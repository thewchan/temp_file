"""``pypabs.ds.x1.run.build_features`` is the entry point for building X1 churn model features."""

# %%
import logging
from pypabs.ds.x1 import META_PARAMS
from pypabs.ds.x1 import customcolumns, customtransforms, customops, customspecs
from pypabs.featurefactory.core import FeatureFactory

logging.basicConfig()
logging.getLogger().setLevel(logging.INFO)
logging.getLogger("py4j").setLevel(logging.ERROR)

# Define ff_config, which contains initial parameters for creating FeatureFactory
ff_config = {
    "specs_file_path": "ds/x1/specs/features",
    # "specs_file_path": "/home/jovyan/work/cloud/comcast/pypabs/pypabs/ds/x1/specs/features",
    "specs_file_name": "features.yml",
    "meta_params": META_PARAMS,
    "custom_modules": [customcolumns, customtransforms, customops],
    "custom_specs": customspecs,
    "from_library": True,
}

# ==

# %%
# Create instance of FeatureFactory given ff_config
ff = FeatureFactory(**ff_config)
# ff.feat_specs_collection = ff.feat_specs_collection[:-1]

# Call make_frames method to create feature frames.
ff.make_frames()

# ==

# FeatureFactory methods to check specifications.
# ff.list_specs()
# ff.show_specs([0, 1])

# len(ff.feat_specs_collection)
# print(ff.feat_specs_collection)
