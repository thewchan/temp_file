"""The ``pypabs.ds.x1.run`` module contains entry points related to X1 churn model."""
