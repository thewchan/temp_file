"""Train X1 churn model."""
# %%
import logging

import pickle  # nosec - safe to use pickle here as all code is written internally

import math
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import gridspec
import mlflow
import numpy as np
import pandas as pd
import pyspark.sql.functions as F
from pytalite_spark.interpretation import (
    partial_dependence_plot,
    feature_importance_plot,
)
from tqdm import tqdm

from pypabs.ds.functions import generate_confusion_matrix, plot_confusion_matrix
from pypabs.ds.x1.models import X1ChurnModel
from pypabs.ds.x1.helper import feature_importances, pdp_plot_single
from pypabs.ds.x1.specs.models.config import (
    MlFlowMeta,
    OtherParams,
    model_config,
    selected_feats,
    dropna_list,
)
from pypabs.featurestore import AxpFeatureStore

logging.basicConfig()
logging.getLogger().setLevel(logging.INFO)
logging.getLogger("py4j").setLevel(logging.ERROR)
x1_churn_logger = logging.getLogger("x1_churn")

# ==

# %% Load features from feature store
feat_store = AxpFeatureStore("x1_churn_model")
model_df = feat_store.load_table("x1_churn_model_data")

# ==

# %% Set latest month to two months prior
x1_churn_logger.info(
    "distinct months in data:\n%s",
    model_df.select("month_id")
    .distinct()
    .sort(F.col("month_id").desc())
    .toPandas(),
)

latest_month = list(
    model_df.select("month_id")
    .distinct()
    .sort(F.col("month_id").desc())
    .toPandas()["month_id"]
)[2]

x1_churn_logger.info("latest month:\n%s", latest_month)

# ==

# %% Prepare features for model
df_subset = model_df.filter(f'month_id="{latest_month}"').cache()
data = df_subset.sampleBy(
    "label",
    fractions={0: OtherParams.downsample, 1: 1},
    seed=model_config["seed"],
)

model_data = data.select(selected_feats)
data_nadropped = model_data.dropna(subset=dropna_list)
data_nafilled = data_nadropped.fillna(-9)

# ==

# %% Start experiment
mlflow.set_tracking_uri("databricks")
mlflow.set_experiment(MlFlowMeta.experiment_name)
mlflow.start_run(run_name=MlFlowMeta.run_name)
run = mlflow.active_run()

x1_churn_logger.info(
    "run_id: %(run_id)s; status: %(status)s",
    {"run_id": run.info.run_id, "status": run.info.status},
)

# ==

# %% Create model
mlflow.log_param("maxDepth", model_config["model_config"]["maxDepth"])

mlflow.log_param("numTrees", model_config["model_config"]["numTrees"])

mlflow.log_param("downsample", OtherParams.downsample)

model = X1ChurnModel(model_data=data_nafilled, **model_config)
training_data = model.training_data
test_data = model.testing_data

# ==

# %% Check null counts, balance and loaded features
data_selected = model.data.drop("features")
x1_churn_logger.info(
    "non-null row counts for each feature:\n%s",
    data_selected.select(
        [
            F.count(F.when(F.isnan(c) | F.col(c).isNull(), c)).alias(c)
            for c in data_selected.columns
        ]
    )
    .union(
        data_selected.select(
            [F.count(c).alias(c) for c in data_selected.columns]
        )
    )
    .toPandas()
    .transpose(),
)

x1_churn_logger.info(
    "training_data class balance:\n%s",
    training_data.groupBy("month_id")
    .agg(F.avg("label"))
    .orderBy("month_id")
    .toPandas(),
)

x1_churn_logger.info(
    "test_data class balance:\n%s",
    test_data.groupBy("month_id")
    .agg(F.avg("label"))
    .orderBy("month_id")
    .toPandas(),
)

x1_churn_logger.info("model features:\n%s", model.features)

# ==

# %% Train model
model.train()

# Log model
mlflow.spark.log_model(model.model, MlFlowMeta.model_name)

# ==

# %% Test model
predictions = model.predict(test_data)
model_auc = model.evaluate(predictions)
x1_churn_logger.info("model auc:%f", model_auc)

# Log metrics
mlflow.log_metric("auc", model_auc)

# ==

# %% Confusion Matrix
cfm = generate_confusion_matrix(predictions)

cfm_fig = plt.figure()
plot_confusion_matrix(cfm)

plt.tight_layout()
mlflow.log_figure(cfm_fig, MlFlowMeta.cfm_img_filename)

# ==

# %% Feature Importance List
feature_importance_list = feature_importances(model)

x1_churn_logger.info(
    "feature importances:\n%s",
    pd.DataFrame(feature_importance_list, columns=["feature", "importance"]),
)

with open(MlFlowMeta.feat_imp_list_filename, "wb") as out_file:
    pickle.dump(feature_importance_list, out_file)

mlflow.log_artifact(MlFlowMeta.feat_imp_list_filename)

# ==

# %% Feature Importance Plot
n_features = OtherParams.feats_imp_plot_n
feature_importances_df = pd.DataFrame(
    data=np.array(feature_importance_list), columns=["feature", "importance"]
).head(n_features)

feature_importances_df["importance"] = feature_importances_df[
    "importance"
].astype(float)

ax = feature_importances_df.iloc[::-1].plot.barh(
    x="feature", y="importance", figsize=(6, 4)
)

plt.tight_layout()
mlflow.log_figure(plt.gcf(), MlFlowMeta.feat_imp_img_filename)

# ==

# %% Permutation Importance Plot
perm_imp = feature_importance_plot(
    test_data.drop("features"),
    "label",
    model.model,
    model_input_col="features",
    columns_to_exclude=["tpid", "month_id"],
    n_top=OtherParams.feats_imp_plot_n,
)

perm_imp.fig.tight_layout()
mlflow.log_figure(perm_imp.fig, MlFlowMeta.perm_imp_img_filename)

# ==

# %% Prepare data for PDP plot
data_pdp = (
    model_data.dropna()
    .sample(OtherParams.pdp_plot_sample_size, seed=model_config["seed"])
    .withColumn("clicks", F.least(F.lit(6000.0), F.col("clicks")))
    .cache()
)

# ==

# %% Features to plot
plottable = []

for f in feature_importance_list:
    f_thresholdpct = data_pdp.selectExpr(
        f"percentile_approx({f[0]}, 0.99)"
    ).collect()[0][0]

    if f_thresholdpct and float(f_thresholdpct) > 0:
        plottable.append(f[0])

list(enumerate(plottable))

# ==

# %% Compute PDP plot data
backend_ = mpl.get_backend()

# Prevent showing plots
mpl.use("Agg")

features_to_plot = OtherParams.pdp_plot_n
num_plots = min(features_to_plot, len(plottable))
ignore_list = ["tpid", "month_id", "label"]

pdp_plot_objs = [
    partial_dependence_plot(
        data_pdp,
        "label",
        model.model,
        f,
        model_input_col="features",
        columns_to_exclude=ignore_list,
    )
    for f in tqdm(plottable[0:num_plots])
]

with open(MlFlowMeta.pdp_obj_filename, "wb") as out_file:
    pickle.dump(pdp_plot_objs, out_file)

# Reset backend
mpl.use(backend_)

x1_churn_logger.info("Number of plot objects:\n%d", len(pdp_plot_objs))

mlflow.log_artifact(MlFlowMeta.pdp_obj_filename)

# ==

# %% Partial dependence plots
NCOLS = 3
nrows = math.ceil(num_plots / NCOLS)
figsize = (30, 30)
fig = plt.figure(figsize=figsize, facecolor=(1, 1, 1, 0))
outer = gridspec.GridSpec(nrows, NCOLS, figure=fig, wspace=0.18, hspace=0.18)

for i, feature in enumerate(plottable[0:num_plots]):
    print(("Plotting lift for feature: {}...").format(feature))
    pdp_plot_single(pdp_plot_objs[i], data_pdp, feature, outer[i], fig)

plt.tight_layout()
mlflow.log_figure(fig, MlFlowMeta.pdp_img_filename)

# ==

# %% End experiment
mlflow.end_run()
run = mlflow.get_run(run.info.run_id)
x1_churn_logger.info(
    "run_id: %(run_id)s; status: %(status)s",
    {"run_id": run.info.run_id, "status": run.info.status},
)

# ==
