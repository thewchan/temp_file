"""Contains model classes for the X1 product.

Models defined here should be extensions of the ``AXPModel`` class.

"""
import logging

from pypabs.ds.core import AXPModel

x1_churn_logger = logging.getLogger("x1_churn")


class X1ChurnModel(AXPModel):
    """X1 churn model.

    Predict the probability an X1 user will churn over the next two months
    based on usage, engagement and account data in the preceding month.

    """

    def __init__(self, model_data=None, **kwargs):
        """Initialize class."""
        self.model_data = model_data
        super().__init__(**kwargs)

    def load_data(self):
        """Override default load_data function in AXPModel class."""
        self.data = self.model_data
        self.get_features()
        self.split_data()
        x1_churn_logger.info("Model data loaded.")
