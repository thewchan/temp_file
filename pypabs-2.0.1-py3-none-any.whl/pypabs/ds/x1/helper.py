"""Helper functions for x1 churn model."""
from os import path
from typing import List, Tuple
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as mtick
from matplotlib import gridspec

import pyspark.sql.functions as F
import pytalite_spark.util.color as clr
from pytalite_spark.util.plots import line_plot, event_plot

from pypabs.ds.core import AXPModel


def feature_importances(model: AXPModel) -> List[Tuple[str, float]]:
    """Return a list of feature importances.

    Returns:
        list[str, float]: List of feature importances

    """
    imp = model.pipeline_model.stages[-1].featureImportances.toArray()
    indices = np.argsort(imp)[::-1]
    return [(model.features[i], round(imp[i], 4)) for i in indices]


def pdp_plot_single(pdp_plot_obj, sdf, feature, outer_grid, fig):
    """Plot a single pdp plot."""
    feature_vals = sdf.select(feature).filter(F.col(feature) != -1)
    means = pdp_plot_obj.data["pd_avg"]
    cis = pdp_plot_obj.data["pd_ci"]
    quantiles = pdp_plot_obj.data["quantiles"]
    x_vals = (quantiles[1:] + quantiles[:-1]) / 2

    style_path = "stylelib/ggplot_transparent.mplstyle"

    # Set path of the mpl style sheet
    style_path = path.join(
        "/dbfs/FileStore/shared_uploads/Anthony_Shaw@comcast.com/", style_path
    )

    with plt.style.context(style_path):
        grid = gridspec.GridSpecFromSubplotSpec(
            2, 1, height_ratios=[10, 1], hspace=0, subplot_spec=outer_grid
        )

        ax1 = plt.subplot(grid[0])
        ax1.yaxis.set_major_formatter(mtick.PercentFormatter(1.0, decimals=1))
        fig.add_subplot(ax1)
        line_plot(
            ax1,
            x_vals,
            cis[:, 0],
            line_color=clr.main[0],
            alpha=0.5,
            style="--",
            line_label=False,
        )
        line_plot(
            ax1,
            x_vals,
            cis[:, 1],
            line_color=clr.main[0],
            alpha=0.5,
            style="--",
            line_label=False,
        )
        line_plot(
            ax1,
            x_vals,
            means,
            line_label=False,
            xticks=[],
            ylabel="",
            legend="Probability",
        )

        ax2 = plt.subplot(grid[1])
        fig.add_subplot(ax2, sharex=ax1)
        event_plot(
            ax2,
            feature_vals.toPandas().values.flatten(),
            0.5,
            1,
            xlabel=feature,
            yticks=[],
            ylim=(-0.2, 1.2),
        )
