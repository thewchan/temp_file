"""The ``pypabs.ds.x1.specs.features`` module contains feature specifications files."""
