"""``pypabs.ds.x1.specs.features.meta`` provides meta parameters used in feature specs YAML file.

X1 model requires 4 complete months of back data to train.

"""
from datetime import datetime

from dateutil.relativedelta import relativedelta

__all__ = ["DATA_DURATION_MONTH", "META_PARAMS", "REF_DAY"]

DATA_DURATION_MONTH = 4
REF_DAY = datetime.today()
# REF_DAY = datetime.strptime("2020-03-15", "%Y-%m-%d")

data_start_date = (
    REF_DAY
    - relativedelta(months=DATA_DURATION_MONTH)
    - relativedelta(days=REF_DAY.day - 1)
)
data_end_date = (
    data_start_date + relativedelta(months=4) - relativedelta(days=1)
)
data_start_date.strftime("%Y-%m")

META_PARAMS = {
    "ingest_date": REF_DAY.strftime("%Y-%m-%d"),
    "data_start_date": data_start_date.strftime("%Y-%m-%d"),
    "data_end_date": data_end_date.strftime("%Y-%m-%d"),
    "data_start_year_month": data_start_date.strftime("%Y-%m"),
    "data_end_year_month": data_end_date.strftime("%Y-%m"),
    # "data_start_year": data_start_date.strftime("%Y"),
    # "data_end_year": data_end_date.strftime("%Y"),
    # "data_start_month": data_start_date.strftime("%m"),
    # "data_end_month": data_end_date.strftime("%m"),
}
