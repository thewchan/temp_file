"""
Module contains mixins to define methods for generating custom columns for each feature frame.

Custom columns for each feature frame are defined in its own mixin class.

Class names need to match short_name in specs file. snake_case short_name will
be converted to PascalCase, with keyword "Mixin" appended. E.g. a short name of
"churn_data" will be matched to "ChurnDataMixin" class.

Method names need to exactly match the values in "custom_columns" in specs file.
All methods need to return a Pyspark column.

"""

import pyspark.sql.functions as F  # noqa: N812; F is convention
from pyspark.sql import Column
from pyspark.sql.window import Window


class TestMixin:  # pragma: no cover # pylint: disable=too-few-public-methods
    """Define custom columns for usage."""

    @staticmethod
    def month_id() -> Column:
        """Define month_id column."""
        return F.substring("day_id", 1, 7)

    @staticmethod
    def tenure_months() -> Column:
        """Define tenure_months column."""
        return F.months_between(F.col("day_id"), F.col("x1_start_date"))

    @staticmethod
    def num_products() -> Column:
        """Define num_products column."""
        return (
            F.col("x1_subscriber")
            + F.col("flex_subscriber")
            + F.col("hsd_subscriber")
            + F.col("xfi_security_subscriber")
            + F.col("home_security_subscriber")
            + F.col("cdv_subscriber")
            + F.col("xmobile_subscriber")
        )

    @staticmethod
    def days_since_stream_last_seen() -> Column:
        """Define days_since_stream_last_seen column."""
        return F.greatest(
            F.lit(0),
            F.least(
                F.datediff(F.col("day_id"), F.col("stream_last_seen")),
                F.lit(180),
            ),
        )

    @staticmethod
    def latest() -> Column:
        """Define latest column."""
        return F.row_number().over(
            Window.partitionBy("tpid", "month_id").orderBy(F.desc("day_id"))
        )


class UserbaseMixin:
    """Define custom columns for userbase."""

    @staticmethod
    def month_id() -> Column:
        """Define month_id column."""
        return F.substring("day_id", 1, 7)

    @staticmethod
    def tenure_months() -> Column:
        """Define tenure_months column."""
        return F.months_between(F.col("day_id"), F.col("x1_start_date"))

    @staticmethod
    def num_products() -> Column:
        """Define num_products column."""
        return (
            F.col("x1_subscriber")
            + F.col("flex_subscriber")
            + F.col("hsd_subscriber")
            + F.col("xfi_security_subscriber")
            + F.col("home_security_subscriber")
            + F.col("cdv_subscriber")
            + F.col("xmobile_subscriber")
        )

    @staticmethod
    def days_since_stream_last_seen() -> Column:
        """Define days_since_stream_last_seen column."""
        return F.greatest(
            F.lit(0),
            F.least(
                F.datediff(F.col("day_id"), F.col("stream_last_seen")),
                F.lit(180),
            ),
        )

    @staticmethod
    def latest() -> Column:
        """Define latest column."""
        return F.row_number().over(
            Window.partitionBy("tpid", "month_id").orderBy(F.desc("day_id"))
        )


class ChurnMonthMixin:  # pylint: disable=too-few-public-methods
    """Define custom columns for churn_month."""

    @staticmethod
    def churn_month() -> Column:
        """Define churn_month column."""
        return F.substring("day_id", 1, 7)


class UsageMixin:  # pylint: disable=too-few-public-methods
    """Define custom columns for usage."""

    @staticmethod
    def month_id() -> Column:
        """Define month_id column."""
        return F.substring("day_id", 1, 7)


class EngagementMixin:
    """Define custom columns for engagement."""

    @staticmethod
    def month_id() -> Column:
        """Define month_id column."""
        return F.concat(
            F.col("calendar_year"),
            F.lit("-"),
            F.when(
                F.col("calendar_month") < 10,
                F.concat(F.lit("0"), F.col("calendar_month")),
            ).otherwise(F.col("calendar_month")),
        )

    @staticmethod
    def MainNav_engage() -> Column:  # pylint: disable=C0103
        """Define MainNav_engage column."""
        return (
            F.col("Guide_clicks")
            + F.col("Saved_clicks")
            + F.col("OnDemand_clicks")
            + F.col("Sports_clicks")
            + F.col("Apps_clicks")
            + F.col("Search_clicks")
            + F.col("Settings_clicks")
        )

    @staticmethod
    def AltGuide_engage() -> Column:  # pylint: disable=C0103
        """Define AltGuide_engage column."""
        return (
            F.col("ALL_CHANNELS_clicks")
            + F.col("FAVORITES_clicks")
            + F.col("FREE_TO_ME_clicks")
            + F.col("HD_clicks")
            + F.col("KIDS_clicks")
            + F.col("MOVIES_clicks")
            + F.col("SPORTS_clicks_Alternative")
            + F.col("TRENDING_clicks")
        )

    @staticmethod
    def MiniGuide_engage() -> Column:  # pylint: disable=C0103
        """Define MiniGuide_engage column."""
        return F.col("MiniGuide_launches")

    @staticmethod
    def Reminders_engage() -> Column:  # pylint: disable=C0103
        """Define Reminders_engage column."""
        return F.col("Reminders")

    @staticmethod
    def Favorites_engage() -> Column:  # pylint: disable=C0103
        """Define Favorites_engage column."""
        return F.col("Favorites")

    @staticmethod
    def Playlists_engage() -> Column:  # pylint: disable=C0103
        """Define Playlists_engage column."""
        return F.col("Playlists")

    @staticmethod
    def Tips_Tricks_engage() -> Column:  # pylint: disable=C0103
        """Define Tips_Tricks_engage column."""
        return F.col("Tips_Tricks")


class X1ChurnDatasetMixin:
    """Define custom columns for x1_churn_dataset."""

    @staticmethod
    def churned_this_month() -> Column:
        """Define churned_this_month column."""
        return F.when(F.col("month_id") == F.col("churn_month"), 1).otherwise(0)

    @staticmethod
    def label() -> Column:
        """Define label column.

        Label columns is defined as whether the user has churned within two
        calendar months after evaluation date.
        """
        return F.least(
            F.lit(1),
            F.sum("churned_this_month").over(
                Window.partitionBy("tpid").orderBy("month_id").rowsBetween(0, 1)
            ),
        )

    @staticmethod
    def churn_month() -> Column:
        """Define churn_month column.

        churn_month is either 1 or "NONE".
        """
        return F.coalesce(F.col("churn_month"), F.lit("NONE"))
