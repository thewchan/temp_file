"""``CustomSpecs`` contains classes that define schemas for custom operations."""

from dataclasses import dataclass
from typing import Optional

from pypabs.util.pprint_mixins import PPrintMixin

__all__ = ["AnotherCustomSample"]


@dataclass
class AnotherCustomSample(PPrintMixin):
    """Define schema for another_custom_sample operation.

    Attributes:
        fraction (float): Fraction of rows to generate, range [0.0, 1.0].
        seed (int): Optional. Seed for sampling (default a random seed).
        with_replacement (bool): Optional. Sample with replacement or not
            (default False).

    """

    fraction: float
    seed: Optional[int] = None
    with_replacement: Optional[bool] = False
