"""
Module contains mixins to define custom transforms for each feature frame.

Custom transforms for each feature frame are defined in its own mixin class.

Class names need to match short_name in specs file. snake_case short_name will
be converted to PascalCase, with keyword "Mixin" appended. E.g. a short name of
"churn_data" will be matched to "ChurnDataMixin" class.

Method names need to exactly match the values in "custom_transforms" in specs file.
All methods need to return a Pyspark dataframe.

"""

from pyspark.sql import DataFrame


class UserbaseMixin:  # pylint: disable=too-few-public-methods
    """Define custom transforms."""

    def custom_sample(self) -> DataFrame:
        """Return a sample from dataframe."""
        return self.sample(withReplacement=False, fraction=0.1, seed=123)
