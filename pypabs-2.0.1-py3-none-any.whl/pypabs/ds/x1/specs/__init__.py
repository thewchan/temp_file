"""Module contains feature, model, and report specifications related to X1 churn model."""
