"""X1 churn model config."""
from dataclasses import dataclass

from pyspark.ml.classification import RandomForestClassifier
from pyspark.ml.evaluation import BinaryClassificationEvaluator


@dataclass
class MlFlowMeta:  # pylint: disable=R0902 # unavoidably many attributes.
    """Define meta params for ML FLow."""

    experiment_name: str = "/Shared/DS-KMM/X1-Churn/x1-churn-dev"
    run_name: str = "top_model"
    model_name: str = "x1-churn-top-model"
    cfm_img_filename: str = "cfm.png"
    feat_imp_list_filename: str = "feature_importance_list.pkl"
    feat_imp_img_filename: str = "feature_importances.png"
    perm_imp_img_filename: str = "perm_importances.png"
    pdp_obj_filename: str = "feature_pdp_obj.pkl"
    pdp_img_filename: str = "feature_pdp.png"


@dataclass
class OtherParams:
    """Define other params."""

    downsample: float = 0.016
    feats_imp_plot_n: int = 30
    pdp_plot_sample_size: float = 0.5
    pdp_plot_n: int = 21


model_config = {
    "seed": 123,
    "model_config": {"maxDepth": 12, "numTrees": 135},
    "model_type": RandomForestClassifier,
    "evaluator_type": BinaryClassificationEvaluator,
    "start_date": "",
    "end_date": "",
    "date_grouping": "month_id",
    "outcome_data": "",
    "feature_sets": "",
    "filter_str": "",
    "excluded_features": ["tpid"],
}

selected_feats = [
    "month_id",
    "tpid",
    "label",
    "mainnav_clicks_proportion",
    "altguide_clicks_proportion",
    "miniguide_clicks_proportion",
    "clicks",
    "time_spent",
    "tune_time_ratio",
    "app_time_ratio",
    "vod_time_ratio",
    "linear_time_ratio",
    "dvr_time_ratio",
    "first_indv_age",
    "tenure_months",
    "time_spent_1mo_percent_change",
    "mrc_recurring_video_amt_per_hr_spent",
    "mrc_recurring_video_proportion",
]

dropna_list = [
    "clicks",
    "time_spent",
    "tune_time_ratio",
    "app_time_ratio",
    "vod_time_ratio",
    "linear_time_ratio",
    "dvr_time_ratio",
    "first_indv_age",
    "tenure_months",
    "time_spent_1mo_percent_change",
    "mrc_recurring_video_amt_per_hr_spent",
    "mrc_recurring_video_proportion",
]
