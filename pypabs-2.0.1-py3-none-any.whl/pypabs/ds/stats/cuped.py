"""Statistic functions and CUPED implementation.

This module contains functions to implement, in PySpark:
    *bootrstrap sampling
    *confidence intervals calculation
    *creation of CUPED metric
    *creation of CUPED metric resampling the data set
    *t-test.
"""

import logging
from typing import List

import numpy as np
import pandas as pd
import scipy.stats as st
from py4j.protocol import Py4JJavaError
from pyspark.ml import Pipeline
from pyspark.ml.feature import StringIndexer, VectorAssembler
from pyspark.ml.regression import LinearRegression
import pyspark.sql.functions as F  # noqa: N812; F is convention
from pyspark.sql.dataframe import DataFrame
from pyspark.sql.session import SparkSession
import pyspark.sql.types as T  # noqa: N812; T is convention
from scipy.stats import t  # type: ignore


logger = logging.getLogger("backend")
DATAFRAME_EMPTY_MSG = "Dataframe empty."
DATAFRAME_DOES_NOT_EXIST_MSG = "does not exist in dataframe."


def bootstrap(
    df_data: DataFrame,
    metric: str,
    spark_session: SparkSession,
    iterations: int = 200,
) -> DataFrame:
    """Generate dataframe of bootstrapped samples.

    This function generates a dataframe containing n bootstrap samples,
     calculated from a PySpark dataframe column. The Spark session
     should have at least these characteristics to produce 1000
     bootstrap sampled datasets:
    spark = SparkSession.builder \
            .master("local[*]") \
            .appName("Bootstrap sampling.") \
            .config("spark.driver.memory", "10g") \
            .config("spark.executor.memory", "10g") \
            .config("spark.driver.maxResultSize", "5g") \
            .config("spark.sql.catalogImplementation", "hive") \
            .getOrCreate()


    Args:
        df_data (pyspark.sql.dataframe.DataFrame): PySpark df that contains
         the data.
        metric (str): df column to calculate the confidence interval
         of.
        spark_session (pyspark.sql.session.SparkSession): Spark
         session.
        iterations (Optional[int]): number of bootstrap samples. It has
         to be at least 100. Defaults to 200.

    Returns:
        pyspark.sql.dataframe.DataFrame: pyspark dataframe with
         bootstrap sample as only column. The column name is the same
         as "metric".
    """
    if iterations < 99:
        raise ValueError("iterations should be at least 100.")

    if df_data.count() == 0:
        raise TypeError(DATAFRAME_EMPTY_MSG)

    if df_data.count() < 2:
        raise ValueError("The data to bootstrapped should be more than 1.")

    if metric not in df_data.columns:
        raise ValueError("Column", metric, DATAFRAME_DOES_NOT_EXIST_MSG)

    def _boot() -> float:
        """Fetches a bootstrapped sample from the dataset."""
        # Ignore return typing check below, cannot infer row elements
        return (
            df_data.sample(withReplacement=True, fraction=1.0, seed=None)
            .agg({metric: "mean"})
            .collect()[0][0]  # type: ignore
        )

    simulations: List[float] = []

    for _ in range(iterations):
        sim = _boot()
        simulations.append(sim)

    # Converting list to pd Dataframe and then to PySpark dataframe.
    dfp_data = pd.DataFrame()
    dfp_data[metric] = simulations
    schema = T.StructType([T.StructField(metric, T.FloatType(), True)])
    return spark_session.createDataFrame(dfp_data, schema=schema)


def confidence_interval(
    alpha: float, df_data: DataFrame, metric: str
) -> List[float]:
    """Generate confidence interval of a column.

    This function generates confidence intervals of a user input
     PySpark dataframe column. It raises a warning if the number of
     data points is less than 30, suggesting to use bootstrap sampling.


    Args:
        alpha (float): significance level. It has to range between
         0 and 1.
        df_data (pyspark.sql.dataframe.DataFrame): PySpark df that contains
         the data.
        metric (str): df column to calculate the confidence interval
         of.

    Returns:
        List[float]: left and right values of confidence interval.
    """
    if alpha < 0.0 or alpha > 1.0:
        raise ValueError(
            "Invalid significance level: \
                          it should be between [0, 1]."
        )

    if df_data.count() == 0:
        raise TypeError("Dataframe empty.")

    if df_data.count() < 2:
        raise ValueError("The data should be more than 1.")

    if df_data.count() < 30:
        logger.warning("Consider bootstrapping (< 30 data points).")

    if metric not in df_data.columns:
        raise ValueError("Column", metric, DATAFRAME_DOES_NOT_EXIST_MSG)

    data_length = df_data.count()
    mean_data: float = df_data.agg({metric: "mean"}).collect()[0][0]
    sem_data: float = df_data.select(F.stddev(metric)).collect()[0][
        0
    ] / np.sqrt(data_length)

    # Ignore type check, limitation to scipy and numpy api
    t_interval = st.t.interval(  # type: ignore
        1 - alpha, data_length - 1, loc=mean_data, scale=sem_data
    )
    return [t_interval[0], t_interval[1]]


def _create_cuped_metric_helper(
    df_data: DataFrame,
    pre_experimental_metric: str,
    metric: str,
) -> List[float]:
    """Create CUPED metrics.

    Args:
        df_data (pyspark.sql.dataframe.DataFrame): PySpark df that
         contains the data.
        pre_experimental_metric (str): pre-experimental metric to be
        used in determining the CUPED metric.
        metric (str): metric to be used in determining the CUPED metric.

    Returns:
        List[float]: parameters (theta and mean_cov) to calculate the
        CUPED metric.
    """
    covariance = df_data.cov(pre_experimental_metric, metric)
    variance: float = df_data.select(
        F.var_pop(pre_experimental_metric)
    ).collect()[0][0]
    theta_calc = covariance / variance
    mean_cov: float = df_data.agg({pre_experimental_metric: "mean"}).collect()[
        0
    ][0]
    return [theta_calc, mean_cov]


def _df_prep_ttest(
    df_data: DataFrame,
    sample_by: str,
    metric: str,
    input_col: str = "CUPED_adjusted_metric",
) -> DataFrame:
    """Prepares data ingestion for t_test().

    Args:
        df_data (pyspark.sql.dataframe.DataFrame): PySpark df that
         contains the data.
        sample_by (str): df column name that contains the "test" and
         "control" groups identifier.
        metric (str): metric to be used in determining the CUPED metric.
        input_col (str): column to be transformed, defaults to:
        "CUPED_adjusted_metric".

    Returns:
        pyspark.sql.dataframe.DataFrame: dataframe assembled to perform
        a t-test via regression.
    """
    string_indexer = StringIndexer(
        inputCol=sample_by, outputCol="group_indexed"
    )
    vector_assembler_pre = VectorAssembler(
        inputCols=[metric], outputCol="features_pre_CUPED"
    )
    vector_assembler_post = VectorAssembler(
        inputCols=[input_col], outputCol="features_CUPED"
    )
    pipeline = Pipeline(
        stages=[string_indexer, vector_assembler_pre, vector_assembler_post]
    )

    # Disabling type checks below due to pyspark api limitation
    model = pipeline.fit(df_data)  # type: ignore

    return model.transform(df_data)  # type: ignore


def create_cuped_metric(  # noqa: CCR001; Consider simplifying
    df_data: DataFrame,
    sample_by: str,
    experimental_groups: List[str],
    pre_experimental_metric: str,
    metric: str,
) -> DataFrame:
    """Return data frame with values adjusted by CUPED.

    This function calculates the CUPED adjusted metric and adds it to
     the dataframe of origin. For more info on the usage, check out the
     notebook at
     https://comcast.cloud.databricks.com/#notebook/5848381/command/5848407.
    Source:
     https://www.exp-platform.com/Documents/2013-02-CUPED-ImprovingSensitivityOfControlledExperiments.pdf,
     https://medium.com/bbc-data-science/increasing-experiment-sensitivity-through-pre-experiment-variance-reduction-166d7d00d8fd


    Args:
        df_data (pyspark.sql.dataframe.DataFrame): PySpark df that contains
         the data.
        sample_by (str): df column name that contains the "test" and
         "control" groups identifier.
        experimental_groups (List(str)): list containing the "test"
         and "control" group identifier as in df column sample_by.
        pre_experimental_metric (str): pre-experimental metric to be
         used in determining the CUPED metric.
        metric (str): metric to be used in determining the CUPED metric.

    Returns:
        pyspark.sql.dataframe.DataFrame: dataframe with
         "CUPED_adjusted_metric" additional column. The relevant
          columns are also indexed and assembled to perform a t-test
          via regression.
    """
    if df_data.count() == 0:
        raise TypeError(DATAFRAME_EMPTY_MSG)

    if sample_by not in df_data.columns:
        raise ValueError("Column", sample_by, DATAFRAME_DOES_NOT_EXIST_MSG)

    groups_list = (  # type: ignore
        df_data.select(sample_by)
        .distinct()
        .rdd.map(lambda x: x[0])  # type: ignore
        .collect()
    )

    if len(experimental_groups) != 2:
        raise ValueError("`experimental_groups` should contain 2 elements.")

    if (experimental_groups[0] not in groups_list) or (
        experimental_groups[1] not in groups_list
    ):
        raise ValueError(
            "`experimental_groups` arguments not found in column ",
            sample_by,
            ".",
        )

    if pre_experimental_metric not in df_data.columns:
        raise ValueError(
            "Column", pre_experimental_metric, DATAFRAME_DOES_NOT_EXIST_MSG
        )

    metric_counts = df_data.filter(
        (F.col(metric) == "") | F.col(metric).isNull() | F.isnan(metric)
    ).count()
    pre_metric_count = df_data.filter(
        (F.col(pre_experimental_metric) == "")
        | F.col(pre_experimental_metric).isNull()
        | F.isnan(pre_experimental_metric)
    ).count()

    if metric_counts != 0 or pre_metric_count != 0:
        raise ValueError(
            "Metric and/or pre-metric columns have invalid\
                         values (None, Null, Nan)."
        )

    df_filtered = (
        df_data.filter(F.col("group").isin(experimental_groups))
        .withColumn(metric, F.col(metric).cast("float"))
        .withColumn(
            pre_experimental_metric,
            F.col(pre_experimental_metric).cast("float"),
        )
    )

    # pylint: disable=C0301
    # Calculation of CUPED adjusted metric
    # (https://www.exp-platform.com/Documents/2013-02-CUPED-ImprovingSensitivityOfControlledExperiments.pdf).
    # pylint: enable=C0301
    theta_calc = _create_cuped_metric_helper(
        df_filtered, pre_experimental_metric, metric
    )[0]
    mean_cov = _create_cuped_metric_helper(
        df_filtered, pre_experimental_metric, metric
    )[1]

    df_filtered = df_filtered.withColumn(
        "CUPED_adjusted_metric",
        F.col(metric)
        - (F.col(pre_experimental_metric) - mean_cov) * theta_calc,
    )
    return _df_prep_ttest(df_filtered, sample_by, metric)


def resample(  # pylint: disable=R0913; required number of vars
    resample_rate: float,
    df_data: DataFrame,
    sample_by: str,
    experimental_groups: List[str],
    pre_experimental_metric: str,
    metric: str,
) -> DataFrame:
    """Return dataframe with CUPED adjusted value on resampled data.

    This function calculates the CUPED adjusted metric for a resampled
     dataframe, and adds it to the dataframe of origin.

    Args:
        resample_rate (float): resample rate in percentage. It must be
         between 0 and 1.
        df (pyspark.sql.dataframe.DataFrame): PySpark df that contains
         the data to resample.
        sample_by (str): df column name that contains the "test" and
        "control" groups identifier.
        experimental_groups (List(str)): list containing the "test" and
         "control" group identifier as in df column sample_by.
        pre_experimental_metric (str): pre-experimental metric to be
         used in determining the CUPED metric.
        metric (str): metric to be used in determining the CUPED
         metric.

    Returns:
        pyspark.sql.dataframe.DataFrame: resampled dataframe with
         "CUPED_adjusted_metric" additional column. The relevant
         columns are also indexed and assembled to perform a t-test via
          regression.
    """
    if (
        (resample_rate < 0.0)
        or (resample_rate > 1.0)
        or (resample_rate == 0.0)
    ):
        raise ValueError(
            "Invalid resample_rate: it should be between [0, 1]."
        )

    print()
    print("Length of df before resampling: ", df_data.count())
    print()

    df_resampled = df_data.sampleBy(
        sample_by,
        fractions={
            experimental_groups[0]: resample_rate,
            experimental_groups[1]: resample_rate,
        },
        seed=0,
    )
    return create_cuped_metric(
        df_resampled,
        sample_by,
        experimental_groups,
        pre_experimental_metric,
        metric,
    )


def t_test(  # noqa: CCR001; consider simplifying
    df_data: DataFrame, feat: str, sample_by: str
) -> List[float]:
    """Return list containing t statistics and p-value of t-test.

    This function performs a two-tailed t-test using regression on the
     categorical variable. If the metric and the categorical variable
     are not suitable for regression, then the function transforms them.

    Args:
        df_data (pyspark.sql.dataframe.DataFrame): PySpark df that
             contains the data to resample.
        feat (str): column to perform the t-test on. If it is not
             of vector type, then the function transforms it.
        sample_by (str): df column name that contains the "test"
             and "control" groups identifier. If it is not of double
              type, then the function transforms it.

    Returns:
        List[float]: t-test and p-value.
    """
    if df_data.count() == 0:
        raise TypeError(DATAFRAME_EMPTY_MSG)

    if feat not in df_data.columns:
        raise ValueError("Column", feat, DATAFRAME_DOES_NOT_EXIST_MSG)

    if dict(df_data.dtypes)[feat] != "vector":
        print(
            "Column",
            feat,
            "is not of vector type - necessary for"
            " regression based t-test: it is being transformed.",
        )
        vector_assembler = VectorAssembler(
            inputCols=[feat], outputCol="assembled_feat"
        )
        pipeline = Pipeline(stages=[vector_assembler])

        # Disabling type checks below due to pyspark api limitation
        model = pipeline.fit(df_data)  # type: ignore
        transformed = model.transform(df_data)  # type: ignore
        return t_test(transformed, feat="assembled_feat", sample_by=sample_by)

    if dict(df_data.dtypes)[sample_by] != "double":
        print(
            "Column",
            sample_by,
            "is not of double type - necessary for"
            " regression based t-test: it is being transformed.",
        )
        string_indexer = StringIndexer(
            inputCol=sample_by, outputCol="double_sample_by"
        )
        pipeline = Pipeline(stages=[string_indexer])

        # Disabling type checks below due to pyspark api limitation
        model = pipeline.fit(df_data)  # type: ignore
        transformed = model.transform(df_data)  # type: ignore
        return t_test(transformed, feat=feat, sample_by="double_sample_by")

    linear_regression = LinearRegression(labelCol=sample_by, featuresCol=feat)
    lr_model = linear_regression.fit(df_data)  # type: ignore
    training_summary = lr_model.summary

    try:
        coeff_t_val = training_summary.tValues[0]
        dof = df_data.count() - 2

        # Disabling type checks below due to scipy api limitation
        p_val: float = (1 - t.cdf(abs(coeff_t_val), dof)) * 2  # type: ignore

        return [coeff_t_val, p_val]

    except (ValueError, Py4JJavaError) as error:
        raise ValueError(
            "There is some issues with the data"
            + "(a group might not have data at all)."
        ) from error
