"""Experimental functions for AB-testing."""
from typing import Callable, List, Literal, Optional, Sequence, Union

import numpy as np
import pandas as pd
import pyspark.sql.functions as F
import statsmodels.api as sm
from numpy.typing import ArrayLike
from pyspark.context import SparkContext
from pyspark.sql.column import Column
from pyspark.sql.dataframe import DataFrame


def _get_bootstrapped_mean(
    data: List[float], boot_size: Optional[int] = None
) -> float:
    """Returns a mean value from bootstrapped sampling.

    Args:
        data: A list of numbers to be sampled on.
        boot_size: Optionally accepts an integer specifying size of each
         bootstrap sample; defaults to size of data.

    Returns:
        Bootstrapped mean.
    """
    if not boot_size:
        boot_size = len(data)

    boot_samples: ArrayLike = [
        data[np.random.randint(0, boot_size - 1)] for _ in range(boot_size)
    ]

    return float(np.mean(boot_samples))


def get_parallel_bootstrap(
    data: List[float],
    spark_context: SparkContext,
    num_iterations: int = 100_000,
    boot_size: Optional[int] = None,
    boot_func: Callable[
        [List[float], Optional[int]], float
    ] = _get_bootstrapped_mean,
) -> DataFrame:
    """Conduct bootstrap sampling in a distributed manner.

    Args:
        data: A 1-D list containing numerical data to be sampled upon.
        spark_context: An active spark context where the distributed
         computation will occur.
        num_iterations: Number of bootstrap sample iterations, defaults
         to 100,000.
        boot_size: The size of each bootstrap sample. Defaults to the
         size of data.
        boot_func: The aggregation function performed by the bootstrap
         sampling. You can specify your own function but it must match
         the function signature of args: data (List[Float]), boot_size
         (Optional[int]) and return a float. If unspecified will default
         to the internal bootstrapped mean function.

    Returns:
        A dataframe with a index column of incrementing integers
         ("sample"), and a column of the bootstrap results
         ("sample_agg").
    """

    if not boot_size:
        boot_size = len(data)

    rdd = spark_context.parallelize(list(range(1, num_iterations + 1)))

    return (
        rdd.map(lambda cell: (cell, boot_func(data, boot_size)))
        .toDF()
        .withColumnRenamed("_1", "sample")
        .withColumnRenamed("_2", "sample_agg")
    )


def _get_stats_summary(column_name: str) -> List[Column]:
    """Return a list of descriptive statistics given a column."""
    stat_functions = [
        F.count,
        F.avg,
        F.stddev,
        F.max,
        F.percentile_approx,
        F.min,
        F.kurtosis,
        F.skewness,
    ]

    return [
        # Linter unable to parse branching comprehension
        func(column_name, 0.5)  # pylint: disable=E1121
        if func == F.percentile_approx
        else func(column_name)
        for func in stat_functions
    ]


def get_stats_summary_table(
    dataframe: DataFrame,
    metric_column: str,
    group_column: str = "",
) -> pd.DataFrame:
    """Return a pandas statistic summary table by group.

    Statistics functions applied include:

    - pyspark.sql.functions.count
    - pyspark.sql.functions.avg
    - pyspark.sql.functions.stddev
    - pyspark.sql.functions.max
    - pyspark.sql.functions.percentile_approx
     (applied at 50% for median)
    - pyspark.sql.functions.min
    - pyspark.sql.functions.kuritosis
    - pyspark.sql.functions.skewness

    Args:
        dataframe: A spark dataframe containing the data.
        metric_column: Name of the column which statistic functions is
         to be applied.
        group_column: Name of the column that labels group membership.
         If left blank will apply statistical functions for the whole
         dataframe.

    Returns:
        A pandas dataframe containing summary statistics.
    """

    return (
        dataframe.groupby(group_column)
        .agg(*_get_stats_summary(metric_column))
        .toPandas()
        .T.rename({0: "", 1: ""}, axis=1)
    )


def _get_binned_data(
    dataframe: DataFrame,
    group_column: str,
    group_name: str,
    metric_name: str,
    bins: int = 250,
) -> pd.DataFrame:
    """Returns a binned pandas dataframe of one group.

    Args:
        dataframe: A pandas dataframe containing the data.
        group_column: Name of the column containing the group split.
        group_name: Name of the group.
        metric_name: Name of the column containing the data to be
         binned.
        bins: Number of bins. Defaults to 250.

    Returns: A pandas dataframe containing the binned metric, including
     upper/lowerbounds.
    """
    return (
        pd.cut(
            dataframe.filter(F.col(group_column) == group_name)
            .toPandas()
            .filter([metric_name], axis=1)
            .squeeze(),
            bins,
        )
        .value_counts()
        .to_frame()
        .reset_index()
        .rename(
            {
                "index": "bins",
                metric_name: "counts",
            },
            axis=1,
        )
        .assign(
            group=group_name,
            lowerbound=lambda temp_dataframe: temp_dataframe["bins"].map(
                lambda interval: interval.left
            ),
            upperbound=lambda temp_dataframe: temp_dataframe["bins"].map(
                lambda interval: interval.right
            ),
            bins=lambda temp_dataframe: temp_dataframe["bins"].astype(str),
        )
    )


def get_grouped_binned_data(
    dataframe: DataFrame,
    group_column: str,
    group_names: Sequence[str],
    metric_name: str,
    bins: int = 250,
) -> pd.DataFrame:
    """Returns a binned pandas dataframe including all groups.

    Args:
        dataframe: A pandas dataframe containing the data.
        group_column: Name of the column containing the group split.
        group_name: Name of the group.
        metric_name: Name of the column containing the data to be
         binned.
        bins: Number of bins. Defaults to 250.

    Returns: A pandas dataframe containing the binned metric, including
     upper/lowerbounds, for each group.
    """
    dataframes: List[pd.DataFrame] = []

    for group in group_names:
        binned_df = _get_binned_data(
            dataframe, group_column, group, metric_name, bins
        )
        dataframes.append(binned_df)

    return pd.concat(dataframes)


def _get_quantile_interval(
    dataframe: DataFrame,
    group_column: str,
    group_name: str,
    metric_name: str,
    alpha: float = 0.05,
) -> pd.DataFrame:
    """Returns the desired quantile interval of a dataframe.

    Args:
        dataframe: The dataframe containing the data.
        group_column: Name of the column containing the grouping of the
         data.
        group_name: Name of the group.
        metric_name: Name of the metric.
        alpha: Confidence level, defaults to 0.05.

    Returns: A pandas dataframe containing the interval.
    """
    return (
        dataframe.filter(F.col(group_column) == group_name)
        .toPandas()
        .filter([metric_name])
        .quantile([alpha / 2, 1 - alpha / 2])
        .assign(**{group_column: group_name})
        .reset_index()
        .rename({"index": "interval"}, axis=1)
    )


def get_grouped_quantile_interval(
    dataframe: DataFrame,
    group_column: str,
    group_names: Sequence[str],
    metric_name: str,
    alpha: float = 0.05,
) -> pd.DataFrame:
    """Returns the grouped desired quantile interval of a dataframe.

    Args:
        dataframe: A pandas dataframe containing the data.
        group_column: Name of the column containing the group split.
        group_names: Names of the group.
        metric_name: Name of the column containing the data to be
         binned.
        bins: Number of bins. Defaults to 250.

    Returns: A pandas dataframe containing the intervals labelled by
     group.
    """
    dataframes: List[pd.DataFrame] = []

    for group in group_names:
        df_interval = _get_quantile_interval(
            dataframe, group_column, group, metric_name, alpha
        )
        dataframes.append(df_interval)

    return pd.concat(dataframes)


def _get_single_group_series(
    dataframe: DataFrame,
    group_column: str,
    group_name: str,
    metric_name: str,
) -> pd.Series:
    """Return a 1D series of 1 group of metric values

    Args:
        dataframe: Spark dataframe containing the data.
        group_column: Name of the column containing the groupings.
        group_name: Name of the group.
        metric_name: Name of the metric.

    Returns: A pandas series of the metric.
    """
    return (
        dataframe.filter(F.col(group_column) == group_name)
        .select(metric_name)
        .toPandas()
        .squeeze()
    )


# Required number of arguments
def get_ttest_summary(  # pylint: disable=R0913,R0914
    dataframe: DataFrame,
    group_column: str,
    group_names: Sequence[str],
    metric_name: str,
    alternative: Union[
        Literal["two-sided"], Literal["larger"], Literal["smaller"]
    ] = "two-sided",
    usevar: Union[Literal["pooled", "unequal"]] = "unequal",
    mean_diff_val: float = 0,
    alpha: float = 0.05,
) -> pd.DataFrame:
    """Returns a pandas dataframe summarizing two-sample t-test.

    This is a wrapper method around the StatsModels t-test api, but
     also summarizes multiple test results and output into a convenient
     dataframe. The list of outputs are:

    - type of t-test ran
    - alternative hypothesis
    - degrees of freedom for two sample test and one sample tests of
     both groups
    - t-statistics for two sample test and one sample tests of both
     groups
    - p-value for two sample test and one sample tests of both groups
    - Confidence interval (determined by ``alpha``) two sample test and
     one sample tests of both groups

    Args:
        dataframe: A spark dataframe containing the data.
        group_column: The name of the column containing the groupings.
        group_names: The names of the two groups. If more than two
         groups exists, only the first two is used.
        metric_name: The name of the metric.
        alternative: This parameter is directly passed to the StatsModels
         api. "two-sided" => H1: Mean not equal to value. "larger" =>
         H1: mean greater than value. "smaller" => H1: mean lesser than
         value. Defaults to "two-sided".
        usevar:This parameter is directly passed to the StatsModels api.
         "polled" => Assumes variance of both group is equal; runs
         regular Student's t-test. "unequal" => Assumes unequal variance
         between the two groups; runs Welch's t-test. Defaults to
         "unequal".
        mean_diff_val: The parameter is directly passed to the
         StatsModels api. This is the value of the mean differences
         between the two group hypothesized to be true in H0. Defaults
         to 0.
        alpha: The parameter is directly passed to the StatsModels api.
         Confidence level; defaults to 0.05.

    Returns: A pandas dataframe containing a summary of the t-tests.
    """
    group_1, group_2, *_ = group_names
    series_group_1 = _get_single_group_series(
        dataframe, group_column, group_1, metric_name
    )
    series_group_2 = _get_single_group_series(
        dataframe, group_column, group_2, metric_name
    )

    descr_stats_w_1 = sm.stats.DescrStatsW(series_group_1)
    descr_stats_w_2 = sm.stats.DescrStatsW(series_group_2)
    compare_means = sm.stats.CompareMeans(descr_stats_w_1, descr_stats_w_2)
    ttest_type = "Student's" if usevar == "pooled" else "Welch's"

    two_samp_t: float
    two_samp_p: float
    two_samp_dof: int
    two_samp_t, two_samp_p, two_samp_dof = compare_means.ttest_ind(
        alternative=alternative, usevar=usevar, value=mean_diff_val
    )

    group_1_t: float
    group_1_p: float
    group_1_dof: int
    group_1_mean: float = descr_stats_w_1.mean
    group_1_t, group_1_p, group_1_dof = descr_stats_w_1.ttest_mean(
        value=descr_stats_w_1.mean, alternative=alternative
    )

    group_2_t: float
    group_2_p: float
    group_2_dof: int
    group_2_mean: float = descr_stats_w_2.mean
    group_2_t, group_2_p, group_2_dof = descr_stats_w_2.ttest_mean(
        value=descr_stats_w_2.mean, alternative=alternative
    )

    if alternative == "two-sided":
        alt_verb = "not equal to"

    elif alternative == "larger":
        alt_verb = "greater than"

    else:
        alt_verb = "lesser than"

    stats_dict = {
        "ttest_type": f"{ttest_type} {alternative} t-test",
        "two_sample_alternative_hypothesis": (
            f"Difference of means is {alt_verb} {mean_diff_val}"
        ),
        "two_sample_degrees_of_freedom": two_samp_dof,
        "two_sample_t_statistics": two_samp_t,
        "two_sample_p_value": two_samp_p,
        f"mean_difference_{int((1 - alpha) * 100)}%_confidence_interval": (
            compare_means.tconfint_diff(
                alpha=alpha,
                alternative=alternative,
                usevar=usevar,
            )
        ),
        f"{group_1}_mean": group_1_mean,
        f"{group_1}_degrees_of_freedom": group_1_dof,
        f"{group_1}_t_statistics": group_1_t,
        f"{group_1}_p_value": group_1_p,
        f"{group_1}_{int((1 - alpha) * 100)}%_confidence_interval": (
            descr_stats_w_1.tconfint_mean(
                alpha=alpha,
                alternative=alternative,
            )
        ),
        f"{group_2}_mean": group_2_mean,
        f"{group_2}_degrees_of_freedom": group_2_dof,
        f"{group_2}_t_statistics": group_2_t,
        f"{group_2}_p_value": group_2_p,
        f"{group_2}_{int((1 - alpha) * 100)}%_confidence_interval": (
            descr_stats_w_2.tconfint_mean(
                alpha=alpha,
                alternative=alternative,
            )
        ),
        f"%-change_{group_2}_to_{group_1}": (group_2_mean - group_1_mean)
        / group_1_mean,
    }

    return pd.DataFrame.from_dict(stats_dict, orient="index", columns=[""])
