"""Utility functions for working with models."""
import itertools
import math
from typing import Callable, List, Mapping, Optional, Tuple, Union

from matplotlib.axes import Axes
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.figure import Figure

import matplotlib.patches as mpatches
import matplotlib.pyplot as plt
import matplotlib.ticker as mtick
import numpy as np
import pandas as pd
from pandas.core.indexes.base import Index
from pandas.core.series import Series
import seaborn as sns
from pyspark.sql.dataframe import DataFrame
from pyspark.sql.types import DoubleType
from sklearn.metrics import confusion_matrix

import pyspark.sql.functions as F  # noqa: N812; F is convention


def generate_confusion_matrix(
    predictions: DataFrame,
) -> np.ndarray:
    """Generates a confusion matrix based on predictions.

    Args:
        prediction (DataFrame): The dataframe containing the prediction
         of the model.

    Returns:
        numpy.ndarray:
            A numpy array containing the values of the confusion matrix.
    """
    pdf = predictions.select("label", "prediction").toPandas()
    return confusion_matrix(pdf["label"], pdf["prediction"], labels=[0, 1])


def plot_feature_lift(  # pylint: disable=R0913; required number of local vars
    feature: str,
    predictions: DataFrame,
    feature_max: int = 100,
    y_axis: str = "probability",
    axes: Optional[Axes] = None,
    legend: bool = True,
    round_digits: int = 0,
) -> None:
    """Plot the lift of the input feature.

    A lift graphs shows the impact of a feature on a model's outcome by
     increasing the value of the given features while holding all other
     features at their population medians.

    Args:
        feature (str): Name of the feature for which lift is to be
         calculated.
        predictions (DataFrame): DataFrame containing model predictions.
        feature_max (int): Maximum value to increase feature value
         towards; default to 100.
        y_axis (Literal["probability", "prediction", "outcome"]): What
         to plot on the y-axis; defaults to "probability".
        axes (matplotlib.axes.Axes): Matplotlib axes object to plot on.
         Defaults to None, which means a new axes object will be used.
        legend (bool): Whether or not to plot legend; defaults to True.
        round_digits (int): The number of decimal place to show.
         Defaults to 0.
    """

    def ith_(vector: List[float], index: int) -> Union[float, None]:
        """Return the element at index for 1D vector."""
        try:
            return float(vector[index])

        except ValueError:
            return None

    ith = F.udf(ith_, DoubleType())
    y_axis = y_axis.lower()
    valid_ys = ["probability", "prediction", "outcome"]

    if y_axis not in valid_ys:
        raise ValueError(f"y must be one of: {valid_ys}")

    data = predictions.withColumnRenamed("label", "outcome").withColumn(
        "probability", ith("probability", F.lit(1))
    )

    avg_y: float = data.agg(F.avg(y_axis)).collect()[0][0]

    pdf = (
        data.withColumn(feature, F.round(feature, round_digits))
        .select(feature, y_axis)
        .filter(f"{feature} between 0 and {feature_max}")
        .toPandas()
    )

    axes = axes or plt.subplots()[1]
    sns.lineplot(data=pdf, x=feature, y=y_axis, label=y_axis, ax=axes)
    axes.axhline(
        avg_y, ls="--", label=f"Baseline ({avg_y:.2%})", color="tomato"
    )
    axes.yaxis.set_major_formatter(mtick.PercentFormatter(1.0))

    if not legend:
        axes.get_legend().remove()
    else:
        plt.legend()


def plot_confusion_matrix(
    model_confusion_matrix: np.ndarray,
    classes: Optional[List[Union[int, str]]] = None,
    normalize: bool = True,
    title: str = "Confusion Matrix",
    # Disable pylint next line; unable to infer color map type
    cmap: LinearSegmentedColormap = plt.cm.Blues,  # pylint: disable=E1101
) -> None:
    """Prints and plots the confusion matrix.

    Args:
        model_confusion_matrix (np.ndarray[integer]): An array
         containing the 4 values of the matrix.
        classes (Optional[List[int, str]]): Name of the binary classes.
         Defaults to [0, 1].
        normalize (bool): Whether or not to normalize the metrics.
         Defaults to True.
        title (str): Title of the visualization. Defaults to "Confusion"
         matrix".
        cmap (matplotlib.colors.LinearSegmentedColormap): A matplotlib
         colormap option. Defaults to ``matplotlib.pyplot.cm.Blues``.
    """
    if classes is None:
        classes = [0, 1]

    # Ignore type check for numpy methods here; limitation to the API
    if normalize:
        model_confusion_matrix = (
            model_confusion_matrix.astype(float)  # type: ignore
            / model_confusion_matrix.sum(axis=1)[:, np.newaxis]  # type: ignore
        )
        print("Normalized confusion matrix")
    else:
        print("Confusion matrix, without normalization")
    plt.imshow(model_confusion_matrix, interpolation="nearest", cmap=cmap)
    plt.title(title)
    plt.colorbar()

    # Ignore type check for numpy methods here; limitation to the API
    tick_marks = np.arange(len(classes))  # type: ignore
    plt.xticks(tick_marks, classes, rotation=45)
    plt.yticks(tick_marks, classes)

    num_format = ".2f" if normalize else "d"

    # Ignore type check for numpy methods here; limitation to the API
    thresh: np.ndarray = model_confusion_matrix.max() / 2.0  # type: ignore

    for pos_i, pos_j in itertools.product(
        range(model_confusion_matrix.shape[0]),
        range(model_confusion_matrix.shape[1]),
    ):
        current_metric_val: int = model_confusion_matrix[pos_i, pos_j]
        plt.text(
            pos_j,
            pos_i,
            format(current_metric_val, num_format),
            horizontalalignment="center",
            color="white"
            if model_confusion_matrix[pos_i, pos_j] > thresh
            else "black",
        )

    plt.tight_layout()
    plt.ylabel("True label")
    plt.xlabel("Predicted label")


def grid_plot(  # pylint: disable=R0913,R0914; required number of local vars
    plot_function: Callable[..., None],
    configs: List[Mapping[str, Union[int, str]]],
    ncols: Optional[int] = None,
    nrows: Optional[int] = None,
    figsize: Optional[Tuple[int, int]] = (18, 11),
    shared_legend: bool = False,
) -> Figure:
    """Plots multiple graphs in a grid arrangement.

    Args:
        plot_function (function): A visualization function. This
         function must take `ax`, a Matplotlib axis object, as an input
         and create the visualization using this object
        configs (list[dict]): A list of configuration dictionaries to be
         passed to `plot_function`.
        ncols (int, optional): Number of columns in the grid. Defaults
         to 3.
        nrows (int, optional): Number of rows in the grid, defaults to
         the number of visualization type divided by ``ncols`` rounded
         up.
        figsize (tuple, optional): (length, width) of the grid in inches
         defaults to (18, 11).
        shared_legend (bool): Whether or not plots in grid should share
         one legend. Defaults to False.

    Returns:
        matplotlib figure: Matplotlib figure object
    """
    if not ncols:
        ncols = 3

    num_plots = len(configs)
    nrows = nrows or math.ceil(num_plots / ncols)
    fig, axes = plt.subplots(nrows, ncols, figsize=figsize)

    # Iterate over all the configurations and plot
    for index, config in enumerate(configs):
        print(f"Plotting config: #{index}...")
        row, col = math.floor(index / ncols), index % ncols

        if len(axes.shape) == 1:
            axis = axes[col]

        else:
            axis = axes[row, col]

        plot_function(axes=axis, **config)

    # Create legend
    if shared_legend:
        handles, labels = axes[0, 0].get_legend_handles_labels()
        fig.legend(handles, labels, loc="lower center")

    return fig


def categorical_feature_lift(  # pylint: disable=R0913,R0914; required# of vars
    feature: str,
    predictions: DataFrame,
    y_axis: str = "probability",
    axes: Optional[Axes] = None,
    title: Optional[str] = None,
    order_by_count: bool = True,
):
    """Plot the lift of the input categorical feature.

    A lift graphs shows the impact of a feature on a model's outcome by
     increasing the value of the given features while holding all other
     features at their population medians. However, for categorical
     features there is no numerical values, thus in this case the counts
     or mean of the categories are varied instead. By default counts
     are used.

    Args:
        feature (str): Name of the feature for which lift is to be
         calculated.
        predictions (DataFrame): DataFrame containing model predictions.
        y_axis (Literal["probability", "prediction", "outcome"]): What
         to plot on the y-axis; defaults to "probability".
        axes (matplotlib.axes.Axes): Matplotlib axes object to plot on.
         Defaults to None, which means a new axes object will be used.
        title (Optional[str]): Title of lift plots, defaults to name of
         the feature.
        order_by_count (bool): Whether to vary the categorical feature
         by counts to generate lift values. If False, the function will
         use means instead. Defaults to True.
    """

    def ith_(vector: List[float], index: int) -> Union[float, None]:
        """Return the element at index for 1D vector."""
        try:
            return float(vector[index])

        except ValueError:
            return None

    ith = F.udf(ith_, DoubleType())
    color = "cornflowerblue"
    valid_ys = ["probability", "prediction", "outcome"]
    if y_axis not in valid_ys:
        raise ValueError(f"y must be one of: {valid_ys}")
    if not axes:
        axes = plt.subplots()[1]

    # Data aggregation
    pdf = (
        predictions.withColumnRenamed("label", "outcome")
        .withColumn("probability", ith("probability", F.lit(1)))
        .select("xboid", feature, y_axis)
        .toPandas()
    )

    # pylint: disable=E1136; Series and Index is scriptable
    # Ignore type check for counts, means and sort_order;
    # limitation to pandas API
    counts: Series = (
        pdf.groupby(feature)
        .xboid.nunique()  # type: ignore
        .sort_values(ascending=False)
    )
    means: pd.DataFrame = (
        pdf.groupby(feature)
        .mean()  # type: ignore
        .sort_values(by=y_axis, ascending=False)
    )
    total_count = pdf["xboid"].nunique()

    if order_by_count:
        sort_order: Index[int] = counts.index  # type: ignore

    else:
        sort_order: Index[int] = means.index  # type: ignore

    # pylint: enable=E1136
    # Ignore type check for counts, means and sort_order;
    # limitation to pandas API
    density: pd.DataFrame = counts.div(  # type: ignore
        total_count, level=feature
    ).reset_index()
    density[feature] = pd.Categorical(
        density[feature], categories=sort_order, ordered=True  # type: ignore
    )

    # Visualization
    barplot_label = f"avg({y_axis})"
    sns.barplot(
        data=pdf,
        x=feature,
        y=y_axis,
        ax=axes,
        order=sort_order,
        label=barplot_label,
        color=color,
    )
    xlabel = feature.replace("_", " ").title()
    axes.set_ylabel(y_axis)
    axes.set_xlabel(xlabel)
    axes.set_xticklabels(axes.get_xticks(), rotation=90)
    ax2 = axes.twinx()
    sns.lineplot(
        data=density,
        x=feature,
        y="xboid",
        ax=ax2,
        marker="o",
        color="black",
        label="Users (%)",
    )
    ax2.set_ylabel("Users (%)")
    axes.yaxis.set_major_formatter(mtick.PercentFormatter(1.0, decimals=0))
    ax2.yaxis.set_major_formatter(mtick.PercentFormatter(1.0, decimals=0))
    plt.title(title or feature)
    handles = ax2.get_legend_handles_labels()[0]

    # Ignore type check for label, limitation to mpl api
    bar_patch = mpatches.Patch(
        color=color,
        label=barplot_label,  # type: ignore
    )
    ax2.legend(handles=[bar_patch, *handles], loc=1)
