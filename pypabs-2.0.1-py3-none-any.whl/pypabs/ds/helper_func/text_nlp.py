"""This module contains functions for parsing NLP texts."""
import re
import string
from typing import List, Union

import nltk
from nltk import ngrams
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize


def find_matching(
    original: List[str], match_ls: List[str]
) -> Union[None, int]:
    """Return number of strings that matches.

    Break list of strings that have contains elements in another list
     of strings.

    Args:
        original (List[str]): List of strings to find matching string
         in another list.
        match_ls (List[str]): List of matching strings.

    Returns:
        int: Number of strings in the original list that has elements
         matched with matching list.

    """
    if original is None:
        return None

    new_list = [
        match_str
        for match_str in original
        if any(str_to_match in match_str for str_to_match in match_ls)
    ]
    return len(new_list)


def remove_numbers(list_str: List[str]) -> List[str]:
    """Remove numbers in a list of strings.

    Args:
        list_str (List[str]): List of strings.

    Returns:
        List[str]: Modified list with no numbers in each string.
    """
    pattern = "[0-9]"

    return [re.sub(pattern, "", i).strip() for i in list_str]


def replace_space(str_w_space: str) -> str:
    """Replace space in a string with underscore & convert to lowercase.

    Args:
        string (str): A string with space.

    Returns:
        str: Replace space with underscore
    """
    if not str_w_space:
        return ""

    return str_w_space.strip().replace(" ", "_").lower()


def break_strings_in_list(
    original: List[str], match_ls: List[str]
) -> Union[None, List[str]]:
    """Break original list of strings based on a matching list.

    If a string in original list contains substring matched in match
     list, single out matched substring to break the string.

    Args:
        original (List[str]): List of strings.
        match (List[str]): Look-up list of strings used to break
         original strings if condition meets.

    Returns:
        Union[None, List[str]]: New list of strings.
    """
    matched_string: List[str] = []
    others: List[str] = []
    idx_array: List[int] = []
    if original is None:
        return None

    for idx, chk_string in enumerate(original):
        for str_to_match in match_ls:
            if (str_to_match in chk_string) & (str_to_match != chk_string):
                matched_string.append(str_to_match)
                others.append(chk_string.replace(str_to_match, "").strip())
                idx_array.append(idx)

    idx_rest = [i for i in range(len(original)) if i not in idx_array]
    rest = [original[i] for i in idx_rest]

    return [
        final_str.strip()
        for final_str in remove_numbers(matched_string + others + rest)
    ]


def count_space_in_string(string_w_space: str) -> int:
    """Count number of spaces in a string.

    Args:
        x (str): A string

    Returns:
        int: Number of spaces in a string.
    """
    if string_w_space is None:
        return 0

    space_count = 0
    for elem in string_w_space:
        if elem == " ":
            space_count += 1

    return space_count


def get_ngrams(current_string: str, ngrams_num: int) -> Union[List[str], None]:
    """Get list of n-gram from a paragraph or sentence.

    Args:
        current_string (str): Sentence or paragraph in a string format.
        ngrams_num (int): Number of grams to break sentence into.

    Returns:
        List[str]: List of n-gram words or phrases.
    """
    nltk.download("punkt")
    nltk.download("wordnet")

    if current_string is None:
        return None

    n_grams = ngrams(word_tokenize(current_string), ngrams_num)
    return [" ".join(grams) for grams in n_grams]


def break_long_commands(current_string: str, match_ls: List[str]) -> str:
    """Basic nlp approach to clean longer voice commands.

    Args:
        current_string (str): Sentence or phrase to break.
        match_ls (List[str]): List of `match` phrase or words that will
         stay its original form.

    Returns:
        str: Sentence that is cleaned up with basic NLP process.
    """
    nltk.download("stopwords")
    nltk.download("punkt")
    nltk.download("wordnet")

    space_count = count_space_in_string(current_string)

    # check special character
    if space_count == 0 and re.match(r"^\w+$", current_string):
        return current_string

    if space_count == 1 and current_string in match_ls:
        return current_string

    current_string = re.sub(r"[\W\_]", " ", current_string).strip()
    text_tokens = word_tokenize(current_string)
    alphabet = list(string.ascii_lowercase)
    list_stop_words = stopwords.words("english")
    lemmatizer = WordNetLemmatizer()

    for letter in alphabet:
        list_stop_words.append(letter)
    tokens_without_sw = [
        word for word in text_tokens if word not in list_stop_words
    ]

    # lemmatization
    lem_text = [
        lemmatizer.lemmatize(str(i), pos="v") for i in tokens_without_sw
    ]
    lem_text = [lemmatizer.lemmatize(str(i), pos="n") for i in lem_text]

    return (" ").join(lem_text)


def lemmatized(current_string: str) -> str:
    """Lemmatize the word string to its original form.

    Args:
        current_string (str): word string

    Returns:
        str: lemmatized word
    """
    nltk.download("wordnet")

    if not current_string:
        return ""

    lemmatizer = WordNetLemmatizer()
    s_new = lemmatizer.lemmatize(current_string, pos="v")
    s_new = lemmatizer.lemmatize(s_new, pos="n")
    s_new = lemmatizer.lemmatize(s_new, pos="a")
    return s_new  # noqa: R504; assignment necessary bc of stateful changes


def check_number_in_string(current_string: str) -> bool:
    """Check if there is number in a string.

    Args:
        s (str): word string

    Returns:
        bool: if number in string, return True
    """
    if not current_string:
        return False

    return any(elem.isdigit() for elem in current_string)
