"""Pyspark UDF to replace a df cell with strings in a list, if the cell contains the string."""

from typing import List

from pyspark.sql.functions import udf
from pyspark.sql.types import StringType


def if_contains(substitutes: List[str], row: str) -> str:
    """Return substitue string if row contains a substring in the list "substitutes".

    Args:
        substitutes (List[str]): list of strings to check and substitute
            if present in the cells
        row (str): string (would be the cell value of the df when used as a udf)

    Returns:
        str: substituted cell if a string in the list substitute was
            found, otherwise old cell

    """
    if len(substitutes) == 0:
        raise TypeError("substitutes lists empty.")

    if not isinstance(row, str):
        raise TypeError("row must be of string type.")

    for substitute in substitutes:

        if substitute in row:
            out = substitute
            return out
    return row


def flatten_rows(substitutes: List[str]) -> StringType:
    """Return a Pyspark UDF using if_contains().

    To use:
    df=df.withColumn("column_new", flatten_rows(substitutes)(F.col("column_old")))

    Args:
        substitutes (List[str]): list of strings to check and substitute
            if present in the cells

    Returns:
        pyspark.sql.types.StrintType: substituted cell if a string in the list
            substitute was found, otherwise old cell

    """
    return udf(lambda x: if_contains(substitutes, x))
