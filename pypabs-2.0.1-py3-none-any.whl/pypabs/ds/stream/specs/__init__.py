"""Feature, model, and report specifications related to stream model."""
