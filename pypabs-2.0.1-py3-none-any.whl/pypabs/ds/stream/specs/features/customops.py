"""Mixins to define custom ops for each feature frame.

Custom ops applicable for ALL feature frames are defined in
 CustomOpsMixin class.

Custom ops for a particular feature frame are defined in its own mixin
 class. Class names need to match short_name of feature frame in specs
 file. The snake_case short_name will be converted to TitleCase, with
 keyword "Mixin" appended. E.g. a short name of "churn_data" will be
 matched to "ChurnDataMixin" class.

Method names need to exactly match the items under "custom_ops" in specs
 file. All methods need to return a Pyspark dataframe.
"""
from typing import TYPE_CHECKING
from pyspark.sql import DataFrame
from pypabs.ds.tutorial.specs.features.customspecs import AnotherCustomSample
# pylint: disable=R0205; will only inherit from DataFrame during type checks

_Base = object

if TYPE_CHECKING:
    _Base = DataFrame


class CustomOpsMixin(_Base):  # pylint: disable=too-few-public-methods
    """Define custom ops."""

    def another_custom_sample(self, params: AnotherCustomSample) -> DataFrame:
        """Return a sample from dataframe.

        Args:
            params (AnotherCustomSample): Schema for sampling function,
             should contain configuration for sampling.

        Returns:
            DataFrame: Sampled dataframe.
        """

        return self.sample(
            withReplacement=params.with_replacement,
            fraction=params.fraction,
            seed=params.seed,
        )
