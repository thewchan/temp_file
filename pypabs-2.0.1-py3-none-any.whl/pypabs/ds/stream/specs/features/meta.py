"""``pypabs.ds.x1.specs.features.meta`` provides meta parameters used in feature specs YAML file."""
from datetime import datetime
from enum import Enum, unique

from pypabs.util.functions import generate_day_id

__all__ = ["META_PARAMS", "REF_DAY"]


@unique
class Platform(str, Enum):
    """Define enumeration for platform.

    Attributes:
        ANDROID: "android"
        CHROMECAST: "chromecast"
        FIRETV: "firetv"
        FLEX: "flex"
        IOS: "ios"
        ROKU: "roku"
        WEB: "web"

    """

    ANDROID = "android"
    CHROMECAST = "chromecast"
    FIRETV = "firetv"
    FLEX = "flex"
    IOS = "ios"
    ROKU = "roku"
    WEB = "web"


REF_DAY = datetime.today()

data_start_date = generate_day_id(-35)
data_end_date = generate_day_id(-7)

# Setting PLATFORM default value
PLATFORM = Platform.IOS.value

META_PARAMS = {
    "ingest_date": REF_DAY.strftime("%Y-%m-%d"),
    "data_start_date": data_start_date,
    "data_end_date": data_end_date,
    "platform": PLATFORM,
}
