"""Mixins to define custom transforms for each feature frame.

Custom transforms for each feature frame are defined in its own mixin
 class.

Class names need to match short_name in specs file. snake_case
 short_name will be converted to PascalCase, with keyword "Mixin"
 appended. E.g. a short name of "churn_data" will be matched to
 "ChurnDataMixin" class.

Method names need to exactly match the values in "custom_transforms"
 in specs file. All methods need to return a Pyspark dataframe.
"""
from typing import TYPE_CHECKING
import pyspark.sql.functions as F  # noqa: N812; F is convention
from pyspark.sql import DataFrame
# pylint: disable=R0205; will only inherit from DataFrame during type checks

_Base = object

if TYPE_CHECKING:
    _Base = DataFrame


# pylint: disable=too-few-public-methods
class EventHighLevelDailyAggrMixin(_Base):
    """Define custom transforms."""

    def session_count_by_event(self) -> DataFrame:
        """Return session_count_by_event.

        Returns:
            DataFrame: Dataframe containing sum of of session counts by
             event names.
        """
        return (
            self.groupBy(
                "account_id", "day_id", "platform", "daily_session_total"
            )
            .pivot("event_name")
            .agg(F.sum("session_count"))
        )
