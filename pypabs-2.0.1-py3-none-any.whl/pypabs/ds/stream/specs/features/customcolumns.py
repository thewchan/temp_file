"""Mixin classes for generating custom columns.

Module contains mixins to define methods for generating custom columns
 for each feature frame. Custom columns for each feature frame are
 defined in its own mixin class.

Class names need to match short_name in specs file. snake_case
 short_name will be converted to PascalCase, with keyword "Mixin"
 appended. E.g. a short name of "churn_data" will be matched to
 "ChurnDataMixin" class.

Method names need to exactly match the values in "custom_columns" in
 specs file. All methods need to return a Pyspark column.

"""
import pyspark.sql.functions as F  # noqa: N812; F is convention
from pyspark.sql import Column
from pyspark.sql.window import Window


class EventHighLevelDailyAggrMixin:  # pylint: disable=too-few-public-methods
    """Define custom columns for event_high_level_daily_aggr."""

    @staticmethod
    def daily_session_total() -> Column:
        """Define daily_session_total column.

        Window function is to aggregate session count per account per
         day.

        Returns:
            Column: Column containing total sessions.
        """
        _window = Window.partitionBy("account_id", "day_id")
        return F.sum("session_count").over(_window)


class EventLowerLevelDailyAggrMixin:  # pylint: disable=too-few-public-methods
    """Define custom columns for event_high_level_daily_aggr."""

    @staticmethod
    def event_attribute() -> Column:
        """Concatenate event_name and payload_key column.

        Returns:
            Column: Column containing string concatenated by underscore.
        """
        return F.concat(F.col("event_name"), F.lit("_"), F.col("payload_key"))

    @staticmethod
    def attribute_value() -> Column:
        """Define custom column here."""
        lowered_col = F.lower(F.col("payload_value"))
        regex_replaced_col = F.regexp_replace(lowered_col, "[^0-9A-Za-z]", "_")
        return (
            F.when(regex_replaced_col.contains("live"), "live_contents")
            .when(regex_replaced_col.contains("mercury"), "mercury_entity")
            .when(regex_replaced_col.contains("recording"), "recording")
            .when(regex_replaced_col.contains("saved"), "saved")
            .when(
                F.col("event_attribute") == "video_played_linear_company",
                "linear_channel",
            )
            .when(
                (
                    F.col("event_attribute")
                    == "video_played_common_sense_media_recommendation"
                )
                & (regex_replaced_col.contains("18+") is True),
                "adult_contents",
            )
            .when(
                (
                    F.col("event_attribute")
                    == "video_played_common_sense_media_recommendation"
                )
                & (~regex_replaced_col.contains("18+") is True),
                "kids_contents",
            )
            .when(
                (regex_replaced_col.contains("browse"))
                & (
                    (regex_replaced_col.contains("kids"))
                    | (regex_replaced_col.contains("baby"))
                    | (regex_replaced_col.contains("ages6"))
                    | (regex_replaced_col.contains("ages8"))
                    | (regex_replaced_col.contains("ages12"))
                    | (regex_replaced_col.contains("preschool"))
                ),
                "kids_contents",
            )
            .when(regex_replaced_col.contains("free"), "free_contents")
            .when(regex_replaced_col.contains("action"), "actions")
            .when(
                (regex_replaced_col.contains("comedy"))
                | (regex_replaced_col.contains("sitcom"))
                | (regex_replaced_col.contains("sit-com"))
                | (regex_replaced_col.contains("sit com")),
                "comedy",
            )
            .when(regex_replaced_col.contains("horror"), "horror")
            .when(regex_replaced_col.contains("reality"), "reality_tv")
            .when(regex_replaced_col.contains("sci-fi"), "scifi")
            .when(regex_replaced_col.contains("drama"), "drama")
            .when(
                (regex_replaced_col.contains("sport"))
                | (regex_replaced_col.contains("football"))
                | (regex_replaced_col.contains("baketball"))
                | (regex_replaced_col.contains("soccer"))
                | (regex_replaced_col.contains("nba"))
                | (regex_replaced_col.contains("nfl")),
                "sports",
            )
            .when(regex_replaced_col.contains("romance"), "drama")
            .when(regex_replaced_col.contains("disney"), "disney")
            .when(regex_replaced_col.contains("hbo"), "hbo")
            .when(regex_replaced_col.contains("movie"), "all_movies")
            .when(regex_replaced_col.contains("film"), "all_movies")
            .when(
                (regex_replaced_col.contains("tvshow"))
                | (regex_replaced_col.contains("tv"))
                | (regex_replaced_col.contains("show")),
                "all_tvshows",
            )
            .when(
                (regex_replaced_col.contains("history"))
                | (regex_replaced_col.contains("discovery"))
                | (regex_replaced_col.contains("documentaries"))
                | (regex_replaced_col.contains("education")),
                "documentaries",
            )
            .when(
                (regex_replaced_col.contains("food"))
                | (regex_replaced_col.contains("cook")),
                "food_network",
            )
            .when(regex_replaced_col.contains("music"), "music")
            .when(regex_replaced_col.contains("film"), "all_movies")
            .when(regex_replaced_col.contains("browse"), "other_contents")
            .otherwise(regex_replaced_col)
        )

    @staticmethod
    def attribute_value_new() -> Column:
        """Define custom column here."""
        return F.concat(
            F.col("event_attribute"), F.lit("_"), F.col("attribute_value")
        )


class X1SubscriberTableMixin:  # pylint: disable=R0903
    """Define custom columns for table here."""

    @staticmethod
    def x1_flag() -> Column:
        """Define custom column here."""
        return F.lit(1)


class X1DailyUsageFeatureMixin:
    """Define custom columns for table here."""

    @staticmethod
    def app_duration() -> Column:
        """Define custom column here."""
        return F.col("app_duration") / 60

    @staticmethod
    def tune_time_spent() -> Column:
        """Define custom column here."""
        return F.col("tune_time_spent") / 60

    @staticmethod
    def time_spent() -> Column:
        """Define custom column here."""
        return F.col("time_spent") / 60


class TargetTableMixin:
    """Define custom columns for table here."""

    @staticmethod
    def user_day() -> Column:
        """Define custom column here."""
        return F.datediff(F.to_date("day_id"), F.to_date("first_seen"))

    @staticmethod
    def user_month() -> Column:
        """Define custom column here."""
        return (
            F.floor(
                F.datediff(F.to_date("day_id"), F.to_date("first_seen")) / 30
            )
            + 1
        )

    @staticmethod
    def user_week() -> Column:
        """Define custom column here."""
        return (
            F.floor(
                F.datediff(F.to_date("day_id"), F.to_date("first_seen")) / 7
            )
            + 1
        )

    @staticmethod
    def next_active_grouping() -> Column:
        """Define custom column here."""
        return F.lead(F.col("user_week")).over(
            Window.partitionBy("account_id", "platform").orderBy(
                F.col("user_week").asc()
            )
        )

    @staticmethod
    def target() -> Column:
        """Define custom column here."""
        return F.when(
            F.col("next_active_grouping") - F.col("user_week") == 1, 1
        ).otherwise(0)


class HighlevelAggrMixin:  # pylint: disable=R0903
    """Define custom columns for table here."""

    @staticmethod
    def user_week() -> Column:
        """Define custom column here."""
        return (
            F.floor(
                F.datediff(F.to_date("day_id"), F.to_date("first_seen")) / 7
            )
            + 1
        )


class LowerlevelAggrMixin:  # pylint: disable=R0903
    """Define custom columns for table here."""

    @staticmethod
    def user_week() -> Column:
        """Define custom column here."""
        return (
            F.floor(
                F.datediff(F.to_date("day_id"), F.to_date("first_seen")) / 7
            )
            + 1
        )
