"""Entry point for building stream retention model features."""

import logging

from pypabs.ds.stream import META_PARAMS, Platform
from pypabs.ds.stream import customcolumns
from pypabs.featurefactory.core import FeatureFactory

logging.basicConfig()
logging.getLogger().setLevel(logging.INFO)
# Set logging evel to ERROR to limit logging printout
# For example: logging.getLogger().setLevel(logging.ERROR)

# Change platform parameter to selected platform here
META_PARAMS["platform"] = Platform.IOS.value

ff_config = {
    "specs_file_path": "ds/stream/specs/features",
    # Set specs_file_path to customize path:
    # e.g. "specs_file_path": "/path/to/folder/containing/yaml/file",
    "specs_file_name": "features.yml",
    "meta_params": META_PARAMS,
    "custom_modules": [customcolumns],
    "from_library": True,
}

ff = FeatureFactory(**ff_config)
# Set feature factory specs to a specific config in collection.
# For example: ff.feat_specs_collection = ff.feat_specs_collection[2:4]

ff.make_frames()
