"""This module contains entry points to run model."""
