"""This module contains specifications and entry points related to the model."""
# pylint: disable=W,C,R
# flake8: noqa

from pypabs.ds.stream.specs.features.meta import META_PARAMS, Platform
from pypabs.ds.stream.specs.features import (
    customcolumns,
    customops,
    customtransforms,
    customspecs,
)
