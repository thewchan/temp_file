"""Core data science functions."""
import json
from datetime import datetime
from typing import (
    Dict,
    List,
    Literal,
    Mapping,
    Optional,
    Sequence,
    Tuple,
    Type,
    TypedDict,
    Union,
)

import attr
import numpy as np
import pandas as pd
from pyspark.ml.base import Estimator, Transformer
import pyspark.sql.functions as F  # noqa: N812; F is convention
from pyspark.ml import Pipeline, PipelineModel
from pyspark.ml.evaluation import BinaryClassificationEvaluator, Evaluator
from pyspark.ml.feature import StringIndexer, VectorAssembler
from pyspark.sql import SparkSession
from pyspark.sql.dataframe import DataFrame
from pyspark.sql.types import DoubleType, StructType

from pypabs.util.functions import generate_day_id


SUCCESS_MESSAGE = "Done!"

spark = SparkSession.builder.getOrCreate()
ConfigValueType = Union[bool, float, int, None, str]
DateGrouping = Union[
    Literal["day_id"],
    Literal["week_id"],
    Literal["month_id"],
    Literal["user_day"],
    Literal["user_week"],
    Literal["user_month"],
]
EvaluatorType = Type[Evaluator]
ModelType = Union[Type[Estimator], Type[Transformer]]


class DateParamType(TypedDict):
    """DateParam type as a TypedDict."""

    start_date: str
    end_date: str
    date_grouping: Union[
        Literal["day_id"],
        Literal["week_id"],
        Literal["month_id"],
        Literal["user_day"],
        Literal["user_week"],
        Literal["user_month"],
    ]


@attr.s
class FeatureSet:
    """A class for generating feature sets.

    Args:
        start_date (string): Start date in YYYY-MM-DD format
        end_date (string): End date in YYYY-MM-DD format
        date_grouping (string): Date grouping in ["day_id","week_id",
        "month_id","user_day","user_week","user_month"]

    """
    start_date = attr.ib(default=generate_day_id(0), type=str)
    end_date = attr.ib(default=generate_day_id(0), type=str)
    date_grouping: DateGrouping = attr.ib(default="day_id")

    date_config = attr.ib(init=False, type=DateParamType)

    def __attrs_post_init__(self) -> None:
        """Initialize additional attributes of FeatureSet."""
        self.date_config = DateParamType(
            start_date=self.start_date,
            end_date=self.end_date,
            date_grouping=self.date_grouping,
        )
        self.validate_inputs()

    def load(self) -> DataFrame:  # pylint: disable=R0201; should be abstract
        """Returns a feature dataframe.

        Method for returning a dataframe containing features + a supported
        date grouping. Should be overridden during subclass creation.
        """
        return spark.createDataFrame([], StructType([]))

    def validate_inputs(self):
        """Validates the date inputs."""
        valid_groupings = [
            "day_id",
            "week_id",
            "month_id",
            "user_day",
            "user_week",
            "user_month",
        ]

        if self.date_grouping not in valid_groupings:
            raise ValueError(
                "Invalid date_grouping. "
                + f"Supported groupings: {valid_groupings}"
            )

        # Validate dates
        try:
            datetime.strptime(self.start_date, "%Y-%m-%d")
            datetime.strptime(self.end_date, "%Y-%m-%d")

        except ValueError as incorrect_date_format:
            print(
                "Invalid date format."
                + "Please provide dates in 'YYYY-MM-DD' format."
            )

            raise ValueError from incorrect_date_format


FeatureSetType = Type[FeatureSet]


@attr.s
class AXPModel:  # pylint: disable=R0902;  Unavoidable number of attributes
    """An object containing data, an ML model, & an evaluator for analyses.

    Args:
        start_date (string): Start date in YYYY-MM-DD format
        end_date (string): End date in YYYY-MM-DD format
        date_grouping (string): Date grouping in ["day_id","week_id",
        "month_id","user_day","user_week","user_month"]
        outcome_data (FeatureSet): Feature sets for generating the outcome
        table to be used by this model.
        feature_sets (list[FeatureSet]): List of FeatureSet objects for
        generating feature sets to be used by this model.
        model_type (pyspark.ml.base.Model): Model to be used
        model_config (dict): Configuration to be passed to the model
        evaluator (pyspark.ml.evaluation.Evaluator): Evaluator to use
        data_inpath (string, optional): Specify path to load a
        pre-compiled dataset
        model_inpath (string, optional): Specify path to load a
        pre-trained model
        excluded_features (list, optional): Individual features to
        exclude from the model
        additional_features (pyspark.sql.dataframe.DataFrame, optional):
         Dataframe of additional features to include in the model
        filter_str(string, optional): SQL filter string to apply to the
         final dataset
        sample_pct (float, optional): Percent (0.00-1.00) of data to
        sample
        seed (int, optional): Seed used for data sampling and
         splitting
        split (list, optional): Split to use for testing and
          training data

    Example:
        ::

            # Data config
            date_grouping = "user_week"
            outcome_data = FlexRetentionOutcomeTable
            feature_sets = [
                FlexUserAttributeFeatures,
                FlexEngagementSummaryFeatures,
                FlexPageViewFeatures,
                FlexHomepageClickFeatures,
                FlexAppUsageFeatures,
                FlexFirstActionFeatures
            ]
            filter_str = "user_week = 1"

            # Model config
            model_config = {
                "maxDepth":10,
                "numTrees":150,
                "maxBins":30
            }
            model = RandomForestClassifier()
            evaluator_type = BinaryClassificationEvaluator()

            # Create final config
            config = {
                "start_date":start_date,
                "end_date": end_date,
                "date_grouping": date_grouping,
                "outcome_data": outcome_data,
                "feature_sets": feature_sets,
                "filter_str": filter_str,
                "model": model,
                "model_config": model_config,
                "evaluator": evaluator
            }

            # Create AXPModel
            model = AXPModel(**config)

    """

    start_date = attr.ib(type=str)
    end_date = attr.ib(type=str)
    date_grouping: DateGrouping = attr.ib()
    outcome_data = attr.ib(type=FeatureSetType)
    feature_sets = attr.ib(type=List[FeatureSetType])
    evaluator_type = attr.ib(type=EvaluatorType)
    model_config = attr.ib(type=Mapping[str, ConfigValueType])
    model_type = attr.ib(type=ModelType)

    additional_features = attr.ib(default=None, type=Optional[DataFrame])
    data_inpath = attr.ib(default=None, type=Optional[str])
    data_summary = attr.ib(default=None, type=DataFrame)
    excluded_features = attr.ib(factory=list, type=Optional[List[str]])
    filter_str = attr.ib(default=None, type=Optional[str])
    model_inpath = attr.ib(default=None, type=Optional[str])
    sample_pct = attr.ib(default=None, type=Optional[float])
    seed = attr.ib(default=None, type=Optional[int])
    split = attr.ib(default=[0.7, 0.3], type=Optional[List[float]])

    data = attr.ib(init=False, type=DataFrame)
    date_params = attr.ib(init=False, type=DateParamType)
    evaluator = attr.ib(init=False, type=Evaluator)
    features = attr.ib(init=False, type=List[str])
    model = attr.ib(init=False, type=Union[Estimator, Transformer])
    other_columns = attr.ib(init=False, type=List[str])
    pipeline = attr.ib(init=False, type=Pipeline)
    pipeline_model = attr.ib(init=False, type=PipelineModel)
    raw_features = attr.ib(init=False, type=List[str])
    string_columns = attr.ib(init=False, type=List[str])
    string_columns_renamed = attr.ib(init=False, type=List[str])
    testing_data = attr.ib(init=False, type=DataFrame)
    training_data = attr.ib(init=False, type=DataFrame)

    # pylint: disable=E1102,W0201
    # Pylint do not recognize __attrs_post_init__
    # Pylint cannot infer certain types are instantiable.
    def __attrs_post_init__(self) -> None:
        """Initialize additional attributes of AXPModel."""
        self.date_params = DateParamType(
            start_date=self.start_date,
            end_date=self.end_date,
            date_grouping=self.date_grouping,
        )
        self.evaluator = self.evaluator_type()
        self.trained = False
        model = self.model_type

        # Load model
        if self.model_inpath:
            self.load_existing_model(self.model_inpath)

        else:
            self.model: Union[Estimator, Transformer] = model(
                **self.model_config
            )

        self.model_config = {
            param[0].name: param[1]
            for param in self.model.extractParamMap().items()
        }

        # Load data
        if self.data_inpath:
            self.load_existing_data(self.data_inpath)

        else:
            self.load_data()

    # pylint: enable=E1102,W0201
    def load_data(self):
        """Loads and combines data for feature sets and outcome data.

        Returns:
            pyspark.sql.dataframe.DataFrame: Dataframe containing
             xboid, date_grouping, label (outcome variable),
             and features
        """
        print("Loading data...")
        date_params = self.date_params

        print(f"Adding outcome data {self.outcome_data.__name__}...")

        # Disable type check here, pyright can't infer attrs
        data = self.outcome_data(**date_params).load()  # type: ignore
        outcome_variable = [
            column
            for column in data.columns
            if column not in ["xboid", self.date_grouping]
        ][0]
        data = data.withColumnRenamed(outcome_variable, "label")

        for feature_set in self.feature_sets:
            print(f"Adding feature set {feature_set.__name__}...")

            # Disable type check here, pyright can't infer attrs
            features = feature_set(**date_params).load()  # type: ignore
            data = data.join(features, ["xboid", self.date_grouping], "left")

        if self.additional_features:
            print("Adding additional features...")
            data = data.join(
                self.additional_features, ["xboid", self.date_grouping], "left"
            )

        if self.sample_pct:
            print("Sampling down...")
            data = data.sample(False, self.sample_pct, seed=self.seed)

        self.get_features(data)
        print("Filling nulls and dropping excluded features...")
        data = (
            data.fillna("UNKNOWN", subset=self.string_columns)
            .fillna(0, subset=self.other_columns)
            .drop(*self.excluded_features)
            .filter(self.filter_str)
        )
        self.data = data
        self.split_data()
        print("Data load complete!")

    def split_data(self) -> None:
        """Splits data into testing and training sets."""
        self.training_data, self.testing_data = self.data.randomSplit(
            self.split, seed=self.seed
        )

    def get_features(self, data: Optional[DataFrame] = None) -> List[str]:
        """Gets a list of model features.

        Args:
            data (pyspark.sql.DataFrame, optional): Input dataframe for
             feature extraction

        Returns:
            list: List of model features
        """
        if not data:
            data = self.data

        ignore_list = [
            "xboid",
            "label",
            self.date_grouping,
            *self.excluded_features,
        ]

        # Feature where values are strings
        self.string_columns = [
            column
            for column, dtype in data.dtypes
            if dtype == "string" and column not in ignore_list
        ]

        # Feature where values are not strings
        self.other_columns = [
            column
            for column, dtype in data.dtypes
            if dtype != "string" and column not in ignore_list
        ]

        self.string_columns_renamed = [
            column + "_index" for column in self.string_columns
        ]

        self.raw_features = self.other_columns + self.string_columns
        self.features = self.other_columns + self.string_columns_renamed

        return self.features

    def set_up_pipeline(self) -> None:
        """Sets up the ML Pipeline.

        Where ``stages = [*indexers, assembler, model]``
        """
        indexers = [
            StringIndexer(
                inputCol=column,
                outputCol=(column + "_index"),
                handleInvalid="skip",
            )
            for column in self.string_columns
        ]
        assembler = VectorAssembler(
            inputCols=self.features, outputCol="features", handleInvalid="skip"
        )
        self.pipeline = Pipeline(stages=[*indexers, assembler, self.model])

    def save_data(self, outpath: str) -> None:
        """Saves data to specified S3 path as parquet.

        Args:
            outpath (string): S3 path for writing out the data
        """
        print(f"Saving data to {outpath}...")
        self.data.write.format("parquet").mode("overwrite").save(outpath)
        self.data = spark.read.parquet(outpath)
        self.training_data, self.testing_data = self.data.randomSplit(
            self.split, seed=self.seed
        )
        print(SUCCESS_MESSAGE)

    def save_model(self, outpath: str) -> None:
        """Saves model to specified S3 path as parquet.

        Args:
            outpath (string): S3 path for saving the model
        """
        print(f"Saving model to {outpath}...")
        self.pipeline_model.write().overwrite().save(outpath)
        print(SUCCESS_MESSAGE)

    def load_existing_data(self, inpath: str) -> None:
        """Loads a saved dataset from the specified S3 path.

        Args:
            inpath (string): S3 location of the data to load

        Returns:
            pyspark.sql.dataframe.DataFrame: Dataframe of data located
             at specified s3 path
        """
        print(f"Loading existing data from {inpath}...")
        self.data = spark.read.parquet(inpath)
        self.get_features()
        self.split_data()
        print(SUCCESS_MESSAGE)

    def load_existing_model(self, inpath: str) -> None:
        """Loads a pre-trained model from s3.

        Args:
            inpath (string): S3 location of saved model
        """
        print(f"Loading existing model {inpath}...")
        self.pipeline_model = PipelineModel.load(inpath)
        self.model = self.pipeline_model.stages[-1]
        self.trained = True  # pylint: disable=W0201; attrb defined in postinit
        print(SUCCESS_MESSAGE)

    def get_data_summary(self) -> DataFrame:
        """Returns a summary of the data."""
        print("Generating data summary...")
        self.data_summary = self.data.summary()
        print(SUCCESS_MESSAGE)
        return self.data_summary

    def train(self, data: Optional[DataFrame] = None) -> None:
        """Trains the model.

        Args:
            data (pyspark.sql.DataFrame, optional): Dataframe containing
             the data to train on.
        """
        data = data or self.training_data
        print("Training model...")
        self.set_up_pipeline()
        self.pipeline_model = self.pipeline.fit(data)
        self.model = self.pipeline_model.stages[-1]
        self.trained = True  # pylint: disable=W0201; attrb defined in postinit
        print(SUCCESS_MESSAGE)

    def predict(self, data: Optional[DataFrame] = None) -> DataFrame:
        """Generates predictions from provided data using the trained model.

        Args:
            data (optional) (pyspark.sql.dataframe.DataFrame): Dataframe to
             generate predictions for. Defaults

        Returns:
            pyspark.sql.dataframe.DataFrame: Dataframe containing
             predictions
        """
        if self.trained:
            data = data or self.testing_data

            return self.pipeline_model.transform(data)

        raise RuntimeError("You must train the model first.")

    def evaluate(self, predictions: Optional[DataFrame] = None) -> float:
        """Evaluates performance of the model based on chosen evaluator.

        Args:
            predictions (pyspark.sql.dataframe.DataFrame): Dataframe
             containing predictions. Defaults to predictions based on
             test data.

        Returns:
            float: Evaluation metric (evaluator specific)
        """
        if not predictions:
            predictions = self.predict()

        return self.evaluator.evaluate(predictions)

    def feature_lift(  # pylint: disable=R0913; Should use typeddict in future
        self,
        feature: str,
        impute_metric: str = "50%",
        minimum: float = 0,
        maximum: Optional[float] = None,
        num: Optional[int] = None,
    ) -> DataFrame:
        """Generates "lift" data for a specified feature.

        Generate feature lift by holding all other features at a value
         specified by the user and iterating the feature over a
         specified range of values.

        Args:
            feature (string): Name of the feature to generate lift data
             for
            impute_metric (string): Metric ("mean", "50%",
             "maximum", "minimum", etc.) to use for setting the value
             of all other features
            minimum (int, optional): Min value to use for feature lift
            maximum (int, optional): Max value to use for feature lift
            num (int, optional): Number of values to use for feature lift

        Returns:
            pyspark.sql.dataframe.DataFrame: Dataframe containing lift
             data for the specified feature
        """

        def ith_(vector: List[float], index: int) -> Union[float, None]:
            """Return the element at index for 1D vector."""
            try:
                return float(vector[index])

            except ValueError:
                return None

        # This udf will return float of ith member given an array cell
        ith = F.udf(ith_, DoubleType())
        summary = self.data_summary or self.get_data_summary()

        # Pyright cannot infer type of summary table, but it will always
        # be a str that is cast-able to float
        maximum = maximum or float(
            summary.filter(F.col("summary") == "75%")
            .select(feature)
            .collect()[0][feature]  # type: ignore
        )

        num = num or int((maximum - minimum) + 1)

        # Disable type check below, limitation of numpy api
        arr = np.linspace(minimum, maximum, num, endpoint=True)  # type: ignore
        _df = spark.createDataFrame(pd.DataFrame(arr), schema=[feature])
        df_new = _df.crossJoin(
            summary.filter(F.col("summary") == impute_metric).select(
                *[
                    F.col(column).cast(DoubleType()).alias(column)
                    for column in self.other_columns
                    if column != feature
                ],
                # Should try to make this the "mode" if possible...
                *[
                    F.lit("UNKNOWN").alias(column)
                    for column in self.string_columns
                    if column != feature
                ],
            )
        )

        return (
            self.predict(df_new)
            .withColumnRenamed("probability", "probability_raw")
            .withColumn("probability", ith("probability_raw", F.lit(1)))
        )

    def get_feature_lifts(  # pylint: disable=R0913; use typeddict in future
        self,
        feature: Union[Sequence[str], str, None] = None,
        num: Optional[int] = None,
        maximum: Optional[float] = None,
        impute_metric: str = "50%",
        minimum: float = 0,
    ) -> Dict[str, pd.DataFrame]:
        """Returns a dict of feature lifts for non-categorical features."""
        lifts: Dict[str, pd.DataFrame] = {}
        feature_list = feature or self.features

        if isinstance(feature, str):
            feature_list = [feature]

        for current_feature in feature_list:
            if "index" not in current_feature:
                print((f"Calculating lift for feature: {current_feature}..."))
                lift = (
                    self.feature_lift(
                        feature=current_feature,
                        impute_metric=impute_metric,
                        minimum=minimum,
                        maximum=maximum,
                        num=num,
                    )
                    .select(
                        current_feature,
                        F.col("probability").alias("retention_probability"),
                    )
                    .toPandas()
                    .set_index(current_feature)
                )

                # disable type check here; limitation of pandas api
                lifts[current_feature] = lift  # type: ignore

        return lifts

    def print_config(self) -> None:  # noqa: CCR001; Cog Complex too high
        """Prints out the configuration of the AXPModel."""
        # date config
        print("========== Date Parameters ==========")
        print(json.dumps({"date_params": self.date_params}, indent=2))
        print("")

        # outcome data
        print("========== Outcome Dataset ==========")
        print(self.outcome_data.__name__)
        print("")

        # feature sets
        print("========== Feature Datasets ==========")

        for feature_set in self.feature_sets:
            print(feature_set.__name__)
        print("")
        print("========== Features ==========")

        for feature in self.features:
            print(feature)
        print("")

        # excluded features
        if self.excluded_features:
            print("========== Excluded Features ==========")

            for feature in self.excluded_features:
                print(feature)
            print("")

        # added features
        if self.additional_features:
            print("========== Additional Features ==========")

            for feature in self.additional_features.columns:
                if feature not in ["xboid", self.date_grouping]:
                    print(feature)

            print("")

        # filter str
        if self.filter_str:
            print("========== Filter String ==========")
            print(self.filter_str)
            print("")

        # model
        print("========== Model Configuration ==========")
        print(self.model.__class__.__name__)
        print(json.dumps({"model_config": self.model_config}, indent=2))
        print("")

        # evaluator
        if isinstance(self.evaluator, BinaryClassificationEvaluator):
            print("========== Evaluator ==========")
            print(self.evaluator.__class__.__name__)
            print(f"Metric: {self.evaluator.getMetricName()}")

    def print_data_info(self) -> Tuple[int, int]:
        """Prints and returns row and user counts of data.

        Returns:
            list (rows, users): List containing row count and user count
        """
        rows = self.data.count()
        users = self.data.select("xboid").distinct().count()
        print("========== Data Info ==========")
        print(f"Rows: {rows}")
        print(f"Users: {users}")

        return rows, users
