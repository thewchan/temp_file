"""Flex models.

The ``models`` module is part of the ``flex.ds`` package in the
 ``pypabs`` library. It contains model classes for the Flex product.

Models defined here should be extensions of the ``AXPModel`` class.

Example:
    ::

        from pyspark.ml.classification import RandomForestClassifier
        from pyspark.ml.evaluation import BinaryClassificationEvaluator
        from pypabs.ds.core import AXPModel
        from pypabs.ds.flex.features import *

        class FlexFirstWeekRetentionModel(AXPModel):
            def __init__(self, **kwargs):

                # Set default config for your model
                default_config = {
                    "start_date": generate_day_id(-91),
                    "end_date": generate_day_id(-1),
                    "date_grouping": "user_week",
                    "outcome_data": FlexRetentionOutcomeTable,
                    "feature_sets": [
                        FlexUserAttributeFeatures,
                        FlexEngagementSummaryFeatures,
                        FlexPageViewFeatures,
                        FlexHomepageClickFeatures,
                        FlexAppUsageFeatures,
                        FlexFirstActionFeatures
                    ],
                    "filter_str": "user_week = 1",
                    "model": RandomForestClassifier,
                    "model_config": {"maxDepth":10,
                                     "numTrees":150,
                                     "maxBins":30},
                    "evaluator": BinaryClassificationEvaluator()
                }

                # Allow user to override default_config
                kwargs = {**default_config, **kwargs}
                super().__init__(**kwargs)

            def some_function(self):
                print("This is a function specific to this model")

"""
from typing import List, Mapping
import attr
import numpy as np
from pyspark.ml.classification import (
    RandomForestClassificationModel,
    RandomForestClassifier,
)
from pyspark.ml.evaluation import BinaryClassificationEvaluator
from pypabs.ds.core import (
    AXPModel,
    ConfigValueType,
    DateGrouping,
    EvaluatorType,
    FeatureSetType,
    ModelType,
)

from pypabs.ds.flex.features.engagement_features import (
    FlexRetentionOutcomeTable,
    FlexUserAttributeFeatures,
    FlexEngagementSummaryFeatures,
    FlexPageViewFeatures,
    FlexHomepageClickFeatures,
    FlexAppUsageFeatures,
    FlexFirstActionFeatures,
    FlexFirstDayFeatures,
)

from pypabs.util.functions import generate_day_id


@attr.s  # Unavoidable number of attributes
class FlexFirstWeekRetentionModel(AXPModel):  # pylint: disable=R0902
    """Flex first week retention predictive model.

    Model for predicting if a Flex user will return in their second
     week (days 8-14) based on usage in their first week (days 1-7)

    Model Type:
        ``RandomForestClassifier``

    Model Config:
        ``{"maxDepth":10,"numTrees":150,"maxBins":30}``

    Outcome Data:
        ``FlexRetentionOutcomeTable``

    Feature Sets:
        * ``FlexUserAttributeFeatures``
        * ``FlexEngagementSummaryFeatures``
        * ``FlexPageViewFeatures``
        * ``FlexHomepageClickFeatures``
        * ``FlexAppUsageFeatures``
        * ``FlexFirstActionFeatures``
        * ``FlexFirstDayFeatures``
    """

    start_date = attr.ib(default=generate_day_id(-91), type=str)
    end_date = attr.ib(default=generate_day_id(-1), type=str)
    date_grouping: DateGrouping = attr.ib(default="user_week")
    outcome_data = attr.ib(
        default=FlexRetentionOutcomeTable, type=FeatureSetType
    )
    feature_sets = attr.ib(
        default=[
            FlexUserAttributeFeatures,
            FlexEngagementSummaryFeatures,
            FlexPageViewFeatures,
            FlexHomepageClickFeatures,
            FlexAppUsageFeatures,
            FlexFirstActionFeatures,
            FlexFirstDayFeatures,
        ],
        type=List[FeatureSetType],
    )
    filter_str = attr.ib(default="user_week = 1", type=str)
    model_type = attr.ib(default=RandomForestClassifier, type=ModelType)
    model_config = attr.ib(
        default={"maxDepth": 10, "numTrees": 150, "maxBins": 30},
        type=Mapping[str, ConfigValueType],
    )
    evaluator_type = attr.ib(
        default=BinaryClassificationEvaluator, type=EvaluatorType
    )

    def feature_importances(self):
        """Returns a list of feature importances.

        Returns:
            list[feature, importance]: List of feature importances
        """
        model_final_step = self.pipeline_model.stages[-1]

        # WARNING: Currently Flex retention model only support models that
        # implements feature importances, e.g. Random forest or decision trees.

        if not isinstance(model_final_step, RandomForestClassificationModel):
            raise TypeError("Model does not implement feature importances")

        imp = model_final_step.featureImportances.toArray()
        indices = np.argsort(imp)[::-1]

        return [(self.features[index], imp[index]) for index in indices]

    def describe(self) -> None:
        """Prints the model's configuration results."""
        performance = round(self.evaluate(), 3)
        metric = self.evaluator.getMetricName()
        print("############### Configuration ###############", end="\n\n")
        self.print_config()
        print("")
        self.print_data_info()
        print("\n\n############### Model Results ###############", end="\n\n")
        print("========== Model Performance ==========")
        print(f"{metric}: {performance}", end="\n\n")
        print("========== Feature Importances ==========")
        for feature in self.feature_importances():
            print(f"{feature[0]:<40} {feature[1]}")
