"""Feature for flex retention model pertaining to device properties."""
from pyspark.sql.dataframe import DataFrame
import pyspark.sql.functions as F  # noqa: N812; F is convention

from pypabs.ds.flex.features.core import FlexFeatureSet
from pypabs.util.core import axp_dataset


class FlexStreamingDeviceFeatures(FlexFeatureSet):
    """Feature of number of non flex devices.

    Creates a dataframe of streaming device features for Flex
     customers, capturing the number of non-Flex streaming devices in
     the household during the date grouping in question.
    """

    def load(self) -> DataFrame:
        """Loads the feature set.

        Returns:
            DataFrame: This feature filters out devices owned by a user
             (xboid) that is not desired to be measured (listed in
             ``device_model``), then return a column of the count of
             distinct devices own by the user as identified by mac
             addresses.
        """
        # Not part of feature; used to related mac address to xboid.
        mapping = (
            axp_dataset("userbase_account_mapping")
            .select(
                F.col("xboid_raw").alias("xboid"),
                F.col("hashed_gateway_mac").alias("cpe_mac"),
            )
            .distinct()
        )

        # A list of undesired model numbers
        device_models = ",".join(
            [
                "'PR150BNC'", "'PX032ANI'", "'MX011ANC'", "'AX014ANM'",
                "'PX013ANC'", "'AX014ANC'", "'MX011ANM'", "'XiD'",
                "'SX022ANC'", "'SR150BNM'",  "'PR150BNM'", "'CXD01ANI'",
                "'AX061AEI'", "'PX051AEI'", "'PX013ANM'", "'TX061AEI'",
                "'AX013ANM'", "'PX001ANM'", "'PX022ANC'", "'PX001ANC'",
                "'CS011ANC'", "'RPI'", "'SX022ANM'", "'AX013ANC'",
                "'PXD01ANI'", "'CS011ANM'", "'PX022ANM'",
            ]
        )
        return (
            axp_dataset("pabs_odp_daily_device")
            .filter(F.col("day_id").between(self.start_date, self.end_date))
            .filter(F.col("device_type") == "Streaming Video Device")
            .filter(
                ~F.col("device_model").isin(
                    [F.lit(model_num) for model_num in device_models]
                )
            )
            .join(mapping, "cpe_mac", "inner")
            .join(self.ref, ["xboid", "day_id"], "inner")
            .withColumn("dt", F.to_date("day_id", "yyyy-MM-dd"))
            .withColumn("month_id", F.substring("day_id", 1, 7))
            .withColumn(
                "week_id",
                F.concat(F.year("dt"), F.lit("-"), F.weekofyear("dt")),
            )
            .drop("dt")
            .groupBy(self.date_grouping, "xboid")
            .agg(F.countDistinct("device_mac").alias("streaming_devices"))
            .withColumn("has_streaming_device", F.lit(1))
        )


# ubb-gateway-ubb-rollup deprecated, will remove completely in future version
# class FlexDataThroughputFeatures(FlexFeatureSet):
#     """Feature for volume of data throughput by user."""

#     def load(self) -> DataFrame:
#         """Loads the feature set.

#         Returns:
#             DataFrame: A dataframe of data throughput features for Flex
#              customers (i.e. total GB up and down.)
#         """
#         return (
#             axp_dataset("ubb-gateway-ubb-rollup")
#             .filter(F.col("day_id").between(self.start_date, self.end_date))
#             .join(self.ref, ["tpid", "day_id"], "inner")
#             .withColumn(
#                 "data_download_gb",
#                 F.col("octin_hourly_agg").cast("float") / 1024 ** 3,
#             )
#             .withColumn(
#                 "data_upload_gb",
#                 F.col("octout_hourly_agg").cast("float") / 1024 ** 3,
#             )
#             .groupBy("xboid", self.date_grouping)
#             .agg(
#                 F.sum("data_download_gb").alias("data_download_gb"),
#                 F.sum("data_upload_gb").alias("data_upload_gb"),
#             )
#         )
