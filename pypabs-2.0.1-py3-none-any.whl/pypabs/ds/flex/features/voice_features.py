"""Voice command feature sets for Flex"""

import string
from datetime import datetime
from pyspark.sql.types import (BooleanType, IntegerType, Row,
                               StringType)
from pyspark.sql import SparkSession

import pyspark.sql.functions as F  # noqa: N812; F is convention

from pypabs.ds.helper_func.text_nlp import (check_number_in_string,
                                            lemmatized, replace_space)
from pypabs.util.core import axp_dataset
from pypabs.ds.flex.features.core import FlexFeatureSet

spark = SparkSession.builder.getOrCreate()


def get_daily_voice_feature_aggregation(dataset):
    """Aggregate and return the daily voice feature."""
    info = dataset["info"]
    # nlp metrics
    total_voice_attempt = len(info)
    nlp_success_voice = len([i for i in info if i["return_code"] == 0])
    nlp_empty_voice_short_press = len([i for i in info
                                       if i["return_code"] == 217])
    nlp_fail_transfer_text = len([i for i in info if i["return_code"] == 211])
    nlp_no_response = len([i for i in info if i["return_code"] == 1003])
    nlp_no_ar_response = len([i for i in info if i["return_code"] == 1004])

    # first action after voice comand
    response_app_launch = len([i for i in info
                               if i["response_type"] == "APP_LAUNCH"])
    response_exit = len([i for i in info if i["response_type"] == "KPR_025"])
    response_search = len([i for i in info if i["response_type"] == "SEA_007"])
    response_try_next_command = len(
                                [i for i in info
                                 if i["response_type"] == "VREX_EVENT_1106"])
    response_media_tune = len([i for i in info
                               if i["response_type"] == "MEDIATUNE_500"])

    # portion
    nlp_success_voice_portion = (nlp_empty_voice_short_press
                                 / total_voice_attempt)
    nlp_empty_voice_short_press_portion = (nlp_empty_voice_short_press
                                           / total_voice_attempt)
    nlp_fail_transfer_text_portion = (nlp_fail_transfer_text
                                      / total_voice_attempt)
    nlp_no_response_portion = nlp_no_response / total_voice_attempt
    nlp_no_ar_response_portion = nlp_no_ar_response / total_voice_attempt

    response_app_launch_portion = response_app_launch / total_voice_attempt
    response_exit_portion = response_exit / total_voice_attempt
    response_search_portion = response_search / total_voice_attempt
    response_try_next_command_portion = (response_try_next_command
                                         / total_voice_attempt)
    response_media_tune_portion = response_media_tune / total_voice_attempt

    return Row(
        xboid=dataset["xboid"],
        date_grouping=dataset[1],
        total_voice_attempt=total_voice_attempt,
        nlp_success_voice=nlp_success_voice,
        nlp_empty_voice_short_press=nlp_empty_voice_short_press,
        nlp_fail_transfer_text=nlp_fail_transfer_text,
        nlp_no_response=nlp_no_response,
        nlp_no_ar_response=nlp_no_ar_response,
        response_app_launch=response_app_launch,
        response_exit=response_exit,
        response_search=response_search,
        response_try_next_command=response_try_next_command,
        response_media_tune=response_media_tune,

        nlp_success_voice_portion=nlp_success_voice_portion,
        nlp_empty_voice_short_press_portion=nlp_empty_voice_short_press_portion,
        nlp_fail_transfer_text_portion=nlp_fail_transfer_text_portion,
        nlp_no_response_portion=nlp_no_response_portion,
        nlp_no_ar_response_portion=nlp_no_ar_response_portion,
        response_app_launch_portion=response_app_launch_portion,
        response_exit_portion=response_exit_portion,
        response_search_portion=response_search_portion,
        response_try_next_command_portion=response_try_next_command_portion,
        response_media_tune_portion=response_media_tune_portion
    )


def get_daily_commands_feature_aggregation(dataset):
    """Aggregate and return the daily commands feature."""
    info = dataset["info"]
    # command
    commands = [i["command"].lower() for i in info if i["return_code"] == 0]
    remove_phase = ["go to", "watch ", "show me ", "launch ", "play ",
                    "open ", "hello ", "please ", "search ", " find ",
                    " one ", " the ", "xfinity", "turn off", "turn on",
                    "tell me", "episode", " two "]
    for word in remove_phase:
        commands = [i.replace(word, "").strip() for i in commands]

    if len(commands) == 0:
        commands = None

    return Row(
        xboid=dataset["xboid"],
        date_grouping=dataset[1],
        commands=commands
    )


class FlexVoiceCommandResolutionFeatures(FlexFeatureSet):
    """
    Creates a dataframe of flex voice first command resolution and nlp
     quality features. (e.g. nlp error counts, nlp success count, app
      launches after voice command, exit after voice command etc.)
    """
    def load(self):
        """Loads the feature set"""
        vcr = (
            axp_dataset("first_command_resolution")
            .filter("partner_id='comcast' and platform='FLEX'")
            .filter(f"""day_id between '{self.start_date}'
                        and '{self.end_date}'""")
            .join(self.hash_mapping, on="xbo_id_hashed", how="inner")
            .drop("xbo_id_hashed")
            .join(self.ref, ["xboid", "day_id"], "inner")
            .groupBy("xboid", self.date_grouping)
            .agg(F.collect_list(F.struct("return_code", "response_type",
                                         "command")).alias("info"))
        )
        vcr_new = (
            vcr.rdd.map(get_daily_voice_feature_aggregation).toDF()
            .withColumnRenamed("date_grouping", self.date_grouping)
            # .drop("info")
        )
        return vcr_new


class FlexVoiceCommandTextRaw(FlexFeatureSet):
    """
    Creates a dataframe of flex voice raw commands.
    """
    def load(self):
        """Loads the feature set"""
        vcr = (
            axp_dataset("first_command_resolution")
            .filter("partner_id='comcast' and platform='FLEX'")
            .filter(f"""day_id between '{self.start_date}'
                        and '{self.end_date}'""")
            .join(self.hash_mapping, on="xbo_id_hashed", how="inner")
            .drop("xbo_id_hashed")
            .join(self.ref, ["xboid", "day_id"], "inner")
            .groupBy("xboid", self.date_grouping)
            .agg(F.collect_list(F.struct("return_code", "response_type",
                                         "command")).alias("info"))
        )
        command_raw = (
            vcr.rdd.map(get_daily_commands_feature_aggregation).toDF()
            .withColumnRenamed("date_grouping", self.date_grouping)
        )
        return command_raw


class FlexVoiceCommandNLPFeatures(FlexFeatureSet):
    """
    Creates a dataframe of flex voice command words features. (e.g.
    netflix, free, hulu, yellowstone etc.)
    """
    def load(self):
        """Loads the feature set"""
        from pyspark.ml.feature import (RegexTokenizer, StopWordsRemover,
                                        Tokenizer)
        replace_space_udf = F.udf(replace_space, StringType())
        lemmatized_udf = F.udf(lemmatized, StringType())
        check_number_in_string_udf = F.udf(check_number_in_string,
                                           BooleanType())

        def get_app_linear_list(start_date, end_date, type_name):
            '''
            Return list of app or linear content name.
            type_name: `APP` or `LINEAR`
            '''
            valid_type = ["APP", "LINEAR"]
            if type_name not in valid_type:
                raise Exception(
                    f"Invalid type name. Supported groupings: {valid_type}")
            apps = (
                axp_dataset("flex_combined_events")
                .filter(f"day_id between '{start_date}' and '{end_date}'")
                .filter(f"type = '{type_name}'")
                .filter(F.col("action").isNotNull())
                .select("action").distinct().collect()
            )
            app_list = list({row["action"].lower() for row in apps})
            return app_list

        def commands_hardcode_clean(command):
            """Clean the commands to their appropirate formate."""
            words_to_exclude = [
                ["go", "two", "en", "take", "de", "say", "hello", "hi",
                 "hey", "usa", "one", "on", "in", "de", "put", "yes", "yeah"]
            ]

            key_word_dict = {
                "amazon": "amazon_prime",
                "netflix": "netflix",
                "setting": "settings",
                "fox": "fox_news",
                "youtube": "youtube",
            }

            for key in key_word_dict:
                if key in command:
                    return key_word_dict[key]

            if (not command) or (command in words_to_exclude):
                return ""

            return command

        commands_hardcode_clean_udf = F.udf(commands_hardcode_clean,
                                            StringType())

        app_list = get_app_linear_list(self.start_date, self.end_date, "APP")
        linear_list = get_app_linear_list(self.start_date, self.end_date,
                                          "LINEAR")
        additional_break_words = ["channel", "disney", "hallmark", "hollywood",
                                  "nfl", "hbo max", "settings", "volume",
                                  "weather", "wgn", "sports", "sling tv",
                                  "amazon music", "amazon prime",
                                  "prime video", "free"]
        combine = list(set(app_list + linear_list + additional_break_words))
        rm_list = [i for i in combine
                   if len(i) == 1] + ["flix", "lol", "ion", "usa"]
        for word in rm_list:
            if word in combine:
                combine.remove(word)

        try:
            commands_raw = FlexVoiceCommandTextRaw(**self.date_config).load()
        except:
            raise Exception("commands raw table cannot be not created")

        commands_explode = (commands_raw.withColumn("commands_explode",
                                                    F.explode(F.col("commands")))
                                        .drop("commands"))

        # tokenize sentence/commands to words
        # tokenizer = Tokenizer(inputCol="commands_explode", outputCol="words")
        regex_tokenizer = RegexTokenizer(inputCol="commands_explode",
                                         outputCol="words", pattern="\\W")
        count_tokens = F.udf(lambda words: len(words), IntegerType())

        regex_tokenized = regex_tokenizer.transform(commands_explode)
        regex_tokenized_df = (
            regex_tokenized
            .select("xboid", self.date_grouping, "commands_explode", "words")
            .withColumn("number_of_words", count_tokens(F.col("words")))
            .withColumn("words_new",
                        F.when(F.col("commands_explode").isin(combine),
                               F.array(F.col("commands_explode")))
                        .otherwise(F.col("words")))
            .drop("words")
            .withColumnRenamed("words_new", "words")
        )

        # remove stop words & apply lemmatization
        remover = StopWordsRemover(inputCol="words", outputCol="filtered")
        remove_sw = remover.transform(regex_tokenized_df)
        commands_new = (
            remove_sw
            .withColumn("explode_new", F.explode(F.col("filtered")))
            .withColumn("filtered_new", lemmatized_udf(F.col("explode_new")))
            .select("xboid", self.date_grouping, "filtered_new")
            .withColumn("words",
                        commands_hardcode_clean_udf(
                            replace_space_udf(F.col("filtered_new"))))
            .cache()
        )

        # save to S3
        time_stamp = int(datetime.now().timestamp())
        outpath = f"s3://comcast-tmp/flex/voice-command-data-{time_stamp}"
        (commands_new.repartition(1000)
         .write.format("parquet").mode("overwrite")
         .save(outpath))
        commands_new = spark.read.parquet(outpath)

        hh_cnt = commands_new.select("xboid").distinct().count()
        alphabet = list(string.ascii_lowercase)
        drop_list = ["fuck", "pussy", "bitch", "you", "hello",
                     "hi", "get", "find", "turn"]
        new_list = alphabet + drop_list

        words_distr = (
            commands_new
            .filter(check_number_in_string_udf(F.col("filtered_new")) is False)
            .filter(F.col("filtered_new")!="")
            .filter(F.col("filtered_new").isNotNull())
            .select("xboid", self.date_grouping, "words")
            .groupBy("words")
            .agg(F.countDistinct("xboid").alias("HH"))
            .filter(F.col("HH") > 0.005*hh_cnt)
            .filter(F.col("words").isNotNull())
            .filter(F.col("words") != "")
            .select("words").distinct().cache()
            .filter(~F.col("words").isin(new_list))
        )

        final = (
            commands_new
            .join(words_distr, on=["words"], how="inner")
            .groupBy("xboid", self.date_grouping, "words")
            .agg(F.count(F.col("xboid")).alias("usage_count"))
            .groupBy("xboid", self.date_grouping)
            .pivot("words")
            .agg(F.sum("usage_count"))
            .fillna(0)
        )
        return final
