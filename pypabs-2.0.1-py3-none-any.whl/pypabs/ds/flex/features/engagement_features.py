"""Engagement feature sets for Flex."""
from typing import List
from pyspark.sql.dataframe import DataFrame
import pyspark.sql.functions as F  # noqa: N812; F is convention
from pyspark.sql.window import Window

from pypabs.ds.flex.features.core import FlexFeatureSet
from pypabs.util.core import axp_dataset


class FlexRetentionOutcomeTable(FlexFeatureSet):
    """Generates an outcome table for Flex retention.

    Flex retention outcome table indicates for each date grouping
     whether a Flex customer used Flex during the subsequent date
     grouping.
     Note: Activation day of week: between 1 and 7; 1 = Sunday, 7 =
     Saturday.
    """

    def load(self) -> DataFrame:
        """Loads the feature set.

        Returns:
            DataFrame: This feature set contains the "true" outcome of
             whether or not new users were retained after the first week
             or not. Active users are defined as user that registered
             either a ``total_time_spent`` that is > 0, or at least 1
             click event, or at least 1 voice commands. Retention is
             determined by comparing active status between week 1 and
             week 2.
        """
        return (
            axp_dataset("flex_daily_usage_summary")
            .filter(F.col("day_id").between(self.start_date, self.end_date))
            .join(
                self.ref.drop("user_day", "user_week"),
                ["xboid", "day_id"],
                "inner",
            )
            .filter(F.lower("partner_id") == "comcast")
            .filter(F.col("account_status") == "Active")
            .withColumn(
                "active",
                F.when(
                    (F.col("total_time_spent") > 0)
                    | (F.col("clicks") > 0)
                    | (F.col("voice_commands") > 0),
                    1,
                ).otherwise(0),
            )
            .groupBy("xboid", self.date_grouping)
            .agg(F.max("active").alias("active"))
            .withColumn(
                "retained",
                F.lead("active").over(
                    Window.partitionBy("xboid").orderBy(self.date_grouping)
                ),
            )
            .filter(F.col(self.date_grouping).isNotNull())
            .filter(F.col("retained").isNotNull())
            .drop("active")
        )


class FlexUserAttributeFeatures(FlexFeatureSet):
    """Creates a dataframe of user attribute features for Flex customers."""

    def load(self) -> DataFrame:
        """Loads the feature set.

        Returns:
            DataFrame: This feature sets contain features related to the
             characteristics of the users themselves. Including the
             Comcast region/division the customer is located, the day of
             the week their device was activated, and other selected
             demographic information from Rosetta.
        """
        div_reg_owned_leased = (
            axp_dataset("userbase_account_details")
            .groupBy("tpid")
            .agg(
                F.max("division").alias("division"),
                F.max("region").alias("region"),
                F.max("owned_leased").alias("owned_leased"),
            )
        )
        activation_day_of_week = (
            axp_dataset("flex_user_week_ref")
            .withColumn(
                "activation_day_of_week",
                F.dayofweek(F.col("account_first_seen_date")),
            )
            .select("xboid", "activation_day_of_week")
        )
        attributes = (
            axp_dataset("flex_rosetta_snapshots")
            .drop("xboid")
            .join(div_reg_owned_leased, ["tpid"], "left")
            .join(self.mapping, ["tpid"], "inner")
            .join(activation_day_of_week, on=["xboid"])
            .drop("tpid")
        )

        return (
            self.ref.join(attributes, ["xboid"], "inner")
            .select(*attributes.columns, self.date_grouping)
            .distinct()
        )


class FlexEngagementSummaryFeatures(FlexFeatureSet):
    """Creates a dataframe of engagement features for Flex customers."""

    def load(self) -> DataFrame:
        """Loads the feature set.

        Returns:
            DataFrame: This feature extract summary engagement metrics
             from flex_daily_usage_summary table according to the
             desired metrics as listed in ``sum_features`` and
             `max_features``. These metrics are aggregated according to
             ``date_grouping``.
        """
        sum_features = [
            "vod_session_count",
            "vod_duration",
            "linear_session_count",
            "linear_duration",
            "other_session_count",
            "other_duration",
            "app_session_count",
            "app_duration",
            "voice_commands",
            "voice_commands_distinct",
            "clicks",
            "total_time_spent",
        ]

        max_features = [
            "distinct_apps",
            "distinct_networks",
            "distinct_features",
        ]

        return (
            axp_dataset("flex_daily_usage_summary")
            .filter(F.col("day_id").between(self.start_date, self.end_date))
            .filter(F.lower("partner_id") == "comcast")
            .filter(F.col("account_status") == "Active")
            .join(
                self.ref.drop("user_day", "user_week"),
                ["xboid", "day_id"],
                "inner",
            )
            .groupBy("xboid", self.date_grouping)
            .agg(
                *[F.sum(feature).alias(feature) for feature in sum_features],
                *[F.max(feature).alias(feature) for feature in max_features],
            )
            .filter(F.col(self.date_grouping).isNotNull())
        )


class FlexPageViewFeatures(FlexFeatureSet):
    """Create a dataframe of page view features for Flex customers."""

    def load(self) -> DataFrame:
        """Loads the feature set.

        Returns:
            DataFrame: This set of features extract from Flex lightning
             logs on whether not not they viewed certain pages as
             defined in ``pages``.
        """
        pages = [
            "Apps",
            "Free to Me",
            "Search",
            "Live TV",
            "Episode Guide",
            "Free movies",
            "Help",
        ]

        # First extract all non empty page view logs
        page_views = (
            axp_dataset("flex_lightning")
            .filter(F.col("day_id").between(self.start_date, self.end_date))
            .filter(F.col("event_name") == "page_view")
            .select(
                "day_id",
                "timestamp",
                F.col("account_id").alias("xboid"),
                "event_id",
                "session_id",
                "event_payload.page_title",
                "event_payload.page_type",
            )
            .filter(F.col("page_title") != "")
            .join(self.ref, ["xboid", "day_id"], "inner")
        )

        # Filter page views to those in list and rename page titles.
        page_view_features_1 = (
            page_views.filter(
                F.col("page_title").isin([F.lit(page) for page in pages])
            )
            .withColumn(
                "page_title",
                F.concat(
                    F.regexp_replace(
                        F.regexp_replace(F.lower("page_title"), r" ", r"_"),
                        r"\'",
                        r"",
                    ),
                    F.lit("_page_views"),
                ),
            )
            .groupBy("xboid", self.date_grouping)
            .pivot("page_title")
            .agg(F.countDistinct("event_id").alias("views"))
        )

        # Filter out page view for home/Casa page.
        page_view_features_2 = (
            page_views.filter(
                ~F.col("page_title").isin(
                    [F.lit(title) for title in ["Home", "Flex Casa"]]
                )
            )
            .withColumn(
                "page_type",
                F.concat(F.col("page_type"), F.lit("_type_page_views")),
            )
            .groupBy("xboid", self.date_grouping)
            .pivot("page_type")
            .agg(F.countDistinct("event_id").alias("views"))
        )

        return page_view_features_1.join(
            page_view_features_2, ["xboid", self.date_grouping], "full"
        ).fillna(0)


class FlexHomepageClickFeatures(FlexFeatureSet):
    """Creates a dataframe of Homepage click features for Flex customers."""

    def load(self) -> DataFrame:
        """Loads the feature set.

        Returns:
            DataFrame: This features extract what tiles on the home page
             flex user clicked on. Home page tiles are defined in ``parents``
             and child tile targets are defined in ``targets``.
        """
        parents = [
            "Popular apps",
            "launchpad",
            "Free movies",
            "News on now",
            "Free TV shows",
            "My list",
        ]

        targets = [
            "Let's get started",
            "Netflix",
            "YouTube",
            "Hulu",
            "Peacock",
            "Prime Video",
            "Trending Live TV",
            "HBO MAX",
            "Apps",
            "Free to Me",
            "Live TV",
            "Pluto TV",
            "Tubi",
            "Sling",
        ]

        # Extract all click events on home page.
        homepage_clicks = (
            axp_dataset("flex_lightning")
            .filter(F.col("day_id").between(self.start_date, self.end_date))
            .filter(F.col("event_name") == "click")
            .filter(F.col("event_payload.page_title") == "Home")
            .select(
                "day_id",
                "timestamp",
                F.col("account_id").alias("xboid"),
                "event_id",
                "session_id",
                "event_payload.page_title",
                "event_payload.parent_title",
                "event_payload.target_title",
                "event_payload.target_url",
            )
            .join(self.ref, ["xboid", "day_id"], "inner")
        )

        # Filter out only click for pages listed in ``parents``
        parent_clicks = (
            homepage_clicks.filter(
                F.col("parent_title").isin(
                    [F.lit(parent) for parent in parents]
                )
            )
            .withColumn(
                "parent_title",
                F.concat(
                    F.regexp_replace(
                        F.regexp_replace(F.lower("parent_title"), r" ", r"_"),
                        r"\'",
                        r"",
                    ),
                    F.lit("_homepage_parent_clicks"),
                ),
            )
            .groupBy("xboid", self.date_grouping)
            .pivot("parent_title")
            .agg(F.countDistinct("event_id").alias("clicks"))
        )

        # Filter out only click for pages listed in ``targets``
        target_clicks = (
            homepage_clicks.filter(
                F.col("target_title").isin(
                    [F.lit(target) for target in targets]
                )
            )
            .withColumn(
                "target_title",
                F.concat(
                    F.regexp_replace(
                        F.regexp_replace(F.lower("target_title"), r" ", r"_"),
                        r"\'",
                        r"",
                    ),
                    F.lit("_homepage_target_clicks"),
                ),
            )
            .groupBy("xboid", self.date_grouping)
            .pivot("target_title")
            .agg(F.countDistinct("event_id").alias("clicks"))
        )

        return parent_clicks.join(
            target_clicks, ["xboid", self.date_grouping], "full"
        ).fillna(0)


class FlexAppUsageFeatures(FlexFeatureSet):
    """Creates a dataframe of app usage features."""

    def load(self) -> DataFrame:
        """Loads the feature set.

        Returns:
            DataFrame: App usage feature for Flex customers is the
             number of sessions and total time spent within important
             apps. Top apps are dynamically defined as the top 15 most
             accessed page as recorded is daily_viewing_summary.
        """
        app_usage = (
            axp_dataset("video_metrics_daily_viewing_summary")
            .filter(F.col("day_id").between(self.start_date, self.end_date))
            .filter(F.col("partner_id") == "comcast")
            .filter(F.col("platform") == "FLEX")
            .filter(F.col("type") == "APP")
            .join(self.mapping, "tpid", "inner")
            .join(self.ref, ["xboid", "day_id"], "inner")
            .withColumn(
                "session_duration",
                F.col("session_duration").cast("float") / 60,
            )
            .withColumn("feature", F.lower(F.col("feature")))
        )

        top_apps: List[str] = (
            app_usage.groupBy("feature")
            .agg(F.countDistinct("xboid").alias("users"))
            .orderBy("users", ascending=False)
            .limit(15)
            .toPandas()["feature"]
            .to_list()
        )

        return (
            app_usage.withColumn(
                "feature",
                F.when(
                    F.col("feature").isin([F.lit(app) for app in top_apps]),
                    F.concat(F.col("feature"), F.lit("_time_spent")),
                ).otherwise("other_apps"),
            )
            .groupBy(self.date_grouping, "xboid")
            .pivot("feature")
            .agg(
                # We can add F.sum("session_count").alias("sessions") here?
                F.sum("session_duration").alias("time_spent")
            )
        )


class FlexFirstActionFeatures(FlexFeatureSet):
    """Creates a dataframe of first action features."""

    def load(self) -> DataFrame:
        """Loads the feature set.

        Returns:
            DataFrame: The list of "first action" captured in these
             features include first app launched, first page viewed, and
             duration spent on first app launched.
        """
        start_datehr = self.start_date.replace("-", "") + "0000"
        end_datehr = self.end_date.replace("-", "") + "2300"

        xboid_hash_table = (
            axp_dataset("xbo_table_account")
            .filter(F.col("day_id").between(self.start_date, self.end_date))
            .select("xboid", "hashxboid")
            .distinct()
        )

        # Get all page views except home/Casa page
        page_views = (
            axp_dataset("flex_lightning")
            .filter(F.col("day_id").between(self.start_date, self.end_date))
            .filter(F.col("event_name") == "page_view")
            .filter(
                ~F.col("event_payload.page_title").isin(
                    [F.lit(title) for title in ["Home", "Flex Casa", ""]]
                )
            )
            .withColumnRenamed("account_id", "xboid")
        )

        # Get all app launches except OTTXFlexApp
        app_launches = (
            axp_dataset("app_launches")
            .filter(F.col("datehr").between(start_datehr, end_datehr))
            .filter(F.col("platform") == "FLEX")
            .filter(F.col("app_name") != "OTTXFlexApp")
            .withColumnRenamed("xboid", "hashxboid")
            .join(xboid_hash_table, "hashxboid")
        )

        # Get top Apps and pages
        top_n = 15
        top_apps: List[str] = (
            app_launches.groupBy("app_name")
            .agg(F.countDistinct("xboid").alias("users"))
            .orderBy("users", ascending=False)
            .limit(top_n)
            .toPandas()["app_name"]
            .to_list()
        )

        top_pages: List[str] = (
            page_views.groupBy("event_payload.page_title")
            .agg(F.countDistinct("xboid").alias("users"))
            .orderBy("users", ascending=False)
            .limit(top_n)
            .toPandas()["page_title"]
            .to_list()
        )

        first_app_launch = (
            app_launches.join(
                app_launches.groupBy("xboid").agg(
                    F.min("log_ts").alias("log_ts")
                ),
                on=["xboid", "log_ts"],
                how="inner",
            )
            .select(
                "xboid",
                F.col("app_name").alias("first_app_launched"),
                (F.col("duration") / 1000).alias(
                    "first_app_launch_duration_sec"
                ),
            )
            .withColumn(
                "first_app_launched",
                F.when(
                    F.col("first_app_launched").isin(
                        [F.lit(apps) for apps in top_apps]
                    ),
                    F.col("first_app_launched"),
                ).otherwise("OTHER"),
            )
        )

        first_page_view = (
            page_views.join(
                page_views.groupBy("xboid").agg(
                    F.min("timestamp").alias("timestamp")
                ),
                on=["xboid", "timestamp"],
                how="inner",
            )
            .select(
                "xboid",
                F.col("event_payload.page_title").alias("first_page_viewed"),
            )
            .withColumn(
                "first_page_viewed",
                F.when(
                    F.col("first_page_viewed").isin(
                        [F.lit(page) for page in top_pages]
                    ),
                    F.col("first_page_viewed"),
                ).otherwise("OTHER"),
            )
        )

        first_actions = first_app_launch.join(first_page_view, "xboid", "full")

        return (
            self.ref.join(first_actions, "xboid", "inner")
            .select(*first_actions.columns, self.date_grouping)
            .distinct()
        )


class FlexFirstDayFeatures(FlexFeatureSet):
    """Creates a dataframe of first day features."""

    def load(self) -> DataFrame:
        """Loads the feature set.

        These features pertain to behavior exhibited during the first
         day of each new user. It extracts the app launch, app usage,
         whether or not they encountered UI errors, voice commands used
         and whether they clicked on a first day user story tile.
        """
        first_seen = (
            axp_dataset("flex_user_week_ref")
            .filter(F.col("day_id").between(self.start_date, self.end_date))
            .groupBy("xboid")
            .agg(F.min("first_seen_date").alias("day_id"))
        )

        lightning = (
            axp_dataset("flex_lightning")
            .withColumnRenamed("account_id", "xboid")
            .join(first_seen, ["xboid", "day_id"], "inner")
        )

        app_usage = (
            axp_dataset("video_metrics_daily_viewing_summary")
            .filter(F.col("day_id").between(self.start_date, self.end_date))
            .filter(F.col("partner_id") == "comcast")
            .filter(F.col("platform") == "FLEX")
            .filter(F.col("type") == "APP")
            .join(self.mapping, "tpid", "inner")
            .join(first_seen, ["xboid", "day_id"], "inner")
            .withColumn(
                "session_duration",
                F.col("session_duration").cast("float") / 60,
            )
            .withColumn("feature", F.lower("feature"))
        )

        top_apps: List[str] = (
            app_usage.groupBy("feature")
            .agg(F.countDistinct("xboid").alias("users"))
            .orderBy("users", ascending=False)
            .limit(15)
            .toPandas()["feature"]
            .to_list()
        )

        first_day_app_usage_features = (
            app_usage.withColumn(
                "feature",
                F.when(
                    F.col("feature").isin([F.lit(app) for app in top_apps]),
                    F.concat(
                        F.lit("first_day_"),
                        F.col("feature"),
                        F.lit("_time_spent"),
                    ),
                ).otherwise("first_day_other_apps_time_spent"),
            )
            .groupBy("xboid")
            .pivot("feature")
            .agg(F.sum("session_duration").alias("time_spent"))
        )

        first_day_lightning_features = (
            lightning.withColumn(
                "visible_error",
                F.when(
                    (F.col("event_name") == "error")
                    & (F.col("event_payload")["is_visible"] == "true"),
                    F.lit(1),
                ).otherwise(F.lit(0)),
            )
            .groupBy("xboid")
            .agg(F.sum("visible_error").alias("first_day_visible_errors"))
        )

        first_day_voice_commands = (
            axp_dataset("flex_daily_usage_summary")
            .filter(F.col("day_id").between(self.start_date, self.end_date))
            .filter(F.lower("partner_id") == "comcast")
            .filter(F.col("account_status") == "Active")
            .join(first_seen, ["xboid", "day_id"], "inner")
            .groupBy("xboid")
            .agg(F.sum("voice_commands").alias("first_day_voice_commands"))
        )

        first_time_user_story_features = (
            axp_dataset("flex_lightning")
            .filter(F.col("day_id").between(self.start_date, self.end_date))
            .filter(F.col("partner_id") == "comcast")
            .select(
                F.col("account_id").alias("xboid"),
                "day_id",
                F.col("event_payload.page_url").alias("page_url"),
                F.when(F.col("event_name") == "click", 1)
                .otherwise(0)
                .alias("first_time_user_story_clicked"),
            )
            .join(
                axp_dataset("flex_user_week_ref")
                .select("xboid", "day_id", "first_seen_date")
                .filter(
                    F.col("day_id").between(self.start_date, self.end_date)
                ),
                on=["xboid", "day_id"],
                how="left",
            )
            .withColumn(
                "days_active",
                F.datediff(F.col("day_id"), F.col("first_seen_date")),
            )
            # Filters user that are within 30 days of device activation
            .filter(F.col("days_active") <= 30)
            .filter(
                F.col("page_url") == "/stories/alias/FlexFirstTimeUserStories"
            )
            .groupBy("xboid")
            .agg(
                F.max("first_time_user_story_clicked").alias(
                    "first_time_user_story_clicked"
                )
            )
        )

        return (
            self.ref.select("xboid", self.date_grouping)
            .distinct()
            .join(first_day_lightning_features, "xboid", "left")
            .join(first_day_app_usage_features, "xboid", "left")
            .join(first_day_voice_commands, "xboid", "left")
            .join(first_time_user_story_features, "xboid", "left")
            .fillna(0)
        )
