"""Core classes and functions for Flex feature sets."""
import attr
from pyspark.sql.dataframe import DataFrame
import pyspark.sql.functions as F  # noqa: N812; F is convention

from pypabs.ds.core import FeatureSet
from pypabs.util.core import axp_dataset


# pylint: disable=W0201; pylint cannot discern __attrs_post_init__
@attr.s
class FlexFeatureSet(FeatureSet):
    """Class for feature sets pertaining to Flex.

    Includes a `ref` attribute that allows for mapping between
     calendar and tenure (i.e. 'user') dates. All other attributes
     inherited from ``FeatureSet``.
    """

    # Create user ref table
    ref = attr.ib(init=False, type=DataFrame)

    def __attrs_post_init__(self):
        """Initialize additional attributes of FlexFeatureSet.

        Generates ``ref`` (pyspark.sql.dataframe.DataFrame), containing user
         IDs and tenure. ``mapping`` (pyspark.sql.dataframe.DataFrame)
         mapping between xboid and tpid. ``hash_mapping`` (
         pyspark.sql.dataframe.DataFrame), mapping between raw xboid and
         hashed (tp hash) xboid.
        """
        # ref is variably generated depending on which date_gropuing is
        # desired.
        self.ref = (
            axp_dataset("flex_user_week_ref")
            .filter(F.col("day_id").between(self.start_date, self.end_date))
            .withColumn(
                "user_month",
                F.floor(
                    F.datediff(
                        F.to_date("day_id"), F.to_date("first_seen_date")
                    )
                    / 30
                )
                + 1,
            )
            .withColumn("dt", F.to_date("day_id", "yyyy-MM-dd"))
            .withColumn("month_id", F.substring("day_id", 1, 7))
            .withColumn(
                "week_id",
                F.concat(F.year("dt"), F.lit("-"), F.weekofyear("dt")),
            )
            .select("tpid", "xboid", "day_id", self.date_grouping)
        )

        self.mapping = (
            axp_dataset("userbase_account_mapping")
            .select(F.col("xboid_raw").alias("xboid"), "tpid")
            .distinct()
        )

        self.hash_mapping = (
            axp_dataset("userbase_account_mapping")
            .select(
                F.col("xboid_raw").alias("xboid"),
                F.col("xboid").alias("xbo_id_hashed"),
            )
            .distinct()
        )
