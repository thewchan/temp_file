"""
Module contains mixins to define custom ops for each feature frame.

Custom ops applicable for ALL feature frames are defined in CustomOpsMixin class.

Custom ops for a particular feature frame are defined in its own mixin class.
Class names need to match short_name of feature frame in specs file. The
snake_case short_name will be converted to TitleCase, with keyword "Mixin"
appended. E.g. a short name of "churn_data" will be matched to "ChurnDataMixin"
class.

Method names need to exactly match the items under "custom_ops" in specs file.
All methods need to return a Pyspark dataframe.

"""

import pyspark.sql.functions as F  # noqa: N812; F is convention
from pyspark.sql import DataFrame
from pypabs.ds.tutorial.specs.features.customspecs import AnotherCustomSample


class CustomOpsMixin:  # pylint: disable=too-few-public-methods
    """Define custom ops for all feature frames."""

    def another_custom_sample(self, params: AnotherCustomSample) -> DataFrame:
        """Return a sample from dataframe."""
        return self.sample(
            withReplacement=params.with_replacement,
            fraction=params.fraction,
            seed=params.seed,
        )


class EventHighLevelDailyAggrMixin:  # pylint: disable=too-few-public-methods
    """Define custom ops for the `event_high_level_daily_aggr` feature frame."""

    def session_count_by_event(self, params: None) -> DataFrame:
        """Return session_count_by_event."""
        _ = params  # doesn't have any input parameters
        return (
            self.groupBy(
                "account_id", "day_id", "platform", "daily_session_total"
            )
            .pivot("event_name")
            .agg(F.sum("session_count"))
        )
