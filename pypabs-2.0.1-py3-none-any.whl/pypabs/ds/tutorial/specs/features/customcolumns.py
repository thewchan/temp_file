"""Mixins with methods for generating columns for each feature frame.

Custom columns for each feature frame are defined in its own mixin
 class.

Class names need to match short_name in specs file. snake_case
 short_name will be converted to TitleCase, with keyword "Mixin"
 appended. E.g. a short name of "churn_data" will be matched to
 "ChurnDataMixin" class.

Method names need to exactly match the values in "custom_columns" in
 specs file. All methods need to return a Pyspark column.
"""
import pyspark.sql.functions as F  # noqa: N812; F is convention
from pyspark.sql import Column
from pyspark.sql.window import Window


class EventHighLevelDailyAggrMixin:  # pylint: disable=too-few-public-methods
    """Define custom columns for event_high_level_daily_aggr."""

    @staticmethod
    def daily_session_total() -> Column:
        """Define daily_session_total column.

        Window function is to aggregate session count per account per
         day.

        Returns:
            Column: Column containing sum of section counts over
             ``account_id`` and ``day_id``.

        """
        _window = Window.partitionBy("account_id", "day_id")

        return F.sum("session_count").over(_window)


class EventLowerLevelDailyAggrMixin:  # pylint: disable=too-few-public-methods
    """Define custom columns for event_high_level_daily_aggr."""

    @staticmethod
    def event_attribute() -> Column:
        """Concatenate event_name and payload_key column.

        Returns:
            Column: Column contained string concatenated by underscores.
        """
        return F.concat(F.col("event_name"), F.lit("_"), F.col("payload_key"))

    @staticmethod
    def attribute_value() -> Column:
        """Transform and clean up attribute values.

        Returns:
            Column: Column containing cleaned up values.
        """
        lowered_col = F.lower(F.col("payload_value"))
        regex_replaced_col = F.regexp_replace(lowered_col, "[^0-9A-Za-z]", "_")
        return (
            F.when(
                F.col("event_attribute").isNull()
                | regex_replaced_col.isNull(),
                "",
            )
            .when(regex_replaced_col.contains("live"), "live_contents")
            .when(regex_replaced_col.contains("mercury"), "mercury_entity")
        )
