"""Feature, model, and report specifications related to the tutorial model."""
