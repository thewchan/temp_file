"""This module contains documentation and sample code for featurestore tutorial."""
# pylint: disable=W,C,R
# flake8: noqa
