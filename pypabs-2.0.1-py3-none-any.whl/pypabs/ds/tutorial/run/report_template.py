#%%+ echo=False, evaluate=False, complete=False
"""Create report using Markdown."""
# pylint: disable=W,C,R
# flake8: noqa

import importlib
import logging
import pickle  # nosec - pickle is safe here cos all code is internally written
import re
import sys
import tempfile
from pathlib import Path

import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import mlflow
import numpy as np
import pandas as pd

from mlflow.entities import ViewType
from pyspark.sql import SparkSession


logging.basicConfig()
logging.getLogger().setLevel(logging.INFO)
logging.getLogger("py4j").setLevel(logging.ERROR)
logger = logging.getLogger("report_template")


def get_dbutils(spark_session):  # pragma: no cover
    """Get dbutils."""
    if "pytest" in sys.modules:
        from unittest import mock

        mock_dbutils = mock.Mock()
        mock_dbutils.fs = mock.Mock()
        return mock_dbutils

    if importlib.util.find_spec("pyspark.dbutils"):
        from pyspark.dbutils import DBUtils  # pylint: disable=C0415

        return DBUtils(spark_session)

    logger.error(
        "pyspark.dbutils not found. This script requires Databricks connect to run."
    )
    sys.exit()


spark = (
    SparkSession.builder.master("local[*]")
    .config("spark.driver.memory", "10g")
    .config("spark.executor.memory", "10g")
    .config("spark.driver.maxResultSize", "5g")
    .config("spark.sql.catalogImplementation", "hive")
    .config(
        "spark.hadoop.fs.s3a.aws.credentials.provider",
        "com.amazonaws.auth.profile.ProfileCredentialsProvider",
    )
    .config("spark.ui.showConsoleProgress", "false")
    .getOrCreate()
)

dbutils = get_dbutils(spark)


mlflow.set_tracking_uri("databricks")
experiment = mlflow.get_experiment_by_name(
    "/Shared/DS-KMM/X1-Churn/x1-churn-dev"
)
experiment_id = experiment.experiment_id

run_infos_list = mlflow.list_run_infos(
    experiment_id, run_view_type=ViewType.ALL, order_by=["start_time DESC"]
)

run_id = pd.DataFrame(run_infos_list).iloc[0][4][1]

artifact_location = Path(experiment.artifact_location) / run_id / "artifacts"


#' ## X1 Churn - Dev
#' #### AXP Key Metric Model
#' #### Date: <% from pypabs.util.functions import generate_day_id; generate_day_id() %>

#' ------
#' ### Executive Summary:

#' ------

#%%+ echo=False, complete=True, results='hidden'
def calc_lifts_data(  # pylint: disable=R0914, R0915
    pdp_plot_objs, feature_importance_list, pctl_step_size=5
):  # pragma: no cover
    """Calculate lifts for all features."""
    all_feature_deltas = []
    all_churn_pct_lifts = []
    all_churn_per_delta_list = []

    quantile_delta = pctl_step_size
    ref_step = pctl_step_size

    for pdp_plot_obj in pdp_plot_objs:
        feature_deltas = []
        churn_pct_lifts = []
        churn_per_delta_list = []

        qt = pdp_plot_obj.data["quantiles"]
        qt = (qt[:-1] + qt[1:]) / 2
        churn_probdist = pdp_plot_obj.data["pd_avg"]

        for ref_idx in range(0, 99 + ref_step, ref_step):
            churn_per_delta_item = {}
            mid_idx = min(ref_idx, 99)
            lower_idx = max(0, int(mid_idx - quantile_delta))
            upper_idx = min(99, int(mid_idx + quantile_delta))

            qt_std_range = (
                qt[lower_idx],
                qt[mid_idx],
                qt[upper_idx],
            )

            churn_std_range = (
                churn_probdist[lower_idx],
                churn_probdist[mid_idx],
                churn_probdist[upper_idx],
            )

            feature_delta = (
                qt_std_range[0] / qt_std_range[1] - 1,
                qt_std_range[2] / qt_std_range[1] - 1,
            )

            churn_pct_lift = (
                churn_std_range[0] / churn_std_range[1] - 1,
                churn_std_range[2] / churn_std_range[1] - 1,
            )

            with np.errstate(all="ignore"):
                churn_per_delta = (
                    churn_pct_lift[0] / abs(feature_delta[0]),
                    churn_pct_lift[1] / abs(feature_delta[1]),
                )

            segment_mid_value = (
                qt[max(0, ref_idx - int(pctl_step_size / 2))],
                qt[min(99, ref_idx + int(pctl_step_size / 2))],
            )

            with np.errstate(all="ignore"):
                churn_per_unit = (
                    (churn_std_range[0] - churn_std_range[1])
                    / (qt_std_range[0] - qt_std_range[1]),
                    (churn_std_range[2] - churn_std_range[1])
                    / (qt_std_range[2] - qt_std_range[1]),
                )

            feature_deltas.append(
                (
                    f"p{mid_idx + 0.5}",
                    "{:.1%}".format(feature_delta[0]),
                    "{0:_.2f}".format(qt_std_range[1]),
                    "{:.1%}".format(feature_delta[1]),
                )
            )

            churn_pct_lifts.append(
                (
                    f"p{mid_idx + 0.5}",
                    "{:.1%}".format(churn_pct_lift[0]),
                    "{:.2}".format(churn_std_range[1]),
                    "{:.1%}".format(churn_pct_lift[1]),
                )
            )

            churn_per_delta_item["seg_left_bound"] = f"p{mid_idx}"

            if np.isnan(churn_per_delta[0]) or (
                churn_per_delta[0] > churn_per_delta[1]
            ):
                idx = 1  # pylint: disable=W0621
                churn_per_delta_item["direction"] = "increase"
                churn_per_delta_item[
                    "target_zone"
                ] = f"p{mid_idx}-p{mid_idx+pctl_step_size}"
                churn_per_delta_item["segment_lo_value"] = qt[mid_idx]
                churn_per_delta_item["segment_hi_value"] = qt[
                    min(99, mid_idx + pctl_step_size)
                ]
            else:
                idx = 0
                churn_per_delta_item["segment_hi_value"] = qt[mid_idx]
                mid_idx = 100 if mid_idx == 99 else mid_idx
                churn_per_delta_item["direction"] = "decrease"
                churn_per_delta_item["segment_lo_value"] = qt[
                    max(0, mid_idx - pctl_step_size)
                ]
                churn_per_delta_item[
                    "target_zone"
                ] = f"p{mid_idx-pctl_step_size}-p{mid_idx}"

            churn_per_delta_item["churn_abs_range"] = abs(
                churn_std_range[2] - churn_std_range[0]
            )
            churn_per_delta_item["churn_per_delta"] = churn_per_delta[idx]
            churn_per_delta_item["segment_mid_value"] = segment_mid_value[idx]
            churn_per_delta_item["churn_per_unit"] = churn_per_unit[idx]
            churn_per_delta_item["pct_to_pct_point_factor"] = (
                0.01 / segment_mid_value[idx] * 100
            )
            churn_per_delta_list.append(churn_per_delta_item)

        all_feature_deltas.append(feature_deltas)
        all_churn_pct_lifts.append(churn_pct_lifts)
        all_churn_per_delta_list.append(churn_per_delta_list)

    feature_names = list(map(lambda x: x[0], feature_importance_list))

    return (
        dict(zip(feature_names, all_feature_deltas)),
        dict(zip(feature_names, all_churn_pct_lifts)),
        dict(zip(feature_names, all_churn_per_delta_list)),
    )


dbfs_prefix_sub_model = "dbfs:/ds-reports/x1-churn/dev/sub-model/"
feature_importance_list_path_sub_model = (
    dbfs_prefix_sub_model + "feature_importance_list.pkl"
)
pdp_obj_path_sub_model = dbfs_prefix_sub_model + "feature_pdp_obj.pkl"

#%%+ echo=False, complete=True, results='hidden', include=False, fig=False
with tempfile.TemporaryDirectory() as temp_dir:
    dbutils.fs.cp(pdp_obj_path_sub_model, "file:" + temp_dir)
    dbutils.fs.cp(feature_importance_list_path_sub_model, "file:" + temp_dir)

    pdp_plot_objs_sm = pickle.load(  # nosec - pickle is safe here
        open(str(Path(temp_dir) / "feature_pdp_obj.pkl"), "rb")
    )
    feature_importance_list_sm = pickle.load(  # nosec - pickle is safe here
        open(str(Path(temp_dir) / "feature_importance_list.pkl"), "rb")
    )


_, _, churn_per_delta_sm = calc_lifts_data(
    pdp_plot_objs_sm, feature_importance_list_sm, 20
)


def exec_summ(churn_per_delta_dict):
    """Extract info to form executive summary table."""
    churn_abs_range_cutoff = 0.005
    max_seg_churn_dict = {}
    for feat, segmentlist in churn_per_delta_dict.items():  # pragma: no cover
        churn_per_delta_min_idx = np.argmin(
            list(map(lambda x: x["churn_per_delta"], segmentlist))
        )
        max_seg_churn_dict[feat] = segmentlist[churn_per_delta_min_idx]

    return (
        pd.DataFrame(max_seg_churn_dict)
        .T.sort_values("churn_abs_range", ascending=False)
        .assign(
            churn_pct_chg_per_1pct_point_chg=lambda x: x.churn_per_delta
            * x.pct_to_pct_point_factor
        )
        .assign(
            proportion=lambda x: x.apply(
                lambda row: "proportion" in str(row.name), axis=1
            )
        )
        .assign(
            change_unit=lambda x: x.apply(
                lambda row: " percentage point" if row.proportion else "%",
                axis=1,
            )
        )
        .drop(
            [
                "time_spent_1mo_percent_change",
                "mrc_recurring_video_amt_per_hr_spent",
                "first_indv_age",
                "tenure_months",
                "mrc_recurring_video_proportion",
            ]
        )
        .query(f"churn_abs_range >= {churn_abs_range_cutoff}")
        .sort_values("churn_abs_range", ascending=False)[
            [
                "direction",
                "target_zone",
                "segment_lo_value",
                "segment_mid_value",
                "segment_hi_value",
                "churn_per_delta",
                "churn_pct_chg_per_1pct_point_chg",
                "change_unit",
                "proportion",
            ]
        ]
    )


_, _, churn_per_delta_sm = calc_lifts_data(
    pdp_plot_objs_sm, feature_importance_list_sm, 20
)

exec_summ_pdf = exec_summ(churn_per_delta_sm)


feature_descriptions = {
    "tenure_months": "Customer tenure with X1 (months)",
    "first_indv_age": "Age of first individual on the account (years)",
    "mrc_recurring_video_amt_per_hr_spent": "Average recurring charge on video per hour of watch time ($/hr)",
    "mrc_recurring_video_proportion": "Recurring charge on video as a fraction of total monthly charge",
    "tune_time_spent": "Total non-app time spent per household per month (mins)",
    "time_spent_1mo_percent_change": "Month-over-month relative change in X1 total time spent per household",
    "clicks": "Number of total clicks per month per household (clicks)",
    "mainnav_clicks_proportion": "Main Navigation as a fraction of total clicks",
    "altguide_clicks_proportion": "Alternative Guide as a fraction of total clicks",
    "miniguide_clicks_proportion": "Mini-Guide as a fraction of total clicks",
    "MN_guide_clicks_proportion": "Guide feature as a fraction of total Main Navigation usage",
    "MN_saved_clicks_proportion": "Saved feature as a fraction of total Main Navigation usage",
    "MN_ondemand_clicks_proportion": "OnDemand feature as a fraction of total Main Navigation usage",
    "MN_sports_clicks_proportion": "Sports feature as a fraction of total Main Navigation usage",
    "MN_apps_clicks_proportion": "Apps feature as a fraction of total Main Navigation usage",
    "MN_search_clicks_proportion": "Search feature as a fraction of total Main Navigation usage",
    "MN_settings_clicks_proportion": "Settings feature as a fraction of total Main Navigation usage",
    "AG_all_channels_proportion": "All Channels feature as a fraction of total Alternative Guide usage",
    "AG_favorites_proportion": "Favorites feature as a fraction of total Alternative Guide usage",
    "AG_free_to_me_proportion": "Free To Me feature as a fraction of total Alternative Guide usage",
    "AG_hd_proportion": "HD feature as a fraction of total Alternative Guide usage",
    "AG_kids_proportion": "Kids feature as a fraction of total Alternative Guide usage",
    "AG_movies_proportion": "Movies feature as a fraction of total Alternative Guide usage",
    "AG_sports_proportion": "Alt. Guide Sports feature as a fraction of total Alternative Guide usage",
    "AG_trending_proportion": "Trending feature as a fraction of total Alternative Guide usage",
}

n_summary_features = len(exec_summ_pdf)
summary = (
    f"The {n_summary_features} largest opportunites to reduce churn are by:"
)

for idx in range(n_summary_features):  # pragma: no cover
    direction = exec_summ_pdf.iloc[idx].direction
    change = "Decreasing" if direction == "decrease" else "Increasing"
    change_color = "tomato" if direction == "decrease" else "MediumSeaGreen"
    feature_name = exec_summ_pdf.iloc[idx].name
    description = (
        feature_descriptions.get(feature_name)[0].lower()
        + feature_descriptions.get(feature_name)[1:]
    )
    description = re.sub(r"\((.*?)\)", "", description)
    unit = re.search(r"\((.*?)\)", feature_descriptions.get(feature_name))
    unit = unit.group(1) if unit else ""
    segment_lo_value = exec_summ_pdf.iloc[idx].segment_lo_value
    segment_hi_value = exec_summ_pdf.iloc[idx].segment_hi_value
    churn_reduction_rate = (
        exec_summ_pdf.iloc[idx].churn_pct_chg_per_1pct_point_chg
        if exec_summ_pdf.iloc[idx].proportion
        else exec_summ_pdf.iloc[idx].churn_per_delta
    )
    change_unit = exec_summ_pdf.iloc[idx].change_unit

    line = f"""\n\n{description} in the range between {float(f'{segment_lo_value:.2g}'):,g} and {float(f'{segment_hi_value:.2g}'):,g} {unit}  (churn reduction rate: {churn_reduction_rate:.2f}% per 1{change_unit} {direction} of the feature) \n"""

    summary += line


#' ##### <%= print(summary) %>

#' ------
#' ### Results:

#' ------
#' ##### AUC: Top-Model: 0.694, Sub-Model: 0.679

#' ------
#' ### Feature Importances

#%%+ echo=False, complete=True, include=True, fig=True, results='hidden'
with tempfile.TemporaryDirectory() as temp_dir:
    importances_img_filename = "feature_importances.png"
    importances_img_path = artifact_location / importances_img_filename
    dbutils.fs.cp(str(importances_img_path), "file:" + temp_dir)
    plt.axis("off")
    plt.tight_layout()
    plt.imshow(mpimg.imread(str(Path(temp_dir) / importances_img_filename)))

#' ------
#' ### Partial Dependence Plots

#%%+ echo=False, complete=True, include=True, fig=True, results='hidden'
with tempfile.TemporaryDirectory() as temp_dir:
    importances_img_filename = "feature_pdp.png"
    importances_img_path = artifact_location / importances_img_filename
    dbutils.fs.cp(str(importances_img_path), "file:" + temp_dir)
    plt.axis("off")
    plt.tight_layout()
    plt.imshow(mpimg.imread(str(Path(temp_dir) / importances_img_filename)))
