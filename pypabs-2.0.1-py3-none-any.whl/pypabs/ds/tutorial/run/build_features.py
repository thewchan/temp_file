"""Entry point for building model features.

Note:
Other parameters you can pass to ``ff.make_frames()``:
``ff.make_frames(["event_high_level_daily_aggr_part_1",
 "event_high_level_daily_aggr"])``
``ff.make_frames("event_high_level_daily_aggr")``
``ff.make_frames(2)``
``ff.make_frames([0, 1])``
"""
import logging

from pypabs.ds.tutorial.specs.features import (
    customcolumns,
    customtransforms,
    customops,
    customspecs,
)
from pypabs.ds.tutorial.specs.features.meta import META_PARAMS
from pypabs.featurefactory.core import FeatureFactory

logging.basicConfig()
logging.getLogger().setLevel(logging.INFO)
# Set logging level to ERROR to limit logging printout
# For example: logging.getLogger().setLevel(logging.ERROR)

ff_config = {
    "specs_file_path": "ds/tutorial/specs/features",
    # if local file path is given, "from_libary" parameter below needs
    # to be set to False
    # For example: "specs_file_path": "/path/to/folder/containing/yaml/file",
    "specs_file_name": "features.yml",
    "meta_params": META_PARAMS,
    "custom_modules": [customcolumns, customtransforms, customops],
    "custom_specs": customspecs,
    "from_library": True,
}

# Load YAML file by running this line:
ff = FeatureFactory(**ff_config)
# Set feature factory specs to a specific config in collection.
# For example: ff.feat_specs_collection = ff.feat_specs_collection[1:]

# Run this line to start making dataframes based on YAML file:
ff.make_frames()
