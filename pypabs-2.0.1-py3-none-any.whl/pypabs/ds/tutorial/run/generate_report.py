"""Publish report using Pweave."""

import os
import sys
from pathlib import Path
from typing import Optional

REPORT_MODULE = "pypabs.ds.tutorial.run"
REPORT_NAME = "report_template"
OUTPUT_MODULE = "pypabs.ds.tutorial.run.output"
OUTPUT_NAME = "model_report"


def gen_html_report(pypabs_path: Optional[str] = None) -> None:
    """Generate report in html based on Pweave markdown and code in Python script.

    Args:
        pypabs_path (str): Optional. Path to PyPabs library
            Required if PyPabs is not installed locally. Alternatively,
            PyPabs path can be set in PYPABS_PATH environment variable.

    """
    pypabs_path_env = os.environ.get("PYPABS_PATH")

    if pypabs_path:
        sys.path.insert(0, pypabs_path)  # pragma: no cover
    elif pypabs_path_env:
        sys.path.insert(0, pypabs_path_env)  # pragma: no cover

    from pypabs.util.reporting import (  # pylint: disable=C0415
        pweave_html_report,
    )

    pweave_html_report(REPORT_MODULE, REPORT_NAME, OUTPUT_MODULE, OUTPUT_NAME)


if __name__ == "__main__":  # pragma: no cover
    arg1 = str(Path(sys.argv[1]).resolve()) if (len(sys.argv) > 1) else None
    gen_html_report(arg1)
