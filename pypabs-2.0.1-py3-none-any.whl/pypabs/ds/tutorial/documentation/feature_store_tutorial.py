"""Scratch file."""
# pylint: disable=W,C,R
# flake8: noqa

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Feature store methods

from pypabs.featurestore import AxpFeatureStore, memorystore

# List all feature stores
AxpFeatureStore().list()

# Load your AxpFeatureStore
streamstore = AxpFeatureStore("stream_retention_model")

# Show all tables inside your store
streamstore.list()

# Show all features for a particular table
streamstore.list("event_high_level_daily_aggr")
streamstore.list("event_high_level_daily_aggr", show_latest=False)

# Other parameters you can pass to list() method
streamstore.list(local_tz="America/Los_Angeles")
streamstore.list(show_latest=False)
streamstore.list(drop_ffspecs=False)

# Load dataframe from feature store
test_data = streamstore.load_table("event_high_level_daily_aggr")
type(test_data)
test_data.limit(1).toPandas()

# Show datadframe meta info
test_data.info()
test_data.summary_stats
test_data.name
test_data.location
test_data.basePath
test_data.format
print(test_data.ffspecs)

# Example of loading dataframe from memory store (table needs to be in memory store first)
# test_data2 = memorystore.event_lower_level_daily_aggr_part_1

# ***

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# AXP_DATASETS methods
from pypabs import AXP_DATASETS

# Show all AXP datasets
AXP_DATASETS.to_df(sort_by="name")

# Load an AXP dataset
adf = AXP_DATASETS.load("flex_daily_usage_summary")
type(adf)

# Meta data
adf.info()
adf.name
adf.location
adf.basePath
adf.format

# ***
