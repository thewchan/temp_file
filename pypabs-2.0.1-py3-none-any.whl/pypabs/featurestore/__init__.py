"""The ``featurestore`` module contains sub-modules related to different feature stores."""

from pypabs.featurestore.core import AxpFeatureStore

__all__ = ["AxpFeatureStore"]
