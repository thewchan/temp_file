"""Dummy module to be used as a module-wide store for locally checkpointed featureframes."""
