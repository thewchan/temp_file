"""
Contains ``AxpFeatureStore`` class that provides methods to interact with a feature store.

Purpose of AxpFeatureStore is to create a centralized, version-controlled
repository to store features and their meta-data.

"""

from __future__ import annotations

import logging
import os
from typing import Optional, TYPE_CHECKING, Union

import json
import marshmallow_dataclass
import pandas as pd

from pyspark.sql.dataframe import DataFrame
import pyspark.sql.functions as F  # noqa: N812; F is convention
from pyspark.sql import SparkSession, Window
from pypabs.featurefactory.featureframespecs import FeatureFrameSpecs
from pypabs.featurefactory.otherspecs import WriteMode
from pypabs.util.axp_dataset import AxpDataFrame, AxpDatasetSpecs
from pypabs.util.format_pandas_display import set_custom_pandas_display

if TYPE_CHECKING:
    from pypabs.featurefactory.featureframe import FeatureFrame

__all__ = ["AxpFeatureStore"]

spark = SparkSession.builder.getOrCreate()


class AxpFeatureStore:
    """This class provides methods to create and interact with a feature store.

    Class can be instantiated with no arguments, or with the name of the store
    as a string. A new store will be created if no existing store matches the
    given name.

    Attributes:
        summary_stats_location (str): Optional. Path pointing to the S3 location
            that contains the summary statistics for a particular feature store.

    Methods:
        load_store: Initialize object to a specific store given storename.
        save: Save featureframe to AxpFeatureStore on DeltaLake/S3.
        load_table: Return table as AxpDataFrame object.
        get_raw_meta: Return PySpark dataframe of raw meta data from store.
        list_stores: Return Pandas dataframe listing of all existing stores.
        list_tables: Return Pandas dataframe listing all tables in a store.
        list: Return Pandas dataframe of store meta data.

    Args:
        storename (str): Optional. Name of the store.

    """

    _AFS_LOCATION = r"s3a://axp-feature-store/"
    _META_LOCATION = r"s3a://axp-feature-store/_meta"
    _SUMMARY_STATS_FOLDER = "_summary_stats"

    _storename: Optional[str] = None
    _store_location: Optional[str] = None
    summary_stats_location: Optional[str] = None

    # Set Pandas display format
    set_custom_pandas_display()

    def __init__(self, storename: Optional[str] = None) -> None:
        """Initialize feature store.

        Note:
            If storename isn't provided, an empty AxpFeatureStore object that
            is not initialized with any feature store will be created.

        Args:
            storename (str): Optional. Name of feature store. A new store will
            be created if storename doesn't match any existing ones.

        """
        self._storename = storename
        if storename:
            self._store_location = os.path.join(self._AFS_LOCATION, storename)
            self._summary_stats_location = os.path.join(
                self._store_location, self._SUMMARY_STATS_FOLDER
            )

    def load_store(self, storename: str) -> AxpFeatureStore:
        """Initialize featurestore given storename.

        Args:
            storename (str): Name of feature store. A new store will be created
                if storename doesn't match any existing ones.

        Returns:
            self of AxpFeatureStore class.

        """
        self.__init__(storename)
        return self

    def _write_meta(self, featureframe: FeatureFrame) -> None:
        """Write meta data to feature store.

        Args:
            featureframe (FeatureFrame): FeatureFrame object to be saved to feature store.

        Returns:
            None.

        """
        logging.info("Writing meta information to feature store...")

        table_name = featureframe.destination.table_name
        afs_columns = ["featurestore", "table"]
        afs_values = [(self._storename, table_name)]
        afs_meta = spark.createDataFrame(afs_values, afs_columns)
        afs_meta = afs_meta.withColumn("last_updated", F.current_timestamp())

        # Serializing ffspecs to JSON string
        class _CustomOpsEncoder(json.JSONEncoder):
            """Custom JSONEncoder."""

            def default(self, o):
                """Define JSONEncoder when object is of type customspecs."""
                if "customspecs" in str(type(o)):
                    return o.__dict__
                return json.JSONEncoder.default(self, o)

        schema = marshmallow_dataclass.class_schema(FeatureFrameSpecs)()
        ffspecs_json = schema.dumps(featureframe.ffspecs, cls=_CustomOpsEncoder)
        afs_meta = afs_meta.withColumn("ffspecs", F.lit(ffspecs_json))

        afs_meta = (
            afs_meta.coalesce(1)
            .write.partitionBy("featurestore")
            .mode("append")
            # .mode("overwrite")
            # .option("overwriteSchema", "true")
            .format("delta")
            .save(self._META_LOCATION)
        )
        logging.info("Done.")

    def _write_summary_stats(self, featureframe: FeatureFrame) -> None:
        """Write summary statistics to feature store.

        Args:
            featureframe (FeatureFrame): FeatureFrame object to be saved to feature store.

        Returns:
            None.

        """
        logging.info("Writing summary statistics to feature store...")

        table_name = featureframe.destination.table_name
        summary_stats = featureframe.summary_stats

        if summary_stats is None:
            # Even when summary_stats is disabled, we still need to populate
            # table and last_updated columns to keep track of the update
            columns = ["table"]
            vals = [(table_name,)]
            store_meta = spark.createDataFrame(vals, columns).withColumn(
                "last_updated", F.current_timestamp()
            )
        else:
            # Convert summary_stats to PySpark DataFrame
            summ = spark.createDataFrame(featureframe.summary_stats)
            # Add backticks because of special characters in column names.
            summ_columns = list(
                "".join(["`", elem, "`"]) for elem in summ.columns
            )
            store_meta = (
                summ.withColumn("table", F.lit(table_name))
                .select(["table"] + summ_columns)
                .withColumn("last_updated", F.current_timestamp())
            )
        store_meta = (
            store_meta.coalesce(1)
            .write.partitionBy("table")
            .mode("append")
            # .mode("overwrite")
            # .option("overwriteSchema", "true")
            .format("delta")
            .save(self._summary_stats_location)
        )
        logging.info("Done.")

    def _write_dataframe(self, featureframe: FeatureFrame) -> None:
        """Write dataframe to feature store.

        Args:
            featureframe (FeatureFrame): FeatureFrame object to be saved to feature store.

        Returns:
            None.

        """
        logging.info("Writing dataframe to feature store...")

        destination = featureframe.destination
        table = featureframe
        table_name = destination.table_name
        table_location = os.path.join(self._store_location, table_name)
        partition_size = destination.partition_size
        repartition_or_coalesce = destination.repartition_or_coalesce
        partition_cols = destination.partition_by
        zorder_by = destination.zorder_by
        write_mode = destination.write_mode
        overwrite_schema_value = "true"

        if write_mode == WriteMode.APPEND:
            overwrite_schema_value = "false"

        if (write_mode == WriteMode.OVERWRITE) and partition_size:
            table.localCheckpoint()
            table = getattr(table, repartition_or_coalesce.value)(
                partition_size
            )

        if partition_cols:
            table = (
                table.write.partitionBy(partition_cols)
                .mode(write_mode.value)
                .option("overwriteSchema", overwrite_schema_value)
                .format("delta")
            )
        else:
            table = (
                table.write.mode(write_mode.value)
                .option("overwriteSchema", overwrite_schema_value)
                .format("delta")
            )

        table.save(table_location)

        if zorder_by:
            if isinstance(zorder_by, list):
                spark.sql(
                    f"OPTIMIZE delta.`{table_location}` ZORDER BY ({', '.join(zorder_by)})"
                )
            else:
                spark.sql(
                    f"OPTIMIZE delta.`{table_location}` ZORDER BY ({zorder_by})"
                )
        logging.info("Done.")

    def save(self, featureframe: FeatureFrame) -> None:  # pylint: disable=R0915
        """Save featureframe to AXP Feature Store on DeltaLake/S3.

        Args:
            featureframe (FeatureFrame): FeatureFrame object to be saved to feature store.

        Returns:
            None.

        """
        if not self._store_location:
            logging.info(
                "Please initilize AxpFeatureStore with init_store(storename) method."
            )
            raise Exception(
                "Saving to feature store failed. Feature store location \
                undefined. 'feature_store' field in destination section of yaml \
                file may be missing."
            )

        self._write_dataframe(featureframe)
        self._write_summary_stats(featureframe)
        self._write_meta(featureframe)

    def load_table(self, table_name: str) -> Union[AxpDataFrame, None]:
        """Return table from feature store given table name.

        Args:
            table_name (str): Optional. Name of a table in the feature store.

        Returns:
            An AxpDataFrame object, which inherits Pyspark DataFrame.

        """

        def load_ffspecs(ffspecs_json: str) -> FeatureFrameSpecs:
            """Take featureframe specs as a JSON string and return a FeatureFrameSpecs object."""
            schema = marshmallow_dataclass.class_schema(FeatureFrameSpecs)()
            return schema.loads(ffspecs_json, partial=True, unknown="INCLUDE")

        if not self._store_location:
            logging.info(
                "Please initilize AxpFeatureStore with load_store(storename) method."
            )
            return None

        table_location = os.path.join(self._store_location, table_name)
        try:
            sdf = spark.read.format("delta").load(table_location)
        except Exception as exc:
            raise Exception(f"Error loading {table_location}") from exc

        specs = AxpDatasetSpecs(
            name=table_name, location=table_location, format="delta"
        )
        # Load summary statistics
        summary_stats = self.list(table_name).drop(columns=["last_updated"])

        # Load ffspecs meta
        meta_pdf = self.list_tables(show_latest=True, drop_ffspecs=False)
        ffspecs_series = meta_pdf[
            meta_pdf.table == table_name
        ].ffspecs.reset_index(drop=True)
        if len(ffspecs_series) == 0:  # if table_name not found
            ffspecs = None
        else:
            ffspecs_json = ffspecs_series[0]
            ffspecs = load_ffspecs(ffspecs_json)

        return AxpDataFrame(
            df=sdf, axpspecs=specs, ffspecs=ffspecs, summary_stats=summary_stats
        )

    def get_raw_meta(self) -> DataFrame:
        """Return PySpark dataframe of raw meta data from store.

        Note:
            Method is overloaded. It returns a dataframe of all metadata for
            AXP Feature Store if object isn't initialized with a feature store.
            Otherwise it returns a dataframe of all metadata for the feature
            store.

        Returns:
            A Pyspark DataFrame.

        """
        if not self._storename:
            return spark.read.format("delta").load(self._META_LOCATION)
        return spark.read.format("delta").load(self._summary_stats_location)

    def list_stores(
        self, show_latest=True, local_tz: str = "America/New_York"
    ) -> pd.DataFrame:
        """Show a summary of all existing stores inside the AXP Feature Store.

        Args:
            show_latest (bool): Optional. If True, only show metadata with the
                latest timestamp, if multiple versions exist. Default is True.
            local_tz (str): A string representing a pytz timezone.
                Timestamp will be provided in the time zone provided by local_tz.
                Default is 'America/New_York'.
            drop_ffspecs (bool): Optional. If True, result will not include
                column containing featureframe specifications meta data. Set to
                True by default.

        Returns:
            Pandas dataframe.

        """
        sdf = (
            spark.read.format("delta")
            .load(self._META_LOCATION)
            .select("featurestore", "last_updated")
        )

        if not show_latest:
            result = sdf.orderBy(F.col("last_updated").desc(), "featurestore")
        else:
            _w = Window.partitionBy(["featurestore"]).orderBy(
                F.col("last_updated").desc()
            )
            result = (
                sdf.withColumn("latest", F.row_number().over(_w))
                .filter(F.col("latest") == 1)
                .drop("latest")
                .orderBy("featurestore")
            )
        result = result.withColumn(
            "last_updated", F.from_utc_timestamp("last_updated", local_tz)
        )
        return result.toPandas()

    def list_tables(
        self,
        show_latest: bool = True,
        local_tz: str = "America/New_York",
        drop_ffspecs: bool = True,
    ) -> pd.DataFrame:
        """Show a summary of all the tables in the store if store is initialized.

        Otherwise show a summary of all stores inside the AXP Feature Store.

        Note:
            This method is overloaded:
              - If object isn't initialized with a storename, it will return
                a summary of store names. Equivalent to calling list_stores() method.

        Args:
            show_latest (bool): Optional. If True, only show metadata with the
                latest timestamp, if multiple versions exist. Default is True.
            local_tz (str): Optional. A string representing a pytz timezone.
                Timestamp will be provided in the time zone provided by local_tz.
                Default is 'America/New_York'.
            drop_ffspecs (bool): Optional. If True, result will not include
                column containing featureframe specifications meta data. Set to
                True by default.

        Returns:
            Pandas dataframe.

        """
        if not self._storename:
            return self.list_stores(show_latest, local_tz)

        sdf = (
            spark.read.format("delta")
            .load(self._META_LOCATION)
            .filter(F.col("featurestore") == self._storename)
            .drop("featurestore")
        )
        if drop_ffspecs:
            sdf = sdf.drop("ffspecs")

        if not show_latest:
            result = sdf.orderBy(F.col("last_updated").desc(), "table")
        else:
            _w = Window.partitionBy(["table"]).orderBy(
                F.col("last_updated").desc()
            )
            result = (
                sdf.withColumn("latest", F.row_number().over(_w))
                .filter(F.col("latest") == 1)
                .drop("latest")
                .orderBy("table")
            )
        result = result.withColumn(
            "last_updated", F.from_utc_timestamp("last_updated", local_tz)
        )
        return result.toPandas()

    def list(
        self,
        table_name: Optional[str] = None,
        show_latest: bool = True,
        local_tz: str = "America/New_York",
        drop_ffspecs: bool = True,
    ) -> pd.DataFrame:
        """Show summary of the content for a store or a table.

        Note:
            This method is overloaded:
              - If object isn't initialized with a storename, it will return
                a summary of store names. Equivalent to calling list_stores() method.
              - If object is initialized with a store AND table name is NOT
                provided, it will return a summary of table names. Equivalent to
                calling list_tables()
              - If object is initialized with a store AND table name is
                provided, it will return a summary of features in that table.

        Args:
            table_name (str): Optional. Name of a table in the feature store.
            show_latest (bool): Optional. If True, only show metadata with the
                latest timestamp, if multiple versions exist. Default is True.
            local_tz (str): Optional. A string representing a pytz timezone.
                Timestamp will be provided in the time zone provided by local_tz.
                Default is 'America/New_York'.
            drop_ffspecs (bool): Optional. If True, result will not include
                column containing featureframe specifications meta data. Set to
                True by default.

        Returns:
            Pandas dataframe.

        """
        if not self._storename:
            return self.list_stores(show_latest, local_tz)

        if not table_name:
            return self.list_tables(show_latest, local_tz, drop_ffspecs)

        sdf = (
            spark.read.format("delta")
            .load(self._summary_stats_location)
            .filter(F.col("table") == table_name)
        )

        if not show_latest:
            result = sdf.orderBy(F.col("last_updated").desc(), "feature")
        else:
            latest_timestamp = sdf.select(F.max("last_updated")).collect()[0][0]
            result = sdf.filter(
                F.col("last_updated") == latest_timestamp
            ).orderBy("feature")

        result = result.withColumn(
            "last_updated", F.from_utc_timestamp("last_updated", local_tz)
        )
        return result.toPandas()
