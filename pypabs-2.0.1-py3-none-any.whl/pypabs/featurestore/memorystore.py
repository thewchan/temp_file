"""Dummy module to be used as a module-wide memory store."""
