"""The ``core`` module provides core feature factory functions."""

import logging
from datetime import datetime, timedelta
from typing import List, Optional, Union

import jinja2
import marshmallow_dataclass
from tqdm import tqdm
import yaml

import pypabs.util.yaml_funcs as yaml_funcs
from pypabs.featurefactory.featureframe import FeatureFrame
from pypabs.featurefactory.featureframespecs import (
    FeatureFrameSpecs,
    FeatureFrameSpecsCollection,
)

__all__ = ["FeatureFactory"]


class FeatureFactory:
    """Purpose of ``FeatureFactory`` is to make features and store them in feature store.

    Class can be instantiated with no arguments, or with path and name of
    specification YAML file, and corresponding dictionary of meta parameters.

    All features are created based on information in specification file.

    Attributes:
        feat_specs_preprocessed (List[Dict]): Preprocessed list of dictionaries
            returned from loading specification YAML file.
        feat_specs_collection (``FeatureFrameSpecsCollection``): List of
            ``FeatureFrameSpecs`` objects, which contain information required
            to make feature frames.

    Methods:
        load_specs_from_library: Load feature specs YAML from package.
        load_specs_from_filesystem: Load feature specs YAML from local filesystem.
        make: Make FeatureFrames according to list of specs.
        list_specs: Return list of specification short names.
        show_specs: Show detailed specifications given short name or index.

    Args:
        spec_file_path (str): Optional. Path to specification file.
        specs_file_name: (str): Optional. Specification name.
        meta_params (dict): Dictionary containing values for global
            objects in first document in YAML file.
        custom_modules (List(object)): List of modules that provides mixin classes
            to create custom columns, custom transforms and custom ops.
        custom_specs (object): The module that provides the schema definitions
            for all the custom ops.
        from_library (bool): True = load spec file from PyPabs library;
            False = load spec file from local file system.

    """

    feat_specs_preprocessed: Optional[List[dict]] = None
    feat_specs_collection: Optional[FeatureFrameSpecsCollection] = None

    def __init__(  # pylint: disable=too-many-arguments
        self,
        specs_file_path: Optional[str] = None,
        specs_file_name: Optional[str] = None,
        meta_params: Optional[dict] = None,
        custom_modules: Optional[List[object]] = None,
        custom_specs: Optional[object] = None,
        from_library: Optional[bool] = True,
    ) -> None:
        """
        Initialize class with specification file and meta parameters.

        Args:
            spec_file_path (str): Optional. Path to specification file.
            specs_file_name: (str): Optional. Specification name.
            meta_params (dict): Dictionary containing values for global
                objects in first document in YAML file.
            custom_modules (List(object)): List of modules that provides mixin
                classes to create custom columns, custom transforms and custom ops.
            custom_specs (object): The module that provides the schema definitions
                for all the custom ops.
            from_library (bool): True = load spec file from PyPabs library;
                False = load spec file from local filesystem.

        """
        load_params = [specs_file_path, specs_file_name, meta_params]
        self.custom_modules = custom_modules
        self.custom_specs = custom_specs

        if all(load_params):
            if from_library:
                self.load_specs_from_library(*load_params)
            else:
                self.load_specs_from_filesystem(*load_params)

    def _load_schema_for_single_custom_op(
        self, op_name: str, op_params: dict
    ) -> object:
        """Create custom schema object by applying optional custom schema to op_params.

        Args:
            op_name (str): Name of custom op.
            op_params (dict): Dictionary of parameters of custom_op.

        Returns:
            Either an object of custom schema specs class or original op_params
            dictionary if optional custom schema is not defined.

        """
        # schema name is Title case of custom op name
        schema_name = op_name.replace("_", " ").title().replace(" ", "")

        # if optional schema is defined for the particular custom_op in custom_specs
        if hasattr(self.custom_specs, schema_name):
            schema = marshmallow_dataclass.class_schema(
                getattr(self.custom_specs, schema_name)
            )()
            logging.info("Custom specs for %s loaded.", op_name)
            return schema.load(op_params)  # return type is object

        # otherwise specs is original dictionary from YAML
        return op_params  # return type is dict

    def _load_schema_for_custom_ops(self) -> None:
        """Apply custom schema and create object for all custom ops if exist."""
        if not self.custom_specs:
            return

        for specs in self.feat_specs_collection:
            if not specs.transform_pipe:
                continue
            for elem in specs.transform_pipe:
                if elem.stage == "custom_ops":
                    custom_ops_specs = {}
                    for op_name, op_params in elem.custom_ops.items():
                        custom_ops_specs[
                            op_name
                        ] = self._load_schema_for_single_custom_op(
                            op_name, op_params
                        )
                    elem.custom_ops = custom_ops_specs

    def _load_feat_specs_collection(self) -> None:
        """Create feature specs collection from dictionary by applying schema."""
        if len(self.feat_specs_preprocessed) <= 1:
            logging.warning("Yaml file contains 0 feature specs.")

        schema = marshmallow_dataclass.class_schema(FeatureFrameSpecs)()
        specs_collection = []
        idx = 0
        for feat_specs_dict in self.feat_specs_preprocessed[1:]:
            if not feat_specs_dict:
                logging.error(
                    "yaml.load_all(yaml_specs[%(idx)s]) returned null, implying the YAML document no.%(idx)s (starting from 0, excluding the global document) is empty. There are probably some structural issues in the YAML file, for example, there could be an additional '---' document separator between documents no.%(idx-1)s and no.%(idx)s.",
                    {"idx-1": idx - 1, "idx": idx},
                )
                raise Exception("Null YAML document")

            logging.info("loading %s...", feat_specs_dict.get("short_name"))
            specs_collection.append(schema.load(feat_specs_dict))
            idx += 1
        self.feat_specs_collection = FeatureFrameSpecsCollection(
            specs_collection
        )
        self._load_schema_for_custom_ops()
        logging.info(
            "Done. %s feature specs successfully loaded.",
            len(self.feat_specs_collection),
        )

    def _load_specs_from_rendered_template(self, yaml_specs: str) -> None:
        """Create dictionary from pure yaml template after Jinja2 rendition."""
        yaml_specs_lines = [
            line + "\n" for line in yaml_specs.split("\n") if line
        ]
        meta_doc = yaml_funcs.get_nth_yaml_doc(
            yaml_specs_lines, 1
        )  # meta_doc is the first document

        custom_loader = yaml_funcs.global_tag_customloader(meta_doc)
        self.feat_specs_preprocessed = list(
            yaml.load_all(yaml_specs, Loader=custom_loader)
        )
        logging.info("YAML file loaded.")
        self._load_feat_specs_collection()

    def load_specs_from_filesystem(
        self, path: str, filename: str, meta_params: dict = None
    ) -> None:
        """Load feature specs YAML file from filesystem.

        Args:
            path (str): Path to file in package resource.
            filename (str): Filename of specification YAML file.
            meta_params (dict): Optional. Values for meta parameters defined in
                specification template

        """
        meta_params = meta_params or {}
        yaml_specs = (
            jinja2.Environment(
                loader=jinja2.FileSystemLoader(path),
                cache_size=0,
                autoescape=True,
                auto_reload=True,
            )
            .get_template(filename)
            .render(meta_params)
        )
        self._load_specs_from_rendered_template(yaml_specs)

    def load_specs_from_library(
        self, path: str, filename: str, meta_params: dict = None
    ) -> None:
        """Load feature specs YAML file from package.

        Args:
            path (str): Path to file in package resource. Root is pypabs.
            filename (str): Filename of specification YAML file.
            meta_params (dict): Optional. Values for meta parameters defined in
                specification template

        """
        meta_params = meta_params or {}
        yaml_specs = (
            jinja2.Environment(
                loader=jinja2.PackageLoader("pypabs", path),
                cache_size=0,
                autoescape=True,
                auto_reload=True,
            )
            .get_template(filename)
            .render(meta_params)
        )
        self._load_specs_from_rendered_template(yaml_specs)

    def _fetch_mixin_classes(
        self, mixin_cls_name: str
    ) -> Union[List[object], None]:
        """Fetch all mixin classes associated with mixin_cls_name.

        Mixin classes could be in any or all these three modules: customcolumns,
        customtransforms, customops.

        Each featureframe has its own associated mixin classes. To find them,
        we need to check their names. Mixin classes have special names that
        correspond to the featureframe shortname converted to TitleCase and
        appended with "Mixin".

        Args:
            mixin_cls_name (str): Featureframe shortname converted to TitleCase
                and appended with "Mixin"

        Returns:
            List of classes.

        """
        if not self.custom_modules:
            return None

        mixin_classes = []

        for module in self.custom_modules:
            if module.__name__.split(".")[-1] == "customops":
                mixin_cls = getattr(module, "CustomOpsMixin", None)
                if mixin_cls:
                    mixin_classes.append(mixin_cls)

            mixin_cls = getattr(module, mixin_cls_name, None)
            if mixin_cls:
                mixin_classes.append(mixin_cls)

        return mixin_classes

    def _make_frame(self, ff_specs: FeatureFrameSpecs) -> None:
        """Contain the actual logic to make a featureframe given ff_specs.

        Args:
            ff_specs (FeatureFrameSpecs): Specification objection for
                generating the featureframe.

        """
        # Mixin class name is obtained by converting short_name in
        # snake_case to TitleCase with "Mixin" appended.
        mixin_cls_name = (
            ff_specs.short_name.replace("_", " ").title().replace(" ", "")
            + "Mixin"
        )

        mixin_classes = self._fetch_mixin_classes(mixin_cls_name)

        # Create new FeatureFrame class with mixin classes
        if mixin_classes:
            FF = type(  # pylint: disable=C0103
                "FeatureFrame_" + mixin_cls_name,
                (*mixin_classes, FeatureFrame),
                {},
            )
        else:
            # No need to add custom columns mixin
            FF = FeatureFrame

        # Run procedure to make feature frame
        FF(ff_specs).make_frame()

    def _make_frame_given_shortname(self, short_name: str) -> None:
        """Fetch specifications associated with short_name and call _make_frame().

        Args:
            short_name (str): Shortname of a FeatureFrameSpecs object.

        """
        for ff_specs in self.feat_specs_collection:
            if ff_specs.short_name == short_name:
                self._make_frame(ff_specs)

    def make_frames(
        self,
        short_name_or_idx: Optional[
            Union[int, str, List[int], List[str]]
        ] = "all",
    ) -> bool:
        """Make featureFrames given shortname of specs or their index.

        Args:
            short_name_or_idx (int, str, List[int] or List[str]). Optional.
                Short_name of featureframe, or an integer specifying the index
                of the spec in the list of featureframe specs, or a list of a
                combination of them.

        Returns:
            True if successful; False otherwise.

        """
        start_time = datetime.now()
        logging.info("Start time is: %s", start_time.strftime("%H:%M:%S"))

        if short_name_or_idx == "all":
            for ff_specs in tqdm(self.feat_specs_collection):
                self._make_frame(ff_specs)

        elif isinstance(short_name_or_idx, str):
            self._make_frame_given_shortname(short_name_or_idx)

        elif isinstance(short_name_or_idx, int):
            self._make_frame(self.feat_specs_collection[short_name_or_idx])

        elif isinstance(short_name_or_idx, list):
            for elem in tqdm(short_name_or_idx):
                if isinstance(elem, str):
                    self._make_frame_given_shortname(elem)
                elif isinstance(elem, int):
                    self._make_frame(self.feat_specs_collection[elem])
                else:
                    print(
                        f"Invalid input: {elem}. Input needs to be List[str] or List[int]."
                    )
                    return False
        else:
            print(
                "Invalid input. Input needs to be int, str, List[str] or List[int]."
            )
            return False
        finish_time = datetime.now()
        time_elapsed = round((finish_time - start_time) / timedelta(minutes=1))
        logging.info("Finish time is: %s", finish_time.strftime("%H:%M:%S"))
        logging.info("Time elasped: %s mins", time_elapsed)
        return True

    def list_specs(self) -> List[str]:
        """Return list of specs short names."""
        return [ff_specs.short_name for ff_specs in self.feat_specs_collection]

    def _show_specs_given_shortname(self, short_name):
        """Fetch and print specifications object associated with short_name.

        Args:
            short_name (str): Shortname of a FeatureFrameSpecs object.

        """
        return [
            print(ff_specs)
            for ff_specs in self.feat_specs_collection
            if ff_specs.short_name == short_name
        ]

    def show_specs(
        self,
        short_name_or_idx: Optional[
            Union[int, str, List[int], List[str]]
        ] = None,
    ) -> None:
        """Print specs details.

        Args:
            short_name_or_idx (int, str, List[int] or List[str]). Optional.
                Short_name of featureframe, or an integer specifying the index
                of the spec in the list of featureframe specs, or a list of a
                combination of them.

        """
        if short_name_or_idx is None:
            print(self.feat_specs_collection)

        elif isinstance(short_name_or_idx, str):
            self._show_specs_given_shortname(short_name_or_idx)

        elif isinstance(short_name_or_idx, int):
            print(self.feat_specs_collection[short_name_or_idx])

        elif isinstance(short_name_or_idx, list):
            for elem in short_name_or_idx:
                if isinstance(elem, str):
                    self._show_specs_given_shortname(elem)
                elif isinstance(elem, int):
                    print(self.feat_specs_collection[elem])
                else:
                    print(
                        f"Invalid input: {elem}. Input needs to be List[str] or List[int]."
                    )
        else:
            print(
                "Invalid input. Input needs to be int, str, List[str] or List[int]."
            )
