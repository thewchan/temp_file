"""``FeatureFrameSpecs`` contains FeatureFrameSpecs and FeatureFrameSpecsCollection classes."""

from collections import UserList
from dataclasses import dataclass, field
from typing import List, Optional, Union

from pypabs.featurefactory.otherspecs import (
    RepartitionMode,
    StoreType,
    WriteMode,
    StageType,
    DropnaHowType,
)
from pypabs.featurefactory.calcfeatures.standardspecs import (
    CalcFeatDefaults,
    Ratio,
    Lag,
    Average,
    PercentChange,
    RateOfChange,
    RateOfPctChange,
    Explode,
)
from pypabs.util.pprint_mixins import PPrintMixin, PPrintListMixin

__all__ = [
    "FeatureFrameSpecs",
    "FeatureFrameSpecsCollection",
]


@dataclass
class FeatureFrameSpecs(PPrintMixin):  # pylint: disable=R0902
    """Define schema for the specifications used in construction of feature frame.

    The specification YAML file will be used to instantiate this class.

    Attributes:
        short_name (str): Short name for the feature frame.
        description (str): Optional. Description of feature frame.
        source (_Source): Schema to define data source.
        destination (_Destination): Optional. Schema to define destination
            options.
        summary_meta (_SummaryMeta): Optional. Schema to define summary
            statistics calculation settings.
        transform_pipe  (_TransformOps): Optional. Schema to define each stage
            of the transform pipeline performed on dataframe.

    """

    @dataclass
    class _Source(PPrintMixin):
        """Schema for source attribute."""

        store_type: StoreType = field(metadata={"by_value": True})
        table_name: str
        feature_store: Optional[str] = None

    @dataclass
    class _Destination(
        PPrintMixin
    ):  # pylint: disable=too-many-instance-attributes
        """Schema for destination attribute."""

        store_type: StoreType = field(metadata={"by_value": True})
        table_name: str
        feature_store: Optional[str] = None
        partition_size: Optional[int] = None
        repartition_or_coalesce: Optional[RepartitionMode] = field(
            default=RepartitionMode.COALESCE, metadata={"by_value": True}
        )
        partition_by: Optional[Union[str, List[str]]] = None
        zorder_by: Optional[Union[str, List[str]]] = None
        write_mode: Optional[WriteMode] = field(
            default=WriteMode.OVERWRITE, metadata={"by_value": True}
        )

    @dataclass
    class _SummaryMeta(
        PPrintMixin
    ):  # pylint: disable=too-many-instance-attributes
        """Schema for summary_meta attribute."""

        enable: Optional[bool] = True
        subset: Optional[List[str]] = None

    @dataclass
    class _TransformPipe(
        PPrintMixin
    ):  # pylint: disable=too-many-instance-attributes
        """
        Contains schema for the specifications for each stage of transform_pipe.

        Attributes:
            stage: StageType. Could be any one of: joins, filter, custom_columns,
                groupby, drop_columns, rename_columns, drop_duplicates, fillna,
                dropna, sample, custom_transforms, custom_ops,
                calc_feat_defaults, calc_features, select, orderby
            joins: Optional[List[_Joins]]. Join specifications.
            filter: Optional[str]. Filter specs.
            custom_columns: Optional[List[str]]. List of custom column names.
            groupby: Optional[_Groupby]. Groupby specifications.
            drop_columns: Optional[List[str]]. List of column names.
            rename_columns: Optional[List[_RenameColumns]] = List of
                rename_column specs.
            drop_duplicates: Optional[_DropDuplicates]. Drop_duplicates specs.
            fillna: Optional[_FillNa]. Fillna specs.
            dropna: Optional[_DropNa]. Dropna specs.
            sample: Optional[_Sample]. Sample specs.
            custom_transforms: Optional[List[str]]. List of custom transform
                names.
            custom_ops: Optional[dict]. Dictionary of custom_ops specs.
            calc_feat_defaults: Optional[List[CalcFeatDefaults]]. List of
                calculated feature defaults specs.
            calc_features: Calculated features specs.
            select: Optional[_Select]. Feature selection specs.
            orderby: Optional[_Orderby]. Orderby specs.

        """

        @dataclass
        class _Joins(PPrintMixin):
            """Schema for joins attribute."""

            store_type: StoreType = field(metadata={"by_value": True})
            table_name: str
            join_type: str
            join_on: List[str]
            feature_store: Optional[str] = None

        @dataclass
        class _Groupby(PPrintMixin):  # pylint: disable=C0115
            """Schema for groupby attribute."""

            @dataclass
            class _Pivot(PPrintMixin):
                """Schema for pivot attribute."""

                column: str
                values: Optional[List[str]] = None

            @dataclass
            class _AggFunction(PPrintMixin):
                """Schema for agg_function attribute."""

                agg_type: Optional[List[str]] = None
                agg_columns: Optional[List[str]] = None
                aliases: Optional[List[str]] = None

            pivot: Optional[_Pivot] = None
            keys: Optional[List[str]] = None
            agg_function: Optional[_AggFunction] = None
            where_string: Optional[str] = None

        @dataclass
        class _RenameColumns(PPrintMixin):  # pylint: disable=C0115
            """Schema for rename_column attribute."""

            existing: str
            new: str

        @dataclass
        class _DropDuplicates(PPrintMixin):  # pylint: disable=C0115
            """Schema for drop_duplicates attribute."""

            enable: Optional[bool] = False
            subset: Optional[List[str]] = None

        @dataclass
        class _FillNa(PPrintMixin):  # pylint: disable=C0115
            """Schema for fillna attribute."""

            value: Optional[Union[str, int, float, bool]] = None
            subset: Optional[List[str]] = None

        @dataclass
        class _DropNa(PPrintMixin):  # pylint: disable=C0115
            """Schema for dropna attribute."""

            enable: Optional[bool] = False
            how: Optional[DropnaHowType] = field(
                default=DropnaHowType.ANY, metadata={"by_value": True}
            )
            thresh: Optional[int] = None
            subset: Optional[List[str]] = None

        @dataclass
        class _Sample(PPrintMixin):  # pylint: disable=C0115
            """Schema for sample attribute."""

            fraction: Optional[float] = None
            seed: Optional[int] = None
            with_replacement: Optional[bool] = False

        @dataclass
        class _Select(PPrintMixin):  # pylint: disable=C0115
            """Schema for select attribute."""

            keys: Optional[List[str]] = None
            features: Optional[List[str]] = field(default_factory=lambda: ["*"])

        @dataclass
        class _Orderby(PPrintMixin):
            """Schema for orderby attribute."""

            columns: Optional[Union[str, List[str]]] = None
            ascending: Optional[Union[bool, List[bool]]] = True

        stage: StageType = field(metadata={"by_value": True})
        joins: Optional[List[_Joins]] = None
        filter: Optional[str] = None
        custom_columns: Optional[List[str]] = None
        groupby: Optional[_Groupby] = None
        drop_columns: Optional[List[str]] = None
        rename_columns: Optional[List[_RenameColumns]] = None
        drop_duplicates: Optional[_DropDuplicates] = None
        fillna: Optional[_FillNa] = None
        dropna: Optional[_DropNa] = None
        sample: Optional[_Sample] = None
        custom_transforms: Optional[List[str]] = None
        custom_ops: Optional[dict] = None
        calc_feat_defaults: Optional[List[CalcFeatDefaults]] = None
        calc_features: Optional[
            List[
                Union[
                    Ratio,
                    Lag,
                    Average,
                    PercentChange,
                    RateOfChange,
                    RateOfPctChange,
                    Explode,
                ]
            ]
        ] = None
        select: Optional[_Select] = None
        orderby: Optional[_Orderby] = None

    short_name: str
    source: _Source
    description: Optional[str] = None
    destination: Optional[_Destination] = None
    summary_meta: Optional[_SummaryMeta] = None
    transform_pipe: Optional[List[_TransformPipe]] = None


class FeatureFrameSpecsCollection(  # pylint: disable=too-many-ancestors
    PPrintListMixin, UserList
):
    """Contain a list of FeatureFrameSpecs objects."""
