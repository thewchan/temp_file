"""
Module contains ``StandardMixin`` to provide methods for generating standard calculated features.

The standard calculated features currently are:
    1. ratio
    2. lag
    3. average
    4. percentChange
    5. rateOfChange
    6. rateOfPctChange
    7. explode_outer
    8. explode

The method names are the calculated feature type prefixed by "calc_", e.g.
method name for the calculated feature type "ratio" is "calc_ratio().
"""

from typing import Callable, List, Union

import pyspark.sql.functions as F  # noqa: N812; F is convention
from pyspark.sql import Column
from pyspark.sql.window import Window

from pypabs.featurefactory.calcfeatures.standardspecs import (
    Ratio,
    Lag,
    Average,
    PercentChange,
    RateOfChange,
    RateOfPctChange,
    Explode,
)
from pypabs.featurefactory import functions as fffun


class StandardMixin:  # pylint: disable=too-few-public-methods
    """Define standard calculated features mixin methods."""

    @staticmethod
    def calc_ratio(specs: Ratio) -> List[Column]:
        """Calculate ratio feature based on specs.

        Args:
            specs (Ratio): Object of class `Ratio` containing specifications.

        Returns:
            List of Pyspark Columns.

        """
        return [
            F.when(
                (F.col(specs.numerator).isNotNull())
                & (F.col(specs.denominator) > 0),
                F.least(
                    F.lit(specs.ceiling),
                    F.greatest(
                        F.lit(specs.floor),
                        F.col(specs.numerator) / F.col(specs.denominator),
                    ),
                ),
            )
            .otherwise(F.lit(None))
            .alias(specs.name)
        ]

    @staticmethod
    def calc_lag(specs: Lag) -> List[Column]:
        """Calculate lag feature based on specs.

        Args:
            specs (Lag): Object of class `Lag` containing specifications.

        Returns:
            List of Pyspark Columns.

        """
        result = []
        for lag_points in specs.lag_points:
            specs.name = (
                f"{specs.target}_{lag_points}{specs.unit}_{specs.type.value}"
            )
            specs.lag = lag_points
            pkey = specs.partition_key
            if isinstance(pkey, str):
                _window = Window.partitionBy(pkey)
            else:
                _window = Window.partitionBy([F.col(key) for key in pkey])
            result.append(
                F.lag(specs.target, specs.lag)
                .over(_window.orderBy(specs.order_key))
                .alias(specs.name)
            )
        return result

    @staticmethod
    def calc_average(specs: Average) -> List[Column]:
        """Calculate average feature based on specs.

        Args:
            specs (Average): Object of class `Average` containing specifications.

        Returns:
            List of Pyspark Columns.

        """
        result = []
        pkey = specs.partition_key
        if isinstance(pkey, str):
            _window = Window.partitionBy(pkey)
        else:
            _window = Window.partitionBy([F.col(key) for key in pkey])

        for ep in specs.durations:  # pylint: disable=C0103
            if specs.lag == 0:
                specs.name = (
                    f"{specs.target}_{ep}{specs.unit}_{specs.type.value}"
                )
            else:
                specs.name = f"{specs.target}_{ep}{specs.unit}_{specs.type.value}_{specs.lag}{specs.unit}_lag"  # pylint: disable=C0301

            oldest_point = ep + specs.lag - 1
            _window = _window.orderBy(specs.order_key).rowsBetween(
                -oldest_point, -specs.lag
            )

            data_points = F.collect_list(F.col(specs.target)).over(_window)

            raw_mean = F.when(F.size(data_points) != ep, None).otherwise(
                sum([data_points[x] for x in range(ep)]) / ep
            )

            result.append(
                F.when(
                    raw_mean.isNotNull(),
                    F.least(
                        F.lit(specs.ceiling),
                        F.greatest(F.lit(specs.floor), raw_mean),
                    ),
                )
                .otherwise(F.lit(None))
                .alias(specs.name)
            )
        return result

    @staticmethod
    def calc_percent_change(specs: PercentChange) -> List[Column]:
        """Calculate percent_change feature based on specs.

        Args:
            specs (PercentChange): Object of class `PercentChange` containing specifications.

        Returns:
            List of Pyspark Columns.

        """
        result = []
        pkey = specs.partition_key
        if isinstance(pkey, str):
            _window = Window.partitionBy(pkey)
        else:
            _window = Window.partitionBy([F.col(key) for key in pkey])

        for ep in specs.period_endpoints:  # pylint: disable=C0103
            if specs.lag == 0:
                specs.name = (
                    f"{specs.target}_{ep}{specs.unit}_{specs.type.value}"
                )
            else:
                specs.name = f"{specs.target}_{ep}{specs.unit}_{specs.type.value}_{specs.lag}{specs.unit}_lag"  # pylint: disable=C0301

            oldest_point = ep + specs.lag
            _window = _window.orderBy(specs.order_key).rowsBetween(
                -oldest_point, -specs.lag
            )
            data_points = F.collect_list(F.col(specs.target)).over(_window)

            # In data_points array, [0] is the oldest and [ep] is the most recent
            numerator = data_points[ep]
            denominator = data_points[0]

            result.append(
                F.when(
                    (numerator.isNotNull()) & (denominator > 0),
                    F.least(
                        F.lit(specs.ceiling),
                        F.greatest(
                            F.lit(specs.floor), numerator / denominator - 1
                        ),
                    ),
                )
                .otherwise(F.lit(None))
                .alias(specs.name)
            )
        return result

    @staticmethod
    def _calc_rate_of_change_core(
        specs: Union[RateOfChange, RateOfPctChange],
        change_udf: Callable[[List[float]], Column],
    ) -> List[Column]:
        """Define common core function called by calc_rate_of_change and calc_rate_of_pct_change.

        Args:
            specs (RateOfChange): Object of class `RateOfChange` containing specifications.
            change_udf (function): UDF that calculates rate of change or rate of pct change.

        Returns:
            List of Pyspark Columns.

        """
        result = []
        pkey = specs.partition_key
        if isinstance(pkey, str):
            _window = Window.partitionBy(pkey)
        else:
            _window = Window.partitionBy([F.col(key) for key in pkey])

        for ep in specs.period_endpoints:  # pylint: disable=C0103
            if specs.lag == 0:
                specs.name = (
                    f"{specs.target}_{ep}{specs.unit}_{specs.type.value}"
                )
            else:
                specs.name = f"{specs.target}_{ep}{specs.unit}_{specs.type.value}_{specs.lag}{specs.unit}_lag"  # pylint: disable=C0301

            oldest_point = ep + specs.lag
            _window = _window.orderBy(specs.order_key).rowsBetween(
                -oldest_point, -specs.lag
            )
            data_points = F.collect_list(F.col(specs.target)).over(_window)

            raw_slope = F.when(F.size(data_points) < ep, None).otherwise(
                change_udf(data_points)
            )

            result.append(
                F.when(
                    raw_slope.isNotNull(),
                    F.least(
                        F.lit(specs.ceiling),
                        F.greatest(F.lit(specs.floor), raw_slope),
                    ),
                )
                .otherwise(F.lit(None))
                .alias(specs.name)
            )
        return result

    @staticmethod
    def calc_rate_of_change(specs: RateOfChange) -> List[Column]:
        """Calculate rate_of_change feature based on specs.

        Args:
            specs (RateOfChange): Object of class `RateOfChange` containing specifications.

        Returns:
            List of Pyspark Columns.

        """
        return StandardMixin._calc_rate_of_change_core(
            specs, fffun.rate_of_change
        )

    @staticmethod
    def calc_rate_of_pct_change(specs: RateOfPctChange) -> List[Column]:
        """Calculate rate_of_pct_change feature based on specs.

        Args:
            specs (RateOfPctChange): Object of class `RateOfPctChange` containing specifications.

        Returns:
            List of Pyspark Columns.

        """
        return StandardMixin._calc_rate_of_change_core(
            specs, fffun.rate_of_pct_change
        )

    @staticmethod
    def _calc_explode_fun(
        specs: Explode, explode_fun: Callable[[str], Column]
    ) -> List[Column]:
        """
        Return a new row for each element in the given array or map.

        Can be either explode or explode_outer depending on input function given.

        Args:
            specs (Explode): Object of class `Explode` containing specifications.
            explode_fun (Callable[str, Column]): Explode or explode_outer function.

        Returns:
            List of Pyspark Columns.

        """
        column = specs.target
        alias = specs.alias

        if alias:
            if isinstance(alias, list):
                if len(alias) > 2:
                    raise Exception(
                        f"Alias parameter can have a max of 2 elements. {len(alias)} was given."
                    )
                res = explode_fun(column).alias(*alias)
            else:
                res = explode_fun(column).alias(alias)
        else:
            res = explode_fun(column)

        return [res]

    @staticmethod
    def calc_explode_outer(specs: Explode) -> List[Column]:
        """
        Return a new row for each element in the given array or map.

        Run PySpark explode_outer function under the hood.

        Args:
            specs (Explode): Object of class `Explode` containing specifications.

        Returns:
            List of Pyspark Columns.

        """
        return StandardMixin._calc_explode_fun(specs, F.explode_outer)

    @staticmethod
    def calc_explode(specs: Explode) -> List[Column]:
        """
        Return a new row for each element in the given array or map.

        Run PySpark explode function under the hood.

        Args:
            specs (Explode): Object of class `Explode` containing specifications.

        Returns:
            List of Pyspark Columns.

        """
        return StandardMixin._calc_explode_fun(specs, F.explode)
