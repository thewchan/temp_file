"""The ``calcfeatures`` module contains classes to create standard calculated features."""
