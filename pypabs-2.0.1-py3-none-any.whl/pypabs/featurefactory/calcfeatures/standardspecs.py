"""``StandardSpecs`` contains classes that define schemas for standard calculated features."""

from dataclasses import dataclass, field
from typing import List, Optional, Union

from pypabs.featurefactory.otherspecs import FeatType
from pypabs.util.pprint_mixins import PPrintMixin

__all__ = [
    "Ratio",
    "Lag",
    "Average",
    "PercentChange",
    "RateOfChange",
    "RateOfPctChange",
    "Explode",
]


@dataclass
class CalcFeatDefaults(PPrintMixin):
    """Define schema and setting defaults for CalcFeatDefaults.

    Attributes:
        type (FeatType): Value can be any one of: "Ratio", "Lag", "Average",
            "PercentChange", "RateOfChange", "RateOfPctChange", "Explode" or
            "explode_outer"
        name (str): Optional.
        target (str): Optional.
        numerator (str): Optional.
        denominator (str): Optional.
        durations (List[int]): Optional.
        period_endpoints (List[int]): Optional.
        lag (int) Optional.
        lag_points (List[int]): Optional.
        unit (str) Optional.
        partition_key (str or List[str]): Optional.
        order_key (str or List[str]): Optional.
        floor (float) Optional.
        ceiling (float): Optional.
        alias: Optional[Union[str, List[str]]: Optional.
        scale (float): Optional.

    """

    # pylint: disable=too-many-instance-attributes
    type: FeatType = field(metadata={"by_value": True})
    name: Optional[str] = None
    target: Optional[str] = None
    numerator: Optional[str] = None
    denominator: Optional[str] = None
    durations: Optional[List[int]] = None
    period_endpoints: Optional[List[int]] = None
    lag: Optional[int] = 0
    lag_points: Optional[List[int]] = None
    unit: Optional[str] = ""
    partition_key: Optional[Union[str, List[str]]] = None
    order_key: Optional[Union[str, List[str]]] = None
    floor: Optional[float] = None
    ceiling: Optional[float] = None
    scale: Optional[float] = None
    alias: Optional[Union[str, List[str]]] = None


@dataclass
class Ratio(PPrintMixin):
    """Define schema for Ratio feature.

    Attributes:
        type (FeatType)
        name (str)
        numerator (str)
        denominator (str)
        floor (float) Optional.
        ceiling (float): Optional.
        scale (float): Optional.

    """

    type: FeatType = field(metadata={"by_value": True})
    name: str
    numerator: str
    denominator: str
    floor: Optional[float] = None
    ceiling: Optional[float] = None
    scale: Optional[float] = None


@dataclass
class Lag(PPrintMixin):
    """Define schema for Lag feature.

    Attributes:
        type (FeatType)
        target (str)
        lag_points (List[int])
        partition_key (str or List[str])
        order_key (str or List[str])
        unit (str) Optional.

    """

    type: FeatType = field(metadata={"by_value": True})
    target: str
    lag_points: List[int]
    partition_key: Union[str, List[str]]
    order_key: Union[str, List[str]]
    unit: Optional[str] = ""


@dataclass
class Average(PPrintMixin):
    """Define schema for Average feature.

    Attributes:
        type (FeatType)
        target (str)
        durations (List[int])
        partition_key (str or List[str])
        order_key (str or List[str])
        lag (int) Optional.
        unit (str) Optional.
        floor (float) Optional.
        ceiling (float): Optional.

    """

    # pylint: disable=too-many-instance-attributes
    type: FeatType = field(metadata={"by_value": True})
    target: str
    durations: List[int]
    partition_key: Union[str, List[str]]
    order_key: Union[str, List[str]]
    lag: Optional[int] = 0
    unit: Optional[str] = ""
    floor: Optional[float] = None
    ceiling: Optional[float] = None


@dataclass
class PercentChange(PPrintMixin):
    """Define schema for PercentChange feature.

    Attributes:
        type (FeatType)
        target (str)
        period_endpoints (List[int])
        partition_key (str or List[str])
        order_key (str or List[str])
        lag (int) Optional.
        unit (str) Optional.
        floor (float) Optional.
        ceiling (float): Optional.

    """

    # pylint: disable=too-many-instance-attributes
    type: FeatType = field(metadata={"by_value": True})
    target: str
    period_endpoints: List[int]
    partition_key: Union[str, List[str]]
    order_key: Union[str, List[str]]
    lag: Optional[int] = 0
    unit: Optional[str] = ""
    floor: Optional[float] = None
    ceiling: Optional[float] = None


@dataclass
class RateOfChange(PPrintMixin):
    """Define schema for RateOfChange feature.

    Attributes:
        type (FeatType)
        target (str)
        period_endpoints (List[int])
        partition_key (str or List[str])
        order_key (str or List[str])
        lag (int) Optional.
        unit (str) Optional.
        floor (float) Optional.
        ceiling (float): Optional.

    """

    # pylint: disable=too-many-instance-attributes
    type: FeatType = field(metadata={"by_value": True})
    target: str
    period_endpoints: List[int]
    partition_key: Union[str, List[str]]
    order_key: Union[str, List[str]]
    lag: Optional[int] = 0
    unit: Optional[str] = ""
    floor: Optional[float] = None
    ceiling: Optional[float] = None


@dataclass
class RateOfPctChange(PPrintMixin):
    """Define schema for RateOfPctChange feature.

    Attributes:
        type (FeatType)
        target (str)
        period_endpoints (List[int])
        partition_key (str or List[str])
        order_key (str or List[str])
        lag (int) Optional.
        unit (str) Optional.
        floor (float) Optional.
        ceiling (float): Optional.

    """

    # pylint: disable=too-many-instance-attributes
    type: FeatType = field(metadata={"by_value": True})
    target: str
    period_endpoints: List[int]
    partition_key: Union[str, List[str]]
    order_key: Union[str, List[str]]
    lag: Optional[int] = 0
    unit: Optional[str] = ""
    floor: Optional[float] = None
    ceiling: Optional[float] = None


@dataclass
class Explode(PPrintMixin):
    """Define schema for Explode input parameters.

    Attributes:
        type (FeatType)
        target (str)
        alias (str or List[str]). Optional.

    """

    type: FeatType = field(metadata={"by_value": True})
    target: str
    alias: Optional[Union[str, List[str]]] = None
