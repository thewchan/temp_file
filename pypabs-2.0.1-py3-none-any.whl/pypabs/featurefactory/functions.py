"""The ``functions`` module provides public functions used by feature factory."""

from typing import List, Union

import pyspark.sql.functions as _F
from pyspark.sql.types import DoubleType

__all__ = ["rate_of_pct_change", "rate_of_change"]


@_F.udf(returnType=DoubleType())
def rate_of_pct_change(points: List[float]) -> Union[float, None]:
    """
    Calculate rate of percentage change given a sequence or time-series.

    Rate of percentage change is the slope of normalized regression line x 100.

    Args:
        points (list): Sequence of numbers

    Returns:
        float: Normalized rate of change in percentage.
    """
    n_raw = len(points)

    # Need at least 3 points to get a minimum of 2 point-to-point changes
    if n_raw < 3:
        return None

    # Since we're calculating point-to-point changes, length(X)
    # is length(points) - 1
    num_pts = n_raw - 1
    x_vec = range(num_pts)

    # calculate point-to-point percentage change
    y_vec = [
        i / j - 1 if j != 0 else None for i, j in zip(points[1:], points[:-1])
    ]

    if any(e is None for e in y_vec):
        return None

    xbar = sum(x_vec) / len(x_vec)
    ybar = sum(y_vec) / len(y_vec)

    numer = (
        sum([xi * yi for xi, yi in zip(x_vec, y_vec)]) - num_pts * xbar * ybar
    )
    denom = sum([xi ** 2 for xi in x_vec]) - num_pts * xbar ** 2

    return None if denom == 0 else numer / denom


@_F.udf(returnType=DoubleType())
def rate_of_change(y_vec: List[float]) -> Union[float, None]:
    """
    Calculate rate of change given a sequence or time-series.

    Rate of change is the slope of regression line.

    Args:
        y_vec (list): Sequence of numbers

    Returns:
        float: Rate of change.
    """
    num_pts = len(y_vec)

    # Need at least 3 points to get a minimum of 2 point-to-point changes
    if num_pts < 3:
        return None

    x_vec = range(num_pts)

    if any(e is None for e in y_vec):
        return None

    xbar = sum(x_vec) / len(x_vec)
    ybar = sum(y_vec) / len(y_vec)

    numer = (
        sum([xi * yi for xi, yi in zip(x_vec, y_vec)]) - num_pts * xbar * ybar
    )
    denom = sum([xi ** 2 for xi in x_vec]) - num_pts * xbar ** 2

    return None if denom == 0 else numer / denom
