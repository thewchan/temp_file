"""``FeatureFrame`` contains FeatureFrame class."""
from __future__ import annotations
import logging
from functools import partial
from typing import Callable, Optional, Union

import numpy as np
import pandas as pd
import pyspark.sql.functions as F  # noqa: N812; F is convention
from pyspark.sql.types import ArrayType, MapType
from pyspark.sql.dataframe import DataFrame

import pypabs
from pypabs.featurestore.core import AxpFeatureStore
import pypabs.featurestore.memorystore as memory_store
import pypabs.featurestore.localcheckpointstore as localcheckpoint_store
from pypabs.featurefactory.otherspecs import StoreType
from pypabs.featurefactory.featureframespecs import FeatureFrameSpecs
from pypabs.featurefactory.transform_pipe import TransformPipeMixin
from pypabs.featurefactory.calcfeatures.standardfeatures import StandardMixin
from pypabs.util.axp_dataset import AxpDataFrame, AxpDatasetSpecs
from pypabs.util.functions import compose

__all__ = ["FeatureFrame"]


class FeatureFrame(
    StandardMixin, TransformPipeMixin, AxpDataFrame
):  # pylint: disable=R0901
    """
    ``FeatureFrame`` extends ``AxpDataFrame`` with additional attributes from ``FeatureFrameSpecs``.

    Methods:
        make_frame: Run whole procedure from beginning to end to make feature
            frame.
        load_source: Load raw dataframe from specified data source.
        run_transform_pipe: Transform dataset by performing stages of specified
            operations defined in the transform_pipe.
        materialize_frame: Materialize dataframe before calculating summary stats.
        calc_summary_stats: Calculate summary statistics on features in
            featureframe.
        write_to_destination: Write dataframe to specified destination store.

    """

    def __init__(
        self,
        ffspecs: FeatureFrameSpecs,
        df: Optional[Union[AxpDataFrame, DataFrame]] = None,
        axpspecs: Optional[AxpDatasetSpecs] = None,
        summary_stats: Optional[pd.DataFrame] = None,
        **kwargs,
    ) -> None:
        """
        Initialize class.

        Args:
            ffspecs (FeatureFrameSpecs): Specifications from YAML file.
            df (AxpDataFrame or Pyspark DataFrame): Optional. Initial dataframe.
            axpspecs (AxpDatasetSpecs): Optional. Specifications for AxpDataFrame.
            summary_stats (Pandas DataFrame): Optional. Summary statistics.

        """
        if not df:
            src = ffspecs.source
            axpdf = FeatureFrame.load_source(src)
            super().__init__(
                df=axpdf._df,
                axpspecs=axpdf._axpspecs,
                ffspecs=self.ffspecs,
                summary_stats=self._summary_stats,
                **kwargs,
            )
        else:
            if type(df) == AxpDataFrame:  # pylint: disable=C0123
                super().__init__(
                    df=df._df,
                    axpspecs=df._axpspecs,
                    ffspecs=df.ffspecs,
                    summary_stats=df._summary_stats,
                    **kwargs,
                )
            elif type(df) == DataFrame:  # pylint: disable=C0123
                super().__init__(
                    df=df,
                    axpspecs=axpspecs,
                    ffspecs=ffspecs,
                    summary_stats=summary_stats,
                    **kwargs,
                )
            else:
                exc_msg = (
                    "Invalid type for df in input arguments. "
                    "Needs to be either DataFrame or AxpDataFrame."
                )
                logging.error(exc_msg)
                raise Exception(exc_msg)

        self._ffspecs = ffspecs
        self._row_cnt = None

        if ffspecs.source.store_type == StoreType.LOCALCHECKPOINT:
            self._localcheckpoint = True
        else:
            self._localcheckpoint = False

        # Assign ffspecs attributes to this class for easy access.
        for _k, _v in vars(ffspecs).items():
            setattr(self, _k, _v)

    class ToFeatureFrame:
        """Decorate a method to make it return a FeatureFrame instead of DataFrame."""

        def __init__(self, decorated):
            """Initialize decorator by taking a function as input."""
            self._decorated = decorated

        def __call__(self, decorated_self):
            """Define helper function here."""
            getattr(super(FeatureFrame, decorated_self), "__init__")(
                df=self._decorated(decorated_self),
                axpspecs=decorated_self._axpspecs,
                ffspecs=decorated_self.ffspecs,
                summary_stats=decorated_self._summary_stats,
            )

            return decorated_self

        def __get__(self, decorated_self, owner):
            """Need this method to use class-based decorator for methods."""
            return partial(self, decorated_self)

    @staticmethod
    def load_source(
        source: FeatureFrameSpecs._Source,  # pylint: disable=W0212
    ) -> AxpDataFrame:
        """Load dataset from source.

        There are four source types:
            1. AxpDataFrame
            2. Feature store
            3. Memory
            4. Local checkpoint

        Args:
            source (FeatureFrameSpecs._Source). Object containing source specifications.

        Returns:
            AxpDataFrame object.

        """

        def _load_axpdataset_resource(
            source: FeatureFrameSpecs._Source,  # pylint: disable=W0212
        ) -> AxpDataFrame:
            """Load source from axp_dataset repo."""
            return pypabs.AXP_DATASETS.load(source.table_name)

        def _load_featurestore_resource(
            source: FeatureFrameSpecs._Source,  # pylint: disable=W0212
        ) -> AxpDataFrame:
            """Load source from AxpFeatureStore."""
            afs = AxpFeatureStore(source.feature_store)
            return afs.load_table(source.table_name)

        def _load_memory_resource(
            source: FeatureFrameSpecs._Source,  # pylint: disable=W0212
        ) -> AxpDataFrame:
            """Load source from memory. Source needs to be a FeatureFrame."""
            source = getattr(memory_store, source.table_name)
            return source  # pylint: disable=W0212

        def _load_localcheckpoint_resource(
            source: FeatureFrameSpecs._Source,  # pylint: disable=W0212
        ) -> AxpDataFrame:
            """Load source from memory. Source needs to be a FeatureFrame."""
            source = getattr(localcheckpoint_store, source.table_name)
            return source  # pylint: disable=W0212

        store_type = source.store_type
        if store_type == StoreType.AXP_DATASET:
            return _load_axpdataset_resource(source)
        if store_type == StoreType.FEATURE_STORE:
            return _load_featurestore_resource(source)
        if store_type == StoreType.MEMORY:
            return _load_memory_resource(source)
        if store_type == StoreType.LOCALCHECKPOINT:
            return _load_localcheckpoint_resource(source)
        raise Exception("load_source() error: invalid source.")

    def run_transform_pipe(self) -> FeatureFrame:
        """Run transform pipe.

        This method recursively runs through all the stages in transform_pipe in
        a "map and reduce" manner, similar to the "fold" function from functional
        programming, by using the custom function `compose`.

        Returns:
            FeatureFrame object.

        """
        transform_pipe = self.transform_pipe
        if not transform_pipe:
            return self

        def run_pipe(
            transform_pipe_elem: FeatureFrameSpecs._TransformPipe,  # pylint: disable=W0212
        ) -> Callable[[], FeatureFrame]:
            """Generate a function that executes each stage of the transform_pipe.

            Args:
                transform_pipe_elem (FeatureFrameSpecs._TransformPipe): A stage
                    in transform_pipe.

            Returns:
                A function that executes a stage of the transform_pipe and
                returns result back as a FeatureFrame object.

            """

            def _inner(self):
                """Execute a stage of the transform_pipe to transform featureframe.

                Note:
                    It calls super().__init__() to turn resulting Pyspark
                    DataFrame object back to original FeatureFrame class for
                    chaining.

                Returns:
                    FeatureFrame object.

                """
                stage_name = transform_pipe_elem.stage.value
                stage_obj = getattr(transform_pipe_elem, stage_name)

                if not stage_obj:
                    logging.warning(
                        "Stage content is null for '%s'. Potentially a stage name and content key mismatch in yaml file.",
                        stage_name,
                    )

                res = getattr(
                    self,
                    "run_" + stage_name,
                )(transform_pipe_elem)

                super().__init__(
                    df=res,
                    axpspecs=self._axpspecs,
                    ffspecs=self.ffspecs,
                    summary_stats=self._summary_stats,
                )
                return self

            return _inner

        # Chain together the .select functions, one for each individual calc_feature
        return compose(list(reversed(list(map(run_pipe, transform_pipe)))))(
            self
        )

    def materialize_frame(self) -> FeatureFrame:
        """Materialize dataframe before calculating summary stats.

        Returns:
            FeatureFrame object.

        """
        logging.info("Materializing featureframe...")
        if not self._localcheckpoint:
            self._row_cnt = self.cache().count()
        else:
            # Cannot call cache() if dataframe is a local checkpoint
            self._row_cnt = self.localCheckpoint(True).count()
        logging.info("%s rows materialized.", "{:,}".format(self._row_cnt))
        return self

    def calc_summary_stats(  # pylint: disable=R0914
        self,
    ) -> FeatureFrame:
        """
        Calculate summary statistics on features in featureframe.

        Summary statistics calculated are:
            - valid count
            - null count
            - NaN count
            - invalid ratio
            - mean
            - median
            - stddev
            - skew
            - min
            - max
            - 0.1%
            - 1%
            - 25%
            - 75%
            - 99%
            - 99.9%

        Returns:
            FeatureFrame object.

        """
        enable = True
        subset = None

        if self.summary_meta:
            enable = self.summary_meta.enable
            subset = self.summary_meta.subset

        if not enable:
            self._summary_stats = None
            AxpDataFrame._summary_stats = self._summary_stats
            return self

        logging.info("Calculating summary stats...")
        subset_self = self.select("*")
        if subset:
            subset_self = self.select(subset)
        stats = [
            "mean",
            "50%",
            "stddev",
            "min",
            "max",
            "0.1%",
            "1%",
            "25%",
            "75%",
            "99%",
            "99.9%",
        ]
        summ1 = subset_self.summary(*stats).toPandas().set_index("summary").T
        numeric_cols = summ1.columns.drop(["min", "max"])
        for col in numeric_cols:
            summ1[col] = summ1[col].astype("float")
        summ1.rename(columns={"50%": "median"}, inplace=True)
        summ1["min"] = summ1["min"].astype(str)
        summ1["max"] = summ1["min"].astype(str)

        # Calculate skewness
        skew = subset_self.select(
            [
                F.skewness(F.col(f.name).cast("double")).alias(f.name)
                for f in subset_self.schema.fields
                if not isinstance(f.dataType, (ArrayType, MapType))
            ]
        )
        skew = skew.withColumn("summary", F.lit("skew")).select(
            ["summary"] + skew.columns
        )

        # Row count
        row_cnt = self._row_cnt if (self._row_cnt) else subset_self.count()

        # Count nulls
        null_count = subset_self.select(
            [
                F.count(
                    F.when(
                        F.col(f.name).rlike("(?i)^none$")
                        | F.col(f.name).rlike("(?i)^null$")
                        | (F.col(f.name) == "")
                        | F.isnull(f.name),
                        f.name,
                    )
                ).alias(f.name)
                for f in subset_self.schema.fields
                if not isinstance(f.dataType, (ArrayType, MapType))
            ]
        )
        null_count = null_count.withColumn(
            "summary", F.lit("null_count")
        ).select(["summary"] + null_count.columns)

        # Count NaN's
        nan_count = subset_self.select(
            [
                F.count(
                    F.when(F.isnan(F.col(f.name).cast("double")), f.name)
                ).alias(f.name)
                for f in subset_self.schema.fields
                if not isinstance(f.dataType, (ArrayType, MapType))
            ]
        )
        nan_count = nan_count.withColumn("summary", F.lit("nan_count")).select(
            ["summary"] + nan_count.columns
        )
        # Join new stats
        summ2 = (
            null_count.union(nan_count)
            .union(skew)
            .toPandas()
            .set_index("summary")
            .T
        )
        # Cast the total_count, null and nan counts as int64 type.
        for col in summ2.columns[:-1]:
            summ2[col] = summ2[col].astype("int64")

        # Merge everything together
        merged_summ = summ2.merge(summ1, left_index=True, right_index=True)

        merged_summ["valid_count"] = (
            merged_summ["null_count"] + merged_summ["nan_count"]
        ).apply(lambda x: row_cnt - x)

        merged_summ["invalid_ratio"] = (
            (merged_summ["null_count"] + merged_summ["nan_count"])
            .apply(lambda x: x / row_cnt if row_cnt > 0 else np.nan)
            .astype("float")
        )

        merged_summ["valid_count"] = merged_summ["valid_count"].astype("int64")

        # Rearrange columns
        cols_to_order = [
            "valid_count",
            "invalid_ratio",
            "null_count",
            "nan_count",
            "mean",
            "median",
            "stddev",
            "skew",
        ]
        new_columns = cols_to_order + (
            merged_summ.columns.drop(cols_to_order).tolist()
        )

        self._summary_stats = (
            merged_summ[new_columns]
            .reset_index()
            .rename(columns={"index": "feature"})
        )
        AxpDataFrame._summary_stats = self._summary_stats
        return self

    def write_to_destination(self) -> FeatureFrame:
        """Write dataset to destination.

        The three destination options are:
            1. Feature store (Permanent. Save to AXP feature store in S3.)
            2. Memory (Ephemeral. Retains in RAM.)
            3. Local checkpoint (Ephemeral. Save to local storage of each work node)

        Can also repartition dataframe or set z-order.

        Returns:
            FeatureFrame object.

        """
        if not self.destination:
            # Set defaults if destination field is null
            store_type = StoreType.MEMORY
            table_name = self.source.table_name
            partition_size = None
        else:
            store_type = self.destination.store_type
            table_name = self.destination.table_name
            partition_size = self.destination.partition_size
            repartition_or_coalesce = self.destination.repartition_or_coalesce

        def _write_to_featurestore(self):
            """Write featureframe to AxpFeatureStore."""
            dest = self.destination
            afs = AxpFeatureStore(dest.feature_store)
            afs.save(self)
            if not self._localcheckpoint:
                self.unpersist(blocking=False)

        def _write_to_memory(self):
            """Save featureframe to memory as a memory_store module attribute."""
            logging.info("Saving to memory...")
            adf = AxpDataFrame(
                df=self,
                axpspecs=self._axpspecs,
                ffspecs=self.ffspecs,
                summary_stats=self._summary_stats,
            )
            setattr(memory_store, table_name, adf)

        def _write_to_localcheckpoint(self):
            """Materialize featureframe and write to local checkpoint."""
            logging.info("Creating localcheckpoint...")
            if not self._localcheckpoint:
                pdf = self.cache().localCheckpoint(eager=True)
            else:
                pdf = self.localCheckpoint(eager=True)
            adf = AxpDataFrame(
                df=pdf,
                axpspecs=self._axpspecs,
                ffspecs=self.ffspecs,
                summary_stats=self._summary_stats,
            )
            setattr(localcheckpoint_store, table_name, adf)

        # Repartition or coalesce featureframe.
        if partition_size:
            res = getattr(self, repartition_or_coalesce.value)(partition_size)
            super().__init__(
                df=res,
                axpspecs=self._axpspecs,
                ffspecs=self.ffspecs,
                summary_stats=self._summary_stats,
            )

        if store_type == StoreType.FEATURE_STORE:
            _write_to_featurestore(self)
        elif store_type == StoreType.MEMORY:
            _write_to_memory(self)
        elif store_type == StoreType.LOCALCHECKPOINT:
            _write_to_localcheckpoint(self)
        else:
            raise Exception(
                "write_to_destination() error: invalid destination."
            )
        logging.info(
            "Frame successfully written to %s.",
            store_type.value.replace("_", " "),
        )
        return self

    def make_frame(self) -> FeatureFrame:
        """Make featureframe according to specifications in ffspecs.

        Internally, it does these four steps:
            1. Execute each stage of transform pipe according to specs.
            2. Materialize featureframe.
            3. Optionally calculate summary statistics for featureframe.
            4. Save featureframe to destination.

        Returns:
            FeatureFrame object.

        """
        logging.info("\nMaking %s...", self.short_name)
        result = (
            self.run_transform_pipe()
            .materialize_frame()
            .calc_summary_stats()
            .write_to_destination()
        )
        logging.info("%s completed.", self.short_name)
        return result
