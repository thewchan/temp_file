"""Module contains ``TransformPipeMixin`` to provide methods to run transform_pipe stages."""

from __future__ import annotations

import logging
from typing import Callable, TYPE_CHECKING, Union

import pyspark.sql.functions as F  # noqa: N812; F is convention
from pyspark.sql.dataframe import DataFrame

import pypabs.featurefactory.calcfeatures.standardspecs as calcspecs
from pypabs.util.functions import compose
from pypabs.featurefactory.otherspecs import StoreType

if TYPE_CHECKING:
    from pypabs.featurefactory.featureframe import FeatureFrame
    from pypabs.featurefactory.featureframespecs import FeatureFrameSpecs


class TransformPipeMixin:
    """Mixin class to define methods to run each stage in tranform_pipe.

    Methods:
        1. run_joins
        2. run_custom_columns
        3. run_filter
        4. run_groupby
        5. run_drop_columns
        6. run_rename_columns
        7. run_drop_duplicates
        8. run_fillna
        9. run_dropna
        10. run_sample
        11. run_custom_tranforms
        12. run_select
        13. run_orderby

    """

    def run_joins(
        self, params: FeatureFrameSpecs._TransformPipe  # pylint: disable=W0212
    ) -> FeatureFrame:
        """Perform joins consecutively according to specs.

        Args:
            params (FeatureFrameSpecs._TransformPipe): An element of
            transform_pipe attribute of FeatureFrameSpecs

        Returns:
            FeatureFrame object with all the tables joined.

        """
        join_srcs = params.joins

        if not join_srcs:
            return self

        def join_table_fun(
            src: FeatureFrameSpecs._TransformPipe._Joins,  # pylint: disable=W0212
        ) -> Callable[None, FeatureFrame]:
            """Generate a function that perform a join according to specs.

            Args:
                src (FeatureFrameSpecs._TransformPipe._Joins): Join specs.

            Returns:
                A function that performs the join and returns result as a
                FeatureFrame.

            """

            def _inner(self) -> FeatureFrame:
                """Join a table using Pyspark .join() method.

                "join_on" and "join_type" parameters are provided in specs.

                Note:
                    It calls super().__init__() to turn resulting Pyspark
                    DataFrame object back to original FeatureFrame class for
                    chaining.

                Returns:
                    FeatureFrame object.

                """
                res = self.join(
                    self.__class__.load_source(src),
                    src.join_on,
                    src.join_type,
                )
                if src.store_type == StoreType.LOCALCHECKPOINT:
                    # Set _localcheckpoint flag to True. Cannot call cache() in
                    # core.py if one of the tables is a localcheckpoint.
                    self._localcheckpoint = True

                super().__init__(
                    df=res,
                    axpspecs=self._axpspecs,
                    ffspecs=self.ffspecs,
                    summary_stats=self._summary_stats,
                )
                return self

            return _inner

        # Chain together the .join functions, one for each table
        return compose(list(reversed(list(map(join_table_fun, join_srcs)))))(
            self
        )

    def run_custom_columns(
        self, params: FeatureFrameSpecs._TransformPipe  # pylint: disable=W0212
    ) -> FeatureFrame:
        """Create custom columns consecutively according to specs.

        Args:
            params (FeatureFrameSpecs._TransformPipe): An element of
            transform_pipe attribute of FeatureFrameSpecs

        Returns:
            FeatureFrame object containing new custom columns.

        """
        custom_columns = params.custom_columns

        if not custom_columns:
            return self

        def add_custom_col_fun(col_name: str) -> Callable[None, FeatureFrame]:
            """Generate a function that creates a custom column.

            Args:
                col_name (str): Column name

            Returns:
                A function that adds a custom column and returns a FeatureFrame
                containing it.

            """

            def _inner(self) -> FeatureFrame:
                """Create custom column using Pyspark .withColumn() method.

                The actual function that contains the logic of creating the
                custom column resides in customcolumns.py file that user
                provides. The function with the same name as the new custom
                column is invoked here by calling getattr(self, col_name)().

                Note:
                    It calls super().__init__() to turn resulting Pyspark
                    DataFrame object back to original FeatureFrame class for
                    chaining.

                Returns:
                    FeatureFrame object.

                """
                if not hasattr(self, col_name):
                    raise Exception(
                        f"method '{col_name}' not found in customcolumns.py"
                    )
                res = self.withColumn(col_name, getattr(self, col_name)())
                super().__init__(
                    df=res,
                    axpspecs=self._axpspecs,
                    ffspecs=self.ffspecs,
                    summary_stats=self._summary_stats,
                )
                return self

            return _inner

        # Chain together the .withColumn functions, one for each new column
        return compose(
            list(reversed(list(map(add_custom_col_fun, custom_columns))))
        )(self)

    def run_filter(
        self, params: FeatureFrameSpecs._TransformPipe  # pylint: disable=W0212
    ) -> DataFrame:
        """Apply PySpark .filter() function on featureframe.

        Args:
            params (FeatureFrameSpecs._TransformPipe): An element of
            transform_pipe attribute of FeatureFrameSpecs

        Returns:
            Pyspark DataFrame object containing result.

        """
        _args = params.filter
        if not _args:
            return self

        return self.filter(_args)

    def run_groupby(  # pylint: disable=R0914
        self, params: FeatureFrameSpecs._TransformPipe  # pylint: disable=W0212
    ) -> DataFrame:
        """Apply PySpark .groupBy().agg().where() transform.

        Args:
            params (FeatureFrameSpecs._TransformPipe): An element of
            transform_pipe attribute of FeatureFrameSpecs

        Returns:
            Pyspark DataFrame object containing result.

        """
        _args = params.groupby
        if not _args:
            return self
        if not all([_args.keys, _args.agg_function]):
            return self

        agg_type_map = {
            "avg": F.avg,
            "count": F.count,
            "countDistinct": F.countDistinct,
            "max": F.max,
            "mean": F.mean,
            "min": F.min,
            "sum": F.sum,
        }

        pivot = _args.pivot
        if pivot:
            pivot_column = pivot.column
            pivot_values = pivot.values

        keys = _args.keys
        agg_type = _args.agg_function.agg_type
        agg_columns = _args.agg_function.agg_columns
        aliases = _args.agg_function.aliases
        where_string = _args.where_string

        try:
            agg_type_funs = map(lambda x: agg_type_map[x], agg_type)
        except KeyError as exc:
            logging.error(
                "Invalid agg_type in groupby.agg_function in YAML file"
            )
            raise exc

        agg_fun_parts = zip(agg_type_funs, agg_columns, aliases)
        agg_funs = map(lambda _p: _p[0](_p[1]).alias(_p[2]), agg_fun_parts)

        if pivot and pivot_column:
            res = (
                self.groupBy(*keys)
                .pivot(pivot_column, pivot_values)
                .agg(*agg_funs)
            )
        else:
            res = self.groupBy(*keys).agg(*agg_funs)

        if where_string:
            res = res.where(where_string)

        return res

    def run_drop_columns(
        self, params: FeatureFrameSpecs._TransformPipe  # pylint: disable=W0212
    ) -> DataFrame:
        """Apply PySpark .drop() function.

        Args:
            params (FeatureFrameSpecs._TransformPipe): An element of
            transform_pipe attribute of FeatureFrameSpecs

        Returns:
            Pyspark DataFrame object containing result.

        """
        _args = params.drop_columns
        if not _args:
            return self

        return self.drop(*_args)

    def run_rename_columns(
        self, params: FeatureFrameSpecs._TransformPipe  # pylint: disable=W0212
    ) -> FeatureFrame:
        """Rename a list of existing columns consecutively with .withColumnRenamed() method.

        Args:
            params (FeatureFrameSpecs._TransformPipe): An element of
            transform_pipe attribute of FeatureFrameSpecs

        Returns:
            FeatureFrame object containing result.

        """
        rename_list = params.rename_columns

        if not rename_list:
            return self

        def rename_column_fun(
            colname: FeatureFrameSpecs._TransformPipe._RenameColumns,  # pylint: disable=W0212
        ) -> Callable[None, FeatureFrame]:
            """Generate a function that renames one existing column.

            Args:
                colname (FeatureFrameSpecs._TransformPipe._RenameColumns): object
                    with attributes "existing" and "new"

            Returns:
                A function that renames a column and returns FeatureFrame
                containing renamed column.

            """

            def _inner(self) -> FeatureFrame:
                """Rename column using Pyspark .withColumnRenamed() method.

                Note:
                    It calls super().__init__() to turn resulting Pyspark
                    DataFrame object back to original FeatureFrame class for
                    chaining.

                Returns:
                    FeatureFrame object.

                """
                res = self.withColumnRenamed(colname.existing, colname.new)
                super().__init__(
                    df=res,
                    axpspecs=self._axpspecs,
                    ffspecs=self.ffspecs,
                    summary_stats=self._summary_stats,
                )
                return self

            return _inner

        # Chain together the .withColumnRenamed functions, one for each renamed column
        return compose(
            list(reversed(list(map(rename_column_fun, rename_list))))
        )(self)

    def run_drop_duplicates(
        self, params: FeatureFrameSpecs._TransformPipe  # pylint: disable=W0212
    ) -> DataFrame:
        """Apply PySpark .drop_dubplicates() function.

        Args:
            params (FeatureFrameSpecs._TransformPipe): An element of
            transform_pipe attribute of FeatureFrameSpecs

        Returns:
            Pyspark DataFrame object containing result.

        """
        _args = params.drop_duplicates
        if not _args:
            return self

        if not _args.enable:
            return self

        return self.drop_duplicates(_args.subset)

    def run_fillna(
        self, params: FeatureFrameSpecs._TransformPipe  # pylint: disable=W0212
    ) -> DataFrame:
        """Apply PySpark .fillna() function.

        Args:
            params (FeatureFrameSpecs._TransformPipe): An element of
            transform_pipe attribute of FeatureFrameSpecs

        Returns:
            Pyspark DataFrame object containing result.

        """
        _args = params.fillna
        if not _args:
            return self
        if not _args.value:
            return self

        return self.fillna(_args.value, _args.subset)

    def run_dropna(
        self, params: FeatureFrameSpecs._TransformPipe  # pylint: disable=W0212
    ) -> DataFrame:
        """Apply PySpark .dropna() function.

        Args:
            params (FeatureFrameSpecs._TransformPipe): An element of
            transform_pipe attribute of FeatureFrameSpecs

        Returns:
            Pyspark DataFrame object containing result.

        """
        _args = params.dropna
        if not _args:
            return self
        if not _args.enable:
            return self
        return self.dropna(
            how=_args.how.value, thresh=_args.thresh, subset=_args.subset
        )

    def run_sample(
        self, params: FeatureFrameSpecs._TransformPipe  # pylint: disable=W0212
    ) -> DataFrame:
        """Apply PySpark .sample() function.

        Args:
            params (FeatureFrameSpecs._TransformPipe): An element of
            transform_pipe attribute of FeatureFrameSpecs

        Returns:
            Pyspark DataFrame object containing result.

        """
        _args = params.sample
        if not _args:
            return self
        if not _args.fraction:
            return self

        return self.sample(
            fraction=_args.fraction,
            seed=_args.seed,
            withReplacement=_args.with_replacement,
        )

    def run_custom_transforms(
        self, params: FeatureFrameSpecs._TransformPipe  # pylint: disable=W0212
    ) -> FeatureFrame:
        """Run custom transforms one by one according to specs and customtranforms.py.

        Args:
            params (FeatureFrameSpecs._TransformPipe): An element of
            transform_pipe attribute of FeatureFrameSpecs

        Returns:
            FeatureFrame object with custom transforms performed.

        """
        _args = params.custom_transforms
        if not _args:
            return self

        def custom_transforms_fun(
            method_name: str,
        ) -> Callable[None, FeatureFrame]:
            """Generate a function that performs a custom transform.

            Args:
                method_name (str): Name of custom transform method.

            Returns:
                A function that performs a custom transform and returns result
                as a FeatureFrame object.

            """

            def _inner(self) -> FeatureFrame:
                """Perform custom transform on a featureframe.

                The actual function that contains the logic of performing the
                custom transform resides in customtransforms.py file that user
                provides. The method with the same name as method_name is
                invoked here by calling getattr(self, method_name)().

                Note:
                    It calls super().__init__() to turn resulting Pyspark
                    DataFrame object back to original FeatureFrame class for
                    chaining.

                Returns:
                    FeatureFrame object.

                """
                if not hasattr(self, method_name):
                    raise Exception(
                        f"method '{method_name}' not found in customtransforms.py"
                    )
                res = getattr(self, method_name)()
                super().__init__(
                    df=res,
                    axpspecs=self._axpspecs,
                    ffspecs=self.ffspecs,
                    summary_stats=self._summary_stats,
                )
                return self

            return _inner

        # Chain together all the custom transforms
        return compose(list(reversed(list(map(custom_transforms_fun, _args)))))(
            self
        )

    def run_custom_ops(
        self, params: FeatureFrameSpecs._TransformPipe  # pylint: disable=W0212
    ) -> FeatureFrame:
        """Run custom ops one by one according to specs and customops.py.

        Args:
            params (FeatureFrameSpecs._TransformPipe): An element of
            transform_pipe attribute of FeatureFrameSpecs

        Returns:
            FeatureFrame object with custom operations performed.

        """
        _args = params.custom_ops
        if not _args:
            return self

        op_dicts = _args.items()

        def run_op_fun(op_dict: dict) -> Callable[None, FeatureFrame]:
            """Generate a function that performs a custom operation.

            Args:
                op_dict (dict): Name of custom operation.

            Returns:
                A function that performs a custom transform and returns result
                as a FeatureFrame object.

            """

            def _inner(self) -> FeatureFrame:
                """Perform custom operation on a featureframe.

                The actual function that contains the logic of performing the
                custom operation resides in customops.py file that user
                provides. The method with the same name as op_name is
                invoked here by calling getattr(self, op_name)().

                Note:
                    It calls super().__init__() to turn resulting Pyspark
                    DataFrame object back to original FeatureFrame class for
                    chaining.

                Returns:
                    FeatureFrame object.

                """
                (op_name, op_params) = op_dict
                if not hasattr(self, op_name):
                    raise Exception(
                        f"method '{op_name}' not found in customops.py"
                    )
                res = getattr(self, op_name)(op_params)
                super().__init__(
                    df=res,
                    axpspecs=self._axpspecs,
                    ffspecs=self.ffspecs,
                    summary_stats=self._summary_stats,
                )
                return self

            return _inner

        # Chain together all the custom operations
        return compose(list(reversed(list(map(run_op_fun, op_dicts)))))(self)

    def run_calc_features(
        self, params: FeatureFrameSpecs._TransformPipe  # pylint: disable=W0212
    ) -> FeatureFrame:
        """Create calculated features according to specs.

        Args:
            params (FeatureFrameSpecs._TransformPipe): An element of
            transform_pipe attribute of FeatureFrameSpecs

        Returns:
            FeatureFrame object containing original features plus new calculated
            features.

        """
        calc_features = params.calc_features
        if not calc_features:
            return self

        def calc(
            specs: Union[
                calcspecs.Ratio,
                calcspecs.Lag,
                calcspecs.Average,
                calcspecs.PercentChange,
                calcspecs.RateOfChange,
                calcspecs.RateOfPctChange,
                calcspecs.Explode,
            ]
        ) -> Callable[None, FeatureFrame]:
            """Generate a custom calculated feature.

            Args:
                specs (Union[
                    Ratio,
                    Lag,
                    Average,
                    PercentChange,
                    RateOfChange,
                    RateOfPctChange,
                    Explode,
                ]): Calculated feature specs. Specs classes are defined in
                    ``pypabs.featurefactory.calcfeatures.standardspecs`` module.

            Returns:
                A function that generates a calculated feature and returns
                FeatureFrame object containing original features plus new
                calculated features.

            """

            def _inner(self) -> FeatureFrame:
                """Generate a custom calculated feature.

                The actual function that contains the logic of performing the
                custom transform resides in
                ``pypabs.featurefactory.calcfeatures.standardfeatures. StandardMixin`` class.
                The method with the same name as "calc_" + specs.type.value is
                invoked here by calling getattr(self, "calc_" + specs.type.value)().

                Note:
                    It calls super().__init__() to turn resulting Pyspark
                    DataFrame object back to original FeatureFrame class for
                    chaining.

                Returns:
                    FeatureFrame object.

                """
                res = self.select(
                    "*", *(getattr(self, "calc_" + specs.type.value)(specs))
                )
                super().__init__(
                    df=res,
                    axpspecs=self._axpspecs,
                    ffspecs=self.ffspecs,
                    summary_stats=self._summary_stats,
                )
                return self

            return _inner

        # Chain together the .select functions, one for each individual calc_feature
        return compose(list(reversed(list(map(calc, calc_features)))))(self)

    def run_select(
        self, params: FeatureFrameSpecs._TransformPipe  # pylint: disable=W0212
    ) -> DataFrame:
        """Select base features.

        Args:
            params (FeatureFrameSpecs._TransformPipe): An element of
            transform_pipe attribute of FeatureFrameSpecs

        Returns:
            Pyspark DataFrame object containing selected features.

        """
        if not params.select:
            return self
        keys = params.select.keys
        base = params.select.features
        if not (keys or base):
            return self
        # Convert None to []
        if not keys:
            keys = []
        if not base:
            base = []

        # remove redundant features if included in both keys and base
        base_not_in_keys = [feature for feature in base if feature not in keys]
        combined_feats = keys + base_not_in_keys
        selected_feats = (
            combined_feats if ("*" not in combined_feats) else ["*"]
        )

        return self.select(*selected_feats)

    def run_orderby(
        self, params: FeatureFrameSpecs._TransformPipe  # pylint: disable=W0212
    ) -> DataFrame:
        """Apply PySpark .orderby() function.

        Args:
            params (FeatureFrameSpecs._TransformPipe): An element of
            transform_pipe attribute of FeatureFrameSpecs

        Returns:
            Pyspark DataFrame object containing result.

        """
        _args = params.orderby
        if not (_args and _args.columns):
            return self

        return self.orderBy(_args.columns, ascending=_args.ascending)
