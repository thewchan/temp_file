"""
The ``featurefactory`` module contains classes and functions related to creating features.

Purpose of feature factory is to create features based on a set of
specifications in YAML file, and store them in feature store.

"""
