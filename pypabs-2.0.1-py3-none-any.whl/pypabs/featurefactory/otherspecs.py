"""This module contains StoreType and FeatType classes."""

from enum import Enum, unique
from pypabs.util.pprint_mixins import PPrintMixin

__all__ = ["StoreType", "FeatType", "WriteMode"]


@unique
class StoreType(PPrintMixin, str, Enum):
    """Define enumeration for StoreType."""

    AXP_DATASET = "axp_dataset"
    FEATURE_STORE = "feature_store"
    MEMORY = "memory"
    LOCALCHECKPOINT = "localcheckpoint"


@unique
class FeatType(PPrintMixin, str, Enum):
    """Define enumeration for FeatType."""

    RATIO = "ratio"
    LAG = "lag"
    AVG = "average"
    PERCENT_CHG = "percent_change"
    RATE_OF_CHG = "rate_of_change"
    RATE_OF_PCT_CHG = "rate_of_pct_change"
    EXPLODE = "explode"
    EXPLODE_OUTER = "explode_outer"


@unique
class RepartitionMode(PPrintMixin, str, Enum):
    """Define enumeration for WriteMode."""

    REPARTITION = "repartition"
    COALESCE = "coalesce"


@unique
class WriteMode(PPrintMixin, str, Enum):
    """Define enumeration for WriteMode."""

    OVERWRITE = "overwrite"
    APPEND = "append"
    IGNORE = "ignore"
    ERRORIFEXISTS = "errorifexists"


@unique
class StageType(PPrintMixin, str, Enum):
    """Define enumeration for FeatType."""

    JOINS = "joins"
    FILTER = "filter"
    CUSTOM_COLUMNS = "custom_columns"
    GROUPBY = "groupby"
    DROP_COLUMNS = "drop_columns"
    RENAME_COLUMNS = "rename_columns"
    DROP_DUPLICATES = "drop_duplicates"
    FILLNA = "fillna"
    DROPNA = "dropna"
    SAMPLE = "sample"
    CUSTOM_OPS = "custom_ops"
    CUSTOM_TRANSFORMS = "custom_transforms"
    CALC_FEATRUES = "calc_features"
    SELECT = "select"
    ORDERBY = "orderby"


@unique
class DropnaHowType(PPrintMixin, str, Enum):
    """Define enumeration for 'how' parameter in dropna()."""

    ANY = "any"
    ALL = "all"
