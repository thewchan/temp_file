"""This module contains utility functions for parsing datasets."""
import logging
from typing import Optional

import pandas as pd

from pypabs.util.axp_dataset import AxpDataFrame, get_repo

__all__ = ["axp_dataset", "list_axp_datasets", "AXP_DATASETS"]


AXP_DATASETS = get_repo()


def axp_dataset(name: str) -> AxpDataFrame:
    """Retrieve dataset from AXP Datalake specified by name.

    Args:
        name (str): Name of the dataset to be retrieved.

    Returns:
        Dataframe (AxpDataFrame): Dataframe of requested data set.

    """
    try:
        if not AXP_DATASETS:
            raise RuntimeError("Unable to load dataset repo")

        return AXP_DATASETS.load(name)

    except Exception as exception:
        logging.exception(exception, exc_info=True)
        raise exception


def list_axp_datasets(
    sort_by: Optional[str] = None, ascending: bool = True
) -> pd.DataFrame:
    """List available datasets from yaml file catalog.

    Args:
        None

    Returns:
        Pandas DataFrame: Contains datasets that are accessible by
            :func:`util.core.axp_dataset`, which are listed in the
            ``axp_datasets.yml`` file.

    """
    if not AXP_DATASETS:
        raise RuntimeError("Unable to load dataset repo")

    return AXP_DATASETS.to_df(sort_by, ascending=ascending)
