"""Assign an S3 client to the variable ``s3`` when imported.

Attributes:
    s3 (botocore.client.S3): S3 client
"""
import boto3


def _get_s3() -> boto3.client:
    """Get s3 client.

        If s3 client already exists, return existing client, otherwise create
        boto3 session and return new S3 client.

    Returns:
        botocore.client.S3: If S3 client already exists or if
            connection is successful, S3 client is returned.
    """
    if "s3" in globals():
        return s3

    session = boto3.Session()
    return session.client("s3")


s3 = _get_s3()
