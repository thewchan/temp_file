# pylint: disable=R0801
"""This is an experimental color module with the Comcast color palette.

The Color class contains an individual color as defined by RGB values,
 while the ColorPalette class is a wrapper class for multiple Color
 instances.
"""
import colorsys
from dataclasses import dataclass
from typing import List, NamedTuple, Tuple, Union

RGB_SCALE = 255


def _get_hex_duple(num: int) -> str:
    """Returns a hex duple given an 8-bit decimal (0–255).

    Args:
        num: 8-bit decimal; between 0 and 255.

    Returns: A hex duple; will pad "0" if single digit.
    """
    duple = hex(num)[2:]

    if len(duple) == 1:
        return "0" + duple

    return duple


@dataclass
class Color:
    """An implementation of an RBG-based color."""

    name: str
    red: int
    green: int
    blue: int

    def hexstring(self) -> str:
        """Return the hex string representation of the color.

        Returns: Hex string of the color in lower case, always 6 digits.
        """
        return (
            _get_hex_duple(self.red)
            + _get_hex_duple(self.green)
            + _get_hex_duple(self.blue)
        )

    def rgb_tuple(self) -> Tuple[int, int, int]:
        """Return the RBG 8-bit decimal values in a tuple.

        Return: Tuple with three elements (RRR, GGG, BBB).
        """
        return self.red, self.green, self.blue

    def _get_rgb_pct(self) -> Tuple[float, float, float]:
        """Return the RGB values in percentage decimals."""
        return (
            self.red / RGB_SCALE,
            self.green / RGB_SCALE,
            self.blue / RGB_SCALE,
        )

    def hsl_tuple(self) -> Tuple[int, int, int]:
        """Return the HSL representation of the color.

        Returns: A three element tuple (Hue, Saturation, Lightness).
        """
        pct_red, pct_green, pct_blue = self._get_rgb_pct()
        pct_hue, pct_lightness, pct_saturation = colorsys.rgb_to_hls(
            pct_red, pct_green, pct_blue
        )
        hue = int(pct_hue * RGB_SCALE)
        lightness = int(pct_lightness * RGB_SCALE)
        saturation = int(pct_saturation * RGB_SCALE)

        return hue, saturation, lightness

    def hsv_tuple(self) -> Tuple[int, int, int]:
        """Return the HSL representation of the color.

        Returns: A three element tuple (Hue, Saturation, Value).
        """
        pct_red, pct_green, pct_blue = self._get_rgb_pct()
        pct_hue, pct_saturation, pct_value = colorsys.rgb_to_hsv(
            pct_red, pct_green, pct_blue
        )
        hue = int(pct_hue * RGB_SCALE)
        saturation = int(pct_saturation * RGB_SCALE)
        value = int(pct_value * RGB_SCALE)

        return hue, saturation, value

    def lighten(
        self, pct: float = 0.5, return_hex: bool = True
    ) -> Union[Tuple[int, int, int], str]:
        """Return a lightened version of the color.

        Args:
            pct: Decimal percentage of the desired lightening. Defaults
             to 0.5.
            return_hex: Whether the method should return a hex string
             or not. Defaults to True. Returns a tuple of 8-bit RGB
             values otherwise.

        Returns: Either a hex string or a tuple of the RGB 8-bit
         decimal of the lightened color.
        """
        hue, lightness, saturation = colorsys.rgb_to_hls(*self._get_rgb_pct())
        new_lightness = (1 - lightness) * pct + lightness

        pct_red, pct_green, pct_blue = colorsys.hls_to_rgb(
            hue, new_lightness, saturation
        )

        if return_hex:
            return (
                _get_hex_duple(int(pct_red * 255))
                + _get_hex_duple(int(pct_green * 255))
                + _get_hex_duple(int(pct_blue * 255))
            )

        return int(pct_red * 255), int(pct_green * 255), int(pct_blue * 255)

    def darken(
        self, pct: float = 0.5, return_hex: bool = True
    ) -> Union[Tuple[int, int, int], str]:
        """Return a darkened version of the color.

        Args:
            pct: Decimal percentage of the desired lightening. Defaults
             to 0.5.
            return_hex: Whether the method should return a hex string
             or not. Defaults to True. Returns a tuple of 8-bit RGB
             values otherwise.

        Returns: Either a hex string or a tuple of the RGB 8-bit
         decimal of the darkened color.
        """
        hue, lightness, saturation = colorsys.rgb_to_hls(*self._get_rgb_pct())
        new_lightness = lightness - lightness * pct

        pct_red, pct_green, pct_blue = colorsys.hls_to_rgb(
            hue, new_lightness, saturation
        )

        if return_hex:
            return (
                _get_hex_duple(int(pct_red * 255))
                + _get_hex_duple(int(pct_green * 255))
                + _get_hex_duple(int(pct_blue * 255))
            )

        return int(pct_red * 255), int(pct_green * 255), int(pct_blue * 255)


def hex_to_rgb(raw_hex_str: str) -> Tuple[int, ...]:
    """Return a tuple of of 8-bit RGB decimal values.

    Args:
        raw_hex_str: A 6-digit hex string of the color.

    Returns: A tuple containing the RGB decimal value of the color.
    """
    hex_str = raw_hex_str.lower().strip()
    red_hex, green_hex, blue_hex = hex_str[:2], hex_str[2:4], hex_str[4:]

    return tuple(
        int(hex_fragment, 16)
        for hex_fragment in [red_hex, green_hex, blue_hex]
    )


class ColorPalette:
    """A representation of a collection of Color instance."""

    def __init__(self, color_list: List[Color]) -> None:
        """Initialize the class and dynamically generate attributes.

        This class assigns each color in ``color_list`` as an attribute.
         You can access each color and their methods directly.

        Args:
            color_list: A list of Color instance.
        """
        self.color_list = color_list

        for color in color_list:
            self.__dict__[color.name] = color

    def get_hex_tuple(self) -> NamedTuple:
        """Return a NamedTuple of each color and its hex string.

        This method generates a named tuple containing each color and
         its hex string. It is a convenience method that gives easy
         access of the hex string of each color of the color palette.

        Returns: A ``NamedTuple`` where the keys are the names of the
         colors in the palette, and the values the hex strings.
        """
        hex_tuple = NamedTuple(
            "hex_tuple", **{color.name: str for color in self.color_list}
        )
        # hex_tuple is callable.
        return hex_tuple(  # pylint: disable=E1102
            **{color.name: color.hexstring() for color in self.color_list}
        )

    def __repr__(self):
        """Return a list of the name of the colors in the palette."""
        return ", ".join([color.name for color in self.color_list]).rstrip(
            ", "
        )


# The Comcast branding guide recommended color palette.
COMCAST_PALETTE = ColorPalette(
    [
        Color("white", 255, 255, 255),
        Color("yellow", 253, 185, 19),
        Color("red", 201, 35, 74),
        Color("purple", 100, 95, 170),
        Color("blue", 0, 137, 207),
        Color("green", 13, 177, 75),
        Color("black", 0, 0, 0),
        Color("mineshaft", 37, 37, 37),
        Color("carbon", 132, 132, 132),
        Color(
            "mercury",
            233,
            233,
            233,
        ),
    ]
)
