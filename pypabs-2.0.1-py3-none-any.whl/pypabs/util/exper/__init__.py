"""Experimental functions for various utilities."""
