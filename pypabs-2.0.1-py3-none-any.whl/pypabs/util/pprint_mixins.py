"""Mixin classes for pretty printing nested objects and lists."""


class PPrintMixin:  # pylint: disable=R0903
    """Provide __str__ method for pretty printing nested objects."""

    def __str__(self):
        """Define __str__ to pretty print nested objects."""
        lines = [self.__class__.__name__ + ":"]
        for key, val in vars(self).items():
            if isinstance(val, list):
                val = f"\n{' ' * len(key)}  ".join(map(str, val))
            lines += f"{key}: {val}".split("\n")
        return f"\n{' ' * 4}".join(lines)


class PPrintListMixin:  # pylint: disable=R0903
    """Provide __repr__ method for pretty printing a list."""

    def __repr__(self):
        """Provide __str__ method for pretty printing a list."""
        stringified_items = "\n".join(
            map(
                lambda x: "".join(
                    [f"Element: {x[0]}\n***********\n\n", str(x[1]), "\n\n"]
                ),
                enumerate(self),
            )
        ).split("\n")
        return "\n".join(stringified_items)
