"""The ``yaml_funcs`` module provides utility functions related to YAML processing."""

import yaml

__all__ = ["global_tag_customloader", "get_nth_yaml_doc"]


def global_tag_customloader(meta_doc=None):
    """
    Create custom loader that understands the !global tag.

    Custom loader replaces node tagged by !global tag with value corresponding
        to the key found in meta_doc.

    Args:
        meta_doc (dict): First document of the yaml file.

    Returns:
        A new custom class that extends yaml.SafeLoader.

    """

    class _CustomLoader(yaml.SafeLoader):  # pylint: disable=too-many-ancestors
        """Custom SafeLoader with constructor to parse !global tag."""

    def _import_global(self, node):
        """
        Define custom Constructor for the '!global' tag.

        Constructor is a function that accepts a Loader instance
        and a node object and produces the corresponding Python
        object.
        """
        node_key = self.construct_scalar(node)
        if meta_doc:
            return meta_doc.get(node_key)
        return None

    yaml.add_constructor("!global", _import_global, _CustomLoader)

    return _CustomLoader


def get_nth_yaml_doc(stream, doc_nr):
    """
    Get nth yaml document from a stream.

    Args:
        stream: Stream of YAML file.
        doc_nr: Document number starting with 1.

    Returns:
        dict: First document of the yaml file.

    """
    doc_idx = 0
    data = []
    for line in stream:
        if line == u"---\n" or line.startswith("--- "):
            doc_idx += 1
            continue
        if line == "...\n":
            break
        if doc_nr < doc_idx:
            break
        if line.startswith(u"%"):
            continue
        if doc_idx == 0:  # no initial '---' YAML files don't start with
            if line.lstrip().startswith("#"):
                continue
            doc_idx = 1
        if doc_idx == doc_nr:
            data.append(line)

    return yaml.load("".join(data), Loader=yaml.SafeLoader)
