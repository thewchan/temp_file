"""This module contains functions that operates on AXP datasets.

Attributes:
    LOCAL_FILENAME (str): Default S3 bucket name,
     set to ``axp-dataset-repo``
    S3_BUCKET (str): Default file name of dataset list; set to
     ``axp_datasets.yml``
    S3_FILENAME (str): Deafult local file name of dataset list; set to
     ``axp_datasets.yml``. The file must be a Yaml file.

Classes:
    AxpDataFrame: Wrapper around PySpark dataframe, containing data and
    meta data.
    AxpDatasetSpecs: Specifications used to retrieve dataframe from AXP
    data lake.
    AxpDatasetRepo: Repository, represented by a collection of
    ``AxpDatasetSpecs`` objects and methods to view specifications and
     retreive the corresponding datasets.

Functions:
    get_repo
    check_s3_valid
    put_repo_to_s3
    get_repo_from_s3
    get_dataset_info

"""
import importlib
import importlib.resources as pkg_resources
import logging
import sys
from collections import UserList
from dataclasses import dataclass
from typing import Dict, Optional, List, Union

import marshmallow_dataclass
import pandas as pd
import pyspark
from pyspark.sql import SparkSession
from pyspark.sql.dataframe import DataFrame
from pyspark.sql.types import StructType
import yaml

from pypabs import resources
from pypabs.featurefactory.featureframespecs import FeatureFrameSpecs
from pypabs.util.pprint_mixins import PPrintMixin, PPrintListMixin
from pypabs.util.s3 import s3

__all__ = [
    "AxpDataFrame",
    "AxpDatasetSpecs",
    "AxpDatasetRepo",
    "get_repo",
    "check_s3_valid",
    "put_repo_to_s3",
    "get_repo_from_s3",
    "get_dataset_info",
]

S3_BUCKET = "axp-dataset-repo"
S3_FILENAME = "axp_datasets.yml"
LOCAL_FILENAME = "axp_datasets.yml"


@dataclass
class AxpDatasetSpecs(PPrintMixin):
    """``AxpDatasetSpecs'' defines the schema for axp_dataset.yml.

    Attributes:
        name (str): Name of dataset
        basePath (str): Optional. Base path for parquet dataset
        location: (str): Location of dataset
        format: (str): Format of dataset

    """

    name: Optional[str] = None
    location: Optional[str] = None
    basePath: Optional[str] = None  # pylint: disable=C0103
    format: Optional[str] = None


class AxpDataFrame(PPrintMixin, DataFrame):
    """``AxpDataFrame`` extends Spark DataFrame with more attributes.

    If df is provided, this class is a essentially a wrapper around df.
    If df is ``None``, a new pyspark dataframe is created based on
        attributes from ``AxpDatasetSpecs`` object.

    Properties:
        axpspecs (AxpDatasetSpecs): Meta data on dataset source.
        ffspecs (FeatureFrameSpecs): Meta data on how the dataframe
            was generated.
        summary_stats (Pandas DataFrame): Summary statistics of dataframe.

    Attributes:
        name (str): Name of dataset
        basePath (str): Optional. Base path for parquet dataset
        location: (str): Location of dataset
        format: (str): Format of dataset

    """

    _axpspecs: Optional[AxpDatasetSpecs] = None
    _ffspecs: Optional[FeatureFrameSpecs] = None
    _summary_stats: Optional[pd.DataFrame] = None

    def __init__(
        self,
        df: Optional[pyspark.sql.DataFrame] = None,
        axpspecs: Optional[AxpDatasetSpecs] = None,
        ffspecs: Optional[FeatureFrameSpecs] = None,
        summary_stats: Optional[pd.DataFrame] = None,
        **kwargs,
    ) -> None:
        """Initialize class.

        Args:
            df (PySpark DataFrame): Optional. A PySpark dataframe.
            axpspecs (AxpDatasetSpecs): Optional. Specifications to
             source the dataframe.
            ffspecs (FeatureFrameSpecs): Optional. Specifications to
            generate the dataframe.
            summary_stats (Pandas DataFrame): Optional. Summary
             statistics of dataframe.

        """
        self._df = df
        self._axpspecs = axpspecs
        self._ffspecs = ffspecs
        self._summary_stats = summary_stats

        spark = SparkSession.builder.getOrCreate()

        if not (df or axpspecs):
            # Set default instance attributes to None
            for _k, _v in vars(AxpDatasetSpecs()).items():
                setattr(self, _k, _v)

            # Create empty DF with no schema
            self._df = spark.createDataFrame([], StructType([]))

        if axpspecs:
            for _k, _v in vars(axpspecs).items():
                setattr(self, _k, _v)
            if not df:
                self._load(spark)

        super().__init__(jdf=self._df._jdf, sql_ctx=self._df.sql_ctx, **kwargs)

    @property
    def axpspecs(self) -> Union[AxpDatasetSpecs, None]:
        """Return axpspecs object."""
        return self._axpspecs

    @property
    def ffspecs(self) -> Union[FeatureFrameSpecs, None]:
        """Return ffspecs object."""
        return self._ffspecs

    @property
    def summary_stats(self) -> Union[pd.DataFrame, None]:
        """Return summary statistics Pandas dataframe."""
        return self._summary_stats

    def _load(self, spark):
        """Load dataset based on attributes and assign dataset to _df."""
        try:
            ads = self._axpspecs
            if not ads.basePath:
                ads.basePath = ads.location
            res = (
                spark.read.format(ads.format)
                .option("basePath", ads.basePath)
                .load(ads.location)
            )
            self._df = res

        except Exception as exception:
            logging.exception(exception, exc_info=True)
            raise exception

    def info(self) -> None:
        """Print AxpDataFrame meta info."""
        print(self.axpspecs)
        if self._summary_stats is not None:
            print("\nSummary statistics:")
            print(
                self._summary_stats[
                    ["feature", "valid_count", "invalid_ratio", "mean"]
                ]
            )


class AxpDatasetRepo(  # pylint: disable=too-many-ancestors
    PPrintListMixin, UserList
):
    """Extends ``UserList`` with ``AxpDatasetSpecs`` objects.

    Methods:
        load(name: str): Taking string representing name of dateset, return
            ``AxpDataFrame`` object.
        get_axpspecs(name: str): Taking string representing name of dataset,
            return corresponding ``AxpDatasetSpecs`` object.
        to_list(): Return ``AxpDatasetRepo`` as list of dicts.
        to_df(): Return ``AxpDatasetRepo`` as Pandas dataframe.

    """

    def __init__(self, *args, **kwargs):
        """Load input dictionary and validate input list."""
        super().__init__(self._load(args[0]), **kwargs)

    @staticmethod
    def _load(dict_list):
        schema = marshmallow_dataclass.class_schema(AxpDatasetSpecs)
        return [
            schema().load(axp_dataset_dict) for axp_dataset_dict in dict_list
        ]

    def get_axpspecs(self, name: str) -> AxpDatasetSpecs:
        """Return ``AxpDatasetSpecs`` object given dataset name."""
        return next(filter(lambda x: x.name == name, self))

    def load(self, name: str) -> AxpDataFrame:
        """Return dataset as ``AxpDataFrame`` object given dataset name.

        Args:
            name (str): Dataset name that matches one in dataset list (YAML)

        Returns:
            ``AxpDataFrame`` object, a wrapper around PySpark Dataframe

        """
        return AxpDataFrame(df=None, axpspecs=self.get_axpspecs(name))

    def to_list(self) -> List[dict]:
        """Return list of ``AxpDatasetSpecs`` objects as dict."""
        return list(map(vars, self))

    def to_df(
        self, sort_by: Optional[str] = None, ascending: bool = True
    ) -> pd.DataFrame:
        """Return ``AxpDatasetRepo`` as Pandas dataframe."""
        dataset_df = pd.DataFrame(self.to_list(), range(len(self)))
        if sort_by:
            return dataset_df.sort_values(
                sort_by, ascending=ascending
            ).reset_index(drop=True)
        return dataset_df


class S3ConnectionError(Exception):
    """Custom exception to capture invalid s3 connection."""


def get_repo() -> Union[AxpDatasetRepo, None]:
    """Load repo from :attr:`LOCAL_FILENAME`.

    Returns:
        ``AxpDatasetRepo`` object, which is a list of
        ``AxpDatasetSpecs`` objects that reflect datasets listed
        from YAML file stored in :attr:`LOCAL_FILENAME`.

        ``None`` is returned if any exceptions are raised.

    No Longer Raises:
        Exception: Any error when reading the :attr:`LOCAL_FILENAME` Yaml
            file. ``None`` is returned instead.
    """
    try:
        yaml_file = pkg_resources.read_text(resources, LOCAL_FILENAME)
        datasets: List[Dict[str, str]] = yaml.safe_load(yaml_file)["datasets"]
        return AxpDatasetRepo(datasets)

    except Exception as exc:  # pylint: disable=W0703
        logging.exception(exc)
        return None


def check_s3_valid() -> bool:
    """Inspects whether a global S3 connection exists.

    This function checks if the global ``s3`` variable was set by
        importing the private :mod

    Returns:
        bool: Description

    Raises:
        Exception: Description
    """
    if "s3" in globals():
        global s3  # pylint: disable=W0603,C0103

        return True

    importlib.reload(sys.modules["pypabs.util.s3"])
    from pypabs.util.s3 import s3  # pylint: disable=W0404,W0621,C0415

    return True


def put_repo_to_s3() -> None:
    """Dump repo to s3."""
    try:
        check_s3_valid()
        with open(LOCAL_FILENAME, "rb") as data:
            s3.upload_fileobj(data, S3_BUCKET, S3_FILENAME)
    except FileNotFoundError as fnf_error:  # pragma: no cover
        logging.exception("dataset yaml file not found")
        logging.exception(fnf_error, exc_info=False)
        raise fnf_error
    except S3ConnectionError as s3conn_error:  # pragma: no cover
        logging.exception("Invalid s3 connection")
        logging.exception(s3conn_error, exc_info=False)
        raise s3conn_error
    except Exception as exc:  # pragma: no cover
        logging.exception("Error in uploading repo to s3")
        logging.exception(exc, exc_info=False)
        raise exc


def get_repo_from_s3() -> AxpDatasetRepo:
    """Load repo from s3.

    Returns:
        ``AxpDatasetRepo`` object, which is a list of
        ``AxpDatasetSpecs`` objects that reflect datasets listed
        from YAML file stored in :attr:`LOCAL_FILENAME`.

        ``None`` is returned if any exceptions are raised.

    No Longer Raises:
        Exception: Any error when reading the :attr:`LOCAL_FILENAME` Yaml
            file. ``None`` is returned instead.
    """
    try:
        check_s3_valid()
        res = s3.get_object(Bucket=S3_BUCKET, Key=S3_FILENAME)
        datasets = yaml.safe_load(res["Body"].read())["datasets"]
        return AxpDatasetRepo(datasets)
    except Exception as exc:  # pragma: no cover
        logging.exception("Invalid s3 connection")
        logging.exception(exc, exc_info=False)
        raise exc


def get_dataset_info(name: str) -> pd.DataFrame:
    """Load and check dataset information."""
    try:
        datamap = get_repo()
        if datamap is not None:
            datamap_df = datamap.to_df().query(f"name == '{name}'")
            if len(datamap_df) == 1:
                return datamap_df
            if len(datamap_df) > 1:  # pragma: no cover
                raise Exception("dataset name is not unique")

            raise Exception("dataset name not found in dictionary")

        raise Exception("axp dataset dictionary not found")

    except Exception as exc:  # pragma: no cover
        logging.exception("Cannot get dataset info")
        logging.exception(exc, exc_info=False)
        raise exc
