"""Reporting utility functions.

Contains functions related to generating/sending e-mail reports.

"""
from typing import List, Optional

from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication

import boto3
import pweave
from importlib_resources import files


def send_email(  # pylint: disable=R0914
    from_email: str,
    to_emails: str,
    subject: str,
    body_html: str,
    attachments: Optional[List[str]] = None,
) -> None:
    """Send an e-mail via AWS SES.

    Args:
        from_email (str): Sender's email address.
        to_emails (str): Recipient's email address.
        subject (str): Subject heading of report email.
        body_html (str): String containing the report's html.
        attachments (Optional[List[str]], optional): Optional list of
         file names to attach.

    """
    attachments = attachments or []
    attachment_ready_html = []
    mime_images = []

    # Iterate over raw HTML
    for line in body_html:
        attachment_ready_html.append(line)

    # Compile e-mail body and headers
    msg = MIMEMultipart()
    msg["Subject"] = subject
    msg["From"] = from_email
    msg["To"] = ", ".join(to_emails)
    body = MIMEText("\n".join(attachment_ready_html), "html")

    # Attachments
    for i in mime_images:
        msg.attach(i)

    msg.attach(body)

    for i, raw_attachment in enumerate(attachments):
        try:
            attachment_name = raw_attachment.split("/")[-1].replace(".png", "")
            with open(raw_attachment, "rb") as attachment_file:
                attachment = MIMEImage(attachment_file.read())
            attachment.add_header("Content-ID", f"<image-{attachment_name}>")
        except TypeError:
            with open(raw_attachment, "rb") as attachment_file:
                attachment = MIMEApplication(attachment_file.read())
            attachment.add_header(
                "Content-Disposition", "attachment", filename=raw_attachment
            )
        msg.attach(attachment)

    # Send
    ses = boto3.client("ses", region_name="us-east-1")
    ses.send_raw_email(
        Source=msg["From"],
        Destinations=to_emails,
        RawMessage={"Data": msg.as_string()},
    )
    print(f"Sent to: {to_emails}")


def pweave_html_report(
    report_module: str,
    report_name: str,
    output_module: str,
    output_name: str,
) -> None:
    """Run Pweave to generate HTML report and save to specified output_module.

    Function will take report with markdown and code from file in a library module,
    and save output to specified html file in output_module.

    Args:
        report_module (str): Name of library module containing python script for report
        report_name (str): Name of report python script with pweave markdown and code
        output_module (str): Name of output module
        output_name (str): Name of output html filename

    """
    report = ".".join(
        [
            str(files(report_module).joinpath(report_name)),
            "py",
        ]
    )
    out_html = ".".join(
        [
            str(files(output_module).joinpath(output_name)),
            "html",
        ]
    )

    # doc_format parameter can be 'html' or 'pdf'. However, there seems to be
    # some issues with 'pdf' that will need to be sorted out.
    pweave.publish(report, doc_format="html", output=out_html)
