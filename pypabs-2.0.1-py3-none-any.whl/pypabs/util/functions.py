"""Helper utility functions.

The "functions" module is part of the util package in the pypabs
library. It contains miscellaneous helper functions that increases
users convenience.
"""
import base64
import hashlib
import functools
import re
from datetime import datetime, timedelta
from typing import Union, Callable

from pyspark.sql import DataFrame, SparkSession

__all__ = [
    "cc_convert",
    "tphash",
    "format_mac",
    "xbo_table",
    "generate_day_id",
    "compose",
]


def cc_convert(name: str) -> str:
    """Convert PascalCase or camelCase to snake_case.

    Args:
        name (str): A string in PascalCase or camelCase.

    Returns:
        str: ``name`` in snake_case.

    Examples:
        >>> cc_convert("John Doe")
        'john_doe'
    """
    s1 = re.sub("(.)([A-Z][a-z]+)", r"\1_\2", name)
    return re.sub("([a-z0-9])([A-Z])", r"\1_\2", s1).lower()


def tphash(s: Union[float, int, str]) -> str:
    """Convert a string or a number to a tpid.

    Args:
        s (Union[float, int, str]):
            A string (although numbers are acceptable) to be converted
            to a hashed tpid.

    Returns:
        str: Hashed tpid as a string.

    Examples:
        >>> tphash("john_doe")
        'mWgrZiFmzY5K3GDUPGe3qCJ7PN10RS299xtspCo2Y2M'
    """
    return base64.b64encode(
        hashlib.sha256(str(s).encode("utf-8")).digest()
    ).decode("utf-8")


def format_mac(x: str) -> str:
    """Correctly format a MAC address.

    Args:
        x (str): A mac address as a string that may be variously formatted.

    Returns:
        str: An appropriately formatted MAC address as a string.

    Examples:
        >>> format_mac("00-D0-56-F2-B5-12 or 00-26-DD-14-C4-EE")
        '00:-D:0-:56:-F:2-:B5:-1:2 :OR: 0:0-:26:-D:D-:14:-C:4-:EE'
    """
    if ":" in x:
        return x.upper()
    return ":".join([x[i : i + 2] for i in range(0, len(x), 2)]).upper()


def xbo_table(table: str, dt: str = None) -> DataFrame:
    """Retrieve a pyspark data frame given the xbo_table name and datetime.

    Args:
        table (str): The valid name of the xbo table.
        dt (str, optional): Date string in YYYY-MM-DD format. If none
            is supplied, no filtering of the data frame would occur.
            Use :func:`generate_day_id` to obtain a correctly formatted
            date string.

    Returns:
        DataFrame:
            The data frame of the given ``table`` id located at
            the `<s3://pabs-xbo/>`_ bucket. If ``dt`` is specified, the data
            frame will narrow to rows of only those dates.

    Raises:
        Exception: If an invalid or non-existent xbo table name was
            supplied.
    """
    spark = SparkSession.builder.getOrCreate()
    xbo_tables = ["account", "device", "account-product"]
    table = table.lower()
    if table not in xbo_tables:
        raise Exception(
            f"Please enter a valid XBO table name: {','.join(xbo_tables)}"
        )
    df = spark.read.format("delta").load(f"s3://pabs-xbo/xbo-{table}-delta/")
    if dt:
        df = df.filter(f"day_id='{dt}'")
    return df


def generate_day_id(delta_days: int = 0) -> str:
    """Generate a date string given the number of days from today.

    Args:
        delta_days (int, optional): An integer specifying the number of
            days from today. If none is supplied a date string for
            today will be returned.

    Returns:
        str: A date string ``delta_days`` from day in the past.

    Examples:
        >>> generate_day_id(-4)
        '2021-01-31'
    """
    dt = (datetime.now() + timedelta(days=delta_days)).strftime("%Y-%m-%d")
    return dt


def compose(*functions: Callable) -> Callable:
    """
    Return a callable that is a composition of the input functions.

    Args:
        *functions (callable): input functions as separate args.
        or:
        functions (list): a list of input functions.

    Return:
        callable: a composition of the input functions.

    """
    if isinstance(functions[0], list):
        functions = functions[0]

    return functools.reduce(
        lambda f, g: lambda x: f(g(x)), functions, lambda x: x
    )
