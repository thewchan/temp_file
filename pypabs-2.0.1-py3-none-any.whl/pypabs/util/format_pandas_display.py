"""Module contains code to set custom Pandas display format."""
import pandas as pd
import pandas.io.formats.format as pf


def set_custom_pandas_display() -> None:
    """Set custom Pandas display format. Pure side-effect."""
    pd.set_option("display.max_rows", None)
    pd.set_option("display.max_columns", None)
    pd.set_option("display.width", 200)
    pd.set_option("display.float_format", "{:.3f}".format)

    # Format integer display
    class _IntArrayFormatter(
        pf.GenericArrayFormatter
    ):  # pylint: disable=too-few-public-methods
        """
        Define custom IntArrayFormatter.

        This class is to replace ("monkey patch") the default
        IntArrayFormatter in Pandas to print integer values with
        thousands separated by underscore and with zero trailing
        decimal.
        """

        def _format_strings(self):
            formatter = self.formatter or "{:_d}".format
            fmt_values = [formatter(x) for x in self.values]
            return fmt_values

    pf.IntArrayFormatter = _IntArrayFormatter
